﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace OCDStudio.SMSPPP.OutlookClient
{
    public partial class ChangeSettings : Form
    {
        public ChangeSettings()
        {
            InitializeComponent();
        }

        private void ChangeSettings_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
        }

        private void ChangeSettings_Load(object sender, EventArgs e)
        {
            txtIp.Text = Utilities.GetIP();
            txtPort.Text = Utilities.GetPort().ToString();
        }

        private void cmdSave_Click(object sender, EventArgs e)
        {
            Utilities.SetValues(txtIp.Text, txtPort.Text);
            Dispose();
        }
    }
}
