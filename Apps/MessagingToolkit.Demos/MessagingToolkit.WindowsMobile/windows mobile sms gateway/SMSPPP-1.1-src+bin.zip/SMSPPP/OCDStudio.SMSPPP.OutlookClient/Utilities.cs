﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using Microsoft.Win32;
using System.Text.RegularExpressions;

namespace OCDStudio.SMSPPP.OutlookClient
{
    class Utilities
    {
        public static string DEFAULT_IP = "169.254.2.1";
        public static string DEFAULT_PORT = "65535";

        public static bool CheckRegistry() {
            try
            {
                RegistryKey mainKey = Registry.CurrentUser;
                RegistryKey sub = mainKey.CreateSubKey("Software");
                RegistryKey key = sub.OpenSubKey("OCDStudio").OpenSubKey("OutlookSMS");
                return true;
            }
            catch
            {
                return false;
            }
        }

        public static void SetValues(string ip, string port) {
            string key = "OCDStudio";
            string subkey = "OutlookSMS";
            RegistryKey mainKey = Registry.CurrentUser;
            RegistryKey sub = mainKey.CreateSubKey("Software");
            sub = sub.CreateSubKey(key);
            sub = sub.CreateSubKey(subkey);
            sub.SetValue("IP", ip);
            sub.SetValue("Port", port);
        }

        public static string GetIP() {
            if (CheckRegistry()) {
                RegistryKey mainKey = Registry.CurrentUser;
                RegistryKey sub = mainKey.CreateSubKey("Software");
                RegistryKey key = sub.OpenSubKey("OCDStudio").OpenSubKey("OutlookSMS");
                return key.GetValue("IP").ToString();
            }
            return "";
        }

        public static int GetPort()
        {
            if (CheckRegistry())
            {
                RegistryKey mainKey = Registry.CurrentUser;
                RegistryKey sub = mainKey.CreateSubKey("Software");
                RegistryKey key = sub.OpenSubKey("OCDStudio").OpenSubKey("OutlookSMS");
                return Int32.Parse(key.GetValue("Port").ToString());
            }
            return -1;
        }



        internal static void SaveSettings(List<ListItem> list)
        {
            string result = "";
            foreach (ListItem item in list) {
                result += item.ToString()+"!";
            }
            global::OCDStudio.SMSPPP.OutlookClient.Properties.Settings.Default.Lists = result.Substring(0,result.Length-1);
            global::OCDStudio.SMSPPP.OutlookClient.Properties.Settings.Default.Save();
        }
    }
}
