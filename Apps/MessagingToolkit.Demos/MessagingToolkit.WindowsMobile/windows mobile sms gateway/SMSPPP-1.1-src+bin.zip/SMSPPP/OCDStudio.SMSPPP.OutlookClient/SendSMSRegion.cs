﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Office = Microsoft.Office.Core;
using Outlook = Microsoft.Office.Interop.Outlook;
using OpenNETCF.Desktop.Communication;
using System.Windows.Forms;
using System.Net.Sockets;
using System.IO;
using OCDStudio.SMSPPP.Common;
using OCDStudio.SMSPPP.Common.Mobile;

namespace OCDStudio.SMSPPP.OutlookClient
{
    partial class SendSMSRegion
    {
        #region Form Region Factory

        [Microsoft.Office.Tools.Outlook.FormRegionMessageClass(Microsoft.Office.Tools.Outlook.FormRegionMessageClassAttribute.Appointment)]
        [Microsoft.Office.Tools.Outlook.FormRegionMessageClass(Microsoft.Office.Tools.Outlook.FormRegionMessageClassAttribute.Contact)]
        [Microsoft.Office.Tools.Outlook.FormRegionMessageClass(Microsoft.Office.Tools.Outlook.FormRegionMessageClassAttribute.Note)]
        [Microsoft.Office.Tools.Outlook.FormRegionName("OulookSMSClient.SendSMSRegion")]
        public partial class SendSMSRegionFactory
        {
            // Occurs before the form region is initialized.
            // To prevent the form region from appearing, set e.Cancel to true.
            // Use e.OutlookItem to get a reference to the current Outlook item.
            private void SendSMSRegionFactory_FormRegionInitializing(object sender, Microsoft.Office.Tools.Outlook.FormRegionInitializingEventArgs e)
            {
            }
        }

        #endregion


        private Outlook.Items contactItems;
        private List<ListItem> list = new List<ListItem>();
        private MobileConnection connection;
        private bool connected;

        #region "Properties"


        public MobileConnection Connection
        {
            get { return connection; }
            set { connection = value; }
        }

        public List<ListItem> NumberList
        {
            get { return list; }
            set { list = value; }
        }

        #endregion

        #region "SMS"


        private void CalculateNumMessages(){
            int nRec = 0;
            int nMex = 0;
            nRec = lstContacts.CheckedItems.Count;
            nMex = (int)(txtMessage.TextLength / 160);
            int res=nRec*(nMex+1);
            lblNumMessages.Text = res.ToString() + " message(s)";
        }


        private void SendMessage()
        {
            if (!connection.IsActive) return;

            SMSPPPCommandBody body = new SMSPPPCommandBody();

            foreach (object obj in lstContacts.CheckedItems)
            {
                string mobo = obj.ToString().Split(':')[1];
                body.Parameters.Add(new NameValue(mobo, txtMessage.Text));
            }

            SMSPPPCommandsResponses resp=
                connection.SendCommandAndWaitResponse(SMSPPPCommands.SEND_SMS, body);
            if (resp == SMSPPPCommandsResponses.MESSAGE_RECEIVED)
            {
                MessageBox.Show("Message(s) sent!", "SMSPPP Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

        }

        

        #endregion

        #region "Phone Call"

        private void cmdStartCall_Click(object sender, EventArgs e)
        {
            try
            {
                if (lstContacts.SelectedItem != null)
                {
                    object obj = lstContacts.SelectedItem;
                    string mobo = obj.ToString().Split(':')[1];

                    SMSPPPCommandBody body = new SMSPPPCommandBody();
                    body.Parameters.Add(new NameValue(SMSPPPConstants.PHONE_CALL_RECIPIENT_KEY, mobo));
                    SMSPPPCommandsResponses resp = connection.SendCommandAndWaitResponse(
                        OCDStudio.SMSPPP.Common.Mobile.SMSPPPCommands.SEND_SMS, body);

                    if (resp != SMSPPPCommandsResponses.MESSAGE_RECEIVED)
                    {
                        //TODO
                    }

                    /* catch
                     {
                         switch (MessageBox.Show("PocketPC server seems to be stopped or maybe it listens on different settings: do you want to change settings?",
                              "Attention!", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Information))
                         {
                             case DialogResult.Yes:
                                 new ChangeSettings().ShowDialog();
                                 break;
                             case DialogResult.No:
                                 MessageBox.Show("Please activate server and click OK!", "Attention!");
                                 break;
                             case DialogResult.Cancel:
                                 MessageBox.Show("Not sent!", "Information!");
                                 return;
                         }

                         continue;
                     }
                 }*/
                }

            }
            catch
            {
                MessageBox.Show("Error while trying to call your contact!", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        #endregion

        #region "General + Outlook Integration"


        private bool CheckConditions()
        {

            try
            {
                if (connection==null || !connection.IsActive)
                {
                    connection = MobileConnectionFactory.GetInstance();
                    connection.ConnectToDevice();
                    LoadAll();
                }
            }
            catch
            {
                new ShowUserSettings().ShowDialog();
                try
                {
                    if (connection == null || !connection.IsActive)
                    {
                        connection = MobileConnectionFactory.GetInstance();
                        connection.ConnectToDevice();
                        connected = true;
                        LoadAll();
                    }
                }
                catch
                {
                    UnloadAll();
                    return false;
                }
            }
            return true;
            
        }

        private void SendSMSRegion_Load(object sender, EventArgs e)
        {
            Outlook.Application objOutlook = new Outlook.Application();
            Outlook.NameSpace outlookNameSpace = objOutlook.GetNamespace("MAPI");
            Outlook.MAPIFolder contactsFolder = outlookNameSpace.GetDefaultFolder(Outlook.OlDefaultFolders.olFolderContacts);
            contactItems = contactsFolder.Items;


            CheckConditions();
            txtMessage.TextChanged += new EventHandler(txtMessage_TextChanged);
        }

        private void ContactsTask() {
                    
            bool bloop = false;
            lstContacts.Items.Clear();
            try
            {
                do
                {
                    try
                    {
                        Outlook.ContactItem contact = (Outlook.ContactItem)contactItems.GetNext();
                        if (contact != null)
                        {

                            if (!String.IsNullOrEmpty(contact.MobileTelephoneNumber))
                                lstContacts.Items.Add(contact.FullName.PadRight(30) + " :" + contact.MobileTelephoneNumber);

                            bloop = true;
                        }
                        else
                        {
                            bloop = false;
                        }
                    }
                    catch
                    {
                        continue;
                    }
                } while (bloop == true);
            }
            catch (Exception ex)
            {
                return;
            }
            lstContacts.Sorted = true;

        }


        #endregion

        
        #region "QuickLists"

        private void PopulateList()
        {
            list.Clear();
            string ls = global::OCDStudio.SMSPPP.OutlookClient.Properties.Settings.Default.Lists;
            if (String.IsNullOrEmpty(ls)) return;

            string[] lists = ls.Split('!');
            foreach (string str in lists)
            {
                ListItem temp = new ListItem();
                string[] fields = str.Split('?');
                temp.Name = fields[0];
                foreach (string num in fields[1].Split('$'))
                {
                    temp.Numbers.Add(num);
                }
                list.Add(temp);
            }
            RefreshCombo();
        }

        private void cmdSave_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(txtNewList.Text) || lstContacts.CheckedItems.Count == 0)
            {
                MessageBox.Show("Please select at least one item and specify a valid name!", "Attention!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            ListItem it = new ListItem();
            it.Name= txtNewList.Text;

            foreach (object obj in lstContacts.CheckedItems)
            {
                it.Numbers.Add(obj.ToString().Split(':')[1]);
            }
            list.Add(it);
            Utilities.SaveSettings(list);
            RefreshCombo();
            MessageBox.Show("Quick List Added!", "Completed!",MessageBoxButtons.OK,MessageBoxIcon.Information);
        }
        
        private void cmbQuickList_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            var item = from tmp in list
                       where tmp.Name == cmbQuickList.Text
                       select tmp;

            for (int i = 0; i < lstContacts.Items.Count; i++) {
                string num = lstContacts.Items[i].ToString().Split(':')[1];
                if (item.First().Numbers.Contains(num)) 
                    lstContacts.SetItemChecked(i, true);
                else 
                    lstContacts.SetItemChecked(i, false);
            }

            
        }

        private void cmdDelete_Click(object sender, EventArgs e)
        {
            if (!String.IsNullOrEmpty(cmbQuickList.Text)) {
                string name = cmbQuickList.Text;
                if (MessageBox.Show("Are you sure you want to delete " + name + " list?", "Attention!", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    var item = from tmp in list
                               where tmp.Name == cmbQuickList.Text
                               select tmp;
                    ListItem it = item.First();
                    list.Remove(it);
                    Utilities.SaveSettings(list);
                    RefreshCombo();
                }
            }
        }

        #endregion

        #region "GUI"

        private void SendSMSRegion_FormRegionShowing(object sender, System.EventArgs e)
        {
        }


        private void SendSMSRegion_FormRegionClosed(object sender, System.EventArgs e)
        {
        }

        void txtMessage_TextChanged(object sender, EventArgs e)
        {
            CalculateNumMessages();
        }

        private void UnloadAll()
        {
            splitContainer1.Panel1.Enabled = false;
            splitContainer1.Panel2.Enabled = true;
            lblAdvice.Visible = true;
        }

        private void LoadAll()
        {
            splitContainer1.Panel1.Enabled = true;
            splitContainer1.Panel2.Enabled = false;
            lblAdvice.Visible = false;

            ContactsTask();
            PopulateList();

            txtMessage.ResetText();
        }



        private void RefreshCombo()
        {
            cmbQuickList.Items.Clear();
            foreach (ListItem it in list)
            {
                cmbQuickList.Items.Add(it.Name);
            }
        }

        private void cmdRefresh_Click(object sender, EventArgs e)
        {
            CheckConditions();
        }

        private void cmdSend_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(txtMessage.Text)) return;

            SendMessage();
            
            txtMessage.ResetText();

        }

        private void lstContacts_MouseUp(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            CalculateNumMessages();
        }

        private void cmdClear_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < lstContacts.Items.Count; i++) {
                lstContacts.SetItemChecked(i, false);
            }
            
        }

        private void lstContacts_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstContacts.SelectedItem != null)
            {
                cmdStartCall.Visible = true;
            }
            else
            {
                cmdStartCall.Visible = false;
            }
        }

        #endregion        
        
    }
}
