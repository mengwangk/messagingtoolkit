﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OCDStudio.SMSPPP.OutlookClient
{
    public class ListItem
    {

        private string name;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        private List<string> numbers=new List<string>();

        public List<string> Numbers
        {
            get { return numbers; }
            set { numbers = value; }
        }

        public override string ToString()
        {
            string text = name+"?";
            foreach (string str in numbers) {
                text += str+"$";
            }

            return text.Substring(0, text.Length - 1);
        }
    }
}
