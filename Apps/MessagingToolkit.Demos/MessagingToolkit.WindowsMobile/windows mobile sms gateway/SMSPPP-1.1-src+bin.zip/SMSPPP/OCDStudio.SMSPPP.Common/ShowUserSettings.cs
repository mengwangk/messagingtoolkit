﻿//
// SMS PocketPC Proxy by Roberto Freato
// http://www.codeplex.com/SMSPPP/
// http://www.robertofreato.com/
//
// Permission is hereby granted, free of charge, to any person obtaining
// a copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to
// permit persons to whom the Software is furnished to do so. subject to
// the following conditions:
// 
// 1. The above copyright notice and this permission notice shall be
//    included in all copies or substantial portions of the Software.
// 2. Namespaces or Class names of the Software components shall not
//    be modified.
// 3. Neither the name of the copyright holders nor the names of its
//    contributors may be used to endorse or promote products derived from
//    this software without specific prior written permission.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
// NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
// LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
// OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
// WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using OCDStudio.SMSPPP.Common.Mobile;

namespace OCDStudio.SMSPPP.Common
{
    public partial class ShowUserSettings : Form
    {
        private MobileConnectionProperties properties;

        public ShowUserSettings()
        {
            InitializeComponent();
        }

        private void ShowUserSettings_Load(object sender, EventArgs e)
        {
            
            try
            {
                properties = MobileConnectionFactory.GetUserConnectionProperties();
                UpdateList();
            }
            catch
            {
                properties = new MobileConnectionProperties();
            }
            connectionPropertiesBindingSource.DataSource = properties.Properties;
            connectionPropertiesBindingSource.CurrentItemChanged += new EventHandler(connectionPropertiesBindingSource_CurrentItemChanged);
            

            
        }

        void connectionPropertiesBindingSource_CurrentItemChanged(object sender, EventArgs e)
        {
            UpdateList();
        }

        private void cmdAddNew_Click(object sender, EventArgs e)
        {
            properties.Properties.Add(new ConnectionProperties("0.0.0.0", 65535, "NewConfiguration"));
            UpdateList();
        }

        private void UpdateList() {
            lstProperties.Items.Clear();
            foreach (ConnectionProperties pr in properties.Properties)
            {
                lstProperties.Items.Add(pr);
            }
        }

        private void lstProperties_DoubleClick(object sender, EventArgs e)
        {            
            properties.SelectedAsDefault = lstProperties.SelectedIndex;
            label4.Text = properties.SelectedAsDefault.ToString();
        }

        private void lstProperties_Click(object sender, EventArgs e)
        {
            if (lstProperties.SelectedItem!=null ) connectionPropertiesBindingSource.DataSource = lstProperties.SelectedItem;
        }

        private void cmdSave_Click(object sender, EventArgs e)
        {
            connectionPropertiesBindingSource.EndEdit();
            if (properties.SelectedAsDefault < 0) properties.SelectedAsDefault = 0;
            MobileConnectionFactory.SetUserConnectionProperties(properties);
            Dispose();
        }

        private void cmdRemove_Click(object sender, EventArgs e)
        {
            if (lstProperties.SelectedItem != null)
            {
                properties.Properties.Remove(lstProperties.SelectedItem as ConnectionProperties);
                UpdateList();
            }
        }

        
        
    }

}
