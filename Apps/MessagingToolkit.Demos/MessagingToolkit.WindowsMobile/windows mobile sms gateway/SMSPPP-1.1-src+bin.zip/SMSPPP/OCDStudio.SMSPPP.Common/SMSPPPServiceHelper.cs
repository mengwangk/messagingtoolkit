﻿//
// SMS PocketPC Proxy by Roberto Freato
// http://www.codeplex.com/SMSPPP/
// http://www.robertofreato.com/
//
// Permission is hereby granted, free of charge, to any person obtaining
// a copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to
// permit persons to whom the Software is furnished to do so. subject to
// the following conditions:
// 
// 1. The above copyright notice and this permission notice shall be
//    included in all copies or substantial portions of the Software.
// 2. Namespaces or Class names of the Software components shall not
//    be modified.
// 3. Neither the name of the copyright holders nor the names of its
//    contributors may be used to endorse or promote products derived from
//    this software without specific prior written permission.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
// NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
// LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
// OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
// WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OCDStudio.SMSPPP.Common.Mobile;

namespace OCDStudio.SMSPPP.Common
{
    /// <remarks>
    /// Class that contains some helper method to perform basic operation on SMSPPP framework.
    /// </remarks>
    public class SMSPPPServiceHelper
    {
        /// <summary>
        /// This method allows the developer to quickly send a single sms to a recipient, without 
        /// knowing all implementation details. It is useful when you don't want to learn API 
        /// but just use the framework rapidly.
        /// </summary>
        /// <param name="recipient">The string representing the recipient mobile phone number</param>
        /// <param name="message">The text message to send</param>
        /// <param name="conn">The active connection to use to send the message</param>
        /// <returns>It returns false if something goes wrong in the communication, or if the connection
        /// is not active. True if the expected server response message is received.</returns>
        public static bool SendSingleSMS(string recipient,string message,MobileConnection conn){
            if (!conn.IsActive) return false;
            SMSPPPCommandBody body=new SMSPPPCommandBody();
            body.Parameters.Add(new NameValue(recipient,message));
            SMSPPPCommandsResponses resp=conn.SendCommandAndWaitResponse(
                OCDStudio.SMSPPP.Common.Mobile.SMSPPPCommands.SEND_SMS, body);
            if (resp == SMSPPPCommandsResponses.MESSAGE_RECEIVED) return true;
            else return false;
        }

        /// <summary>
        /// This method allows the developer to quickly start a call to the specified contact number,
        /// without knowing all implementation details. It is useful when you don't want to learn API 
        /// but just use the framework rapidly.
        /// </summary>
        /// <param name="number">The string representing the recipient mobile phone number</param>
        /// <param name="conn">The active connection to use to send the message</param>
        /// <returns>It returns false if something goes wrong in the communication, or if the connection
        /// is not active. True if the expected server response message is received.</returns>
        public static bool StartPhoneCall(string number, MobileConnection conn)
        {
            if (!conn.IsActive) return true;
            SMSPPPCommandBody body = new SMSPPPCommandBody();
            body.Parameters.Add(new NameValue(SMSPPPConstants.PHONE_CALL_RECIPIENT_KEY, number));
            SMSPPPCommandsResponses resp = conn.SendCommandAndWaitResponse(
                OCDStudio.SMSPPP.Common.Mobile.SMSPPPCommands.PHONE_CALL, body);
            if (resp == SMSPPPCommandsResponses.MESSAGE_RECEIVED) return true;
            else return false;
        }

    }
}
