﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.Net;

namespace OCDStudio.SMSPPP.WindowsMobile.Server
{
    public partial class MainForm : Form
    {

        
        private Dictionary<FriendlyButtons, Rectangle> buttons;
        
        private int defaultPort;
        private SMSPPPMobileServer server=null;
        private Thread serverThread = null;
        private int supposedHeight = 320;
        private int supposedWidth = 240;

        public MainForm()
        {
            String g = System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal) + "\\SMSPPPData\\SMSPPP.sdf;";


            InitializeComponent();
            buttons = new Dictionary<FriendlyButtons, Rectangle>();
            buttons.Add(FriendlyButtons.Start, new Rectangle(33, 258, 55, 30));
            buttons.Add(FriendlyButtons.Stop, new Rectangle(97, 258, 55, 30));
            buttons.Add(FriendlyButtons.Exit, new Rectangle(162, 258, 55, 30));

            defaultPort = Int32.Parse(global::OCDStudio.SMSPPP.WindowsMobile.Server.Properties.Resources.DefaultPort);

            PopulateServicesList();

        }

        private void PopulateServicesList()
        {
            List<SMSPPPServices> list = SMSPPPMobileHelper.GetImplementedServices();
            foreach (SMSPPPServices serv in list)
            {
                lstServices.Items.Add(serv.ToString());
            }
        }

        

        private void bg_MouseDown(object sender, MouseEventArgs e)
        {
            FriendlyButtons b = DiscoverButton(e.X, e.Y);
            switch (b)
            {
                case FriendlyButtons.Start:
                    DoStart();
                    break;
                case FriendlyButtons.Stop:
                    DoStop();
                    break;
                case FriendlyButtons.Exit:
                    DoExit();
                    break;                
            }
        }

        private void DoExit()
        {
            DoStop();
            Application.Exit();
        }

        private void DoStop()
        {
            if (server != null)
            {
                serverThread.Abort();
                server.StopServer();
                server = null;
                status.Text = "Server stopped - ready!";
                PopulateIPsList();
            }
        }

        private void DoStart()
        {
            if (server == null)
            {
                server = new SMSPPPMobileServer(defaultPort);

                serverThread = new Thread(new ThreadStart(server.StartServer));
                serverThread.Start();

                Thread.Sleep(1000);

                PopulateIPsList();
                

                status.Text = "Server started!";
                return;
            }
            else
            {
                status.Text = "Server already started!";

            }
        }

        private void PopulateIPsList()
        {
            String strHostName = Dns.GetHostName();
            lstEndpoint.Items.Clear();            
            IPHostEntry iphostentry = Dns.GetHostByName(strHostName);
            

            foreach (IPAddress ipaddress in iphostentry.AddressList)
            {
                lstEndpoint.Items.Add(ipaddress.ToString());
            }
        }

        private FriendlyButtons DiscoverButton(int p1, int p2)
        {
            float hCorrection, wCorrection;
            hCorrection = ((float)supposedHeight) / ((float)System.Windows.Forms.Screen.PrimaryScreen.Bounds.Height);
            wCorrection = ((float)supposedWidth) / ((float)System.Windows.Forms.Screen.PrimaryScreen.Bounds.Width);



            foreach (FriendlyButtons btn in buttons.Keys)
            {
                Rectangle rect = buttons[btn];
                
                rect.Width =(int)( ((float) rect.Width)/wCorrection);
                rect.Height = (int)(((float)rect.Height) / hCorrection);
                rect.X = (int)(((float)rect.X) / wCorrection);
                rect.Y = (int)(((float)rect.Y) / hCorrection);                
                if (rect.Contains(new Point(p1,p2))) return btn;
            }
            return FriendlyButtons.NoButton;
        }
    }

    enum FriendlyButtons
    {
        Start,
        Stop,
        Exit,
        NoButton
    }
}