﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using Microsoft.WindowsMobile.PocketOutlook;
using Microsoft.WindowsMobile.Telephony;

namespace OCDStudio.SMSPPP.WindowsMobile.Server
{
    public class SMSPPPMobileHelper
    {

        private static List<SMSPPPServices> implemented;

        public static List<SMSPPPServices> GetImplementedServices()
        {
            if (implemented != null) return implemented;

            implemented = new List<SMSPPPServices>();

            OutlookSession session = new OutlookSession();
            if (session.SmsAccount != null) implemented.Add(SMSPPPServices.SMS);
            session.Dispose();

            try
            {
                Phone phone = new Phone();
                implemented.Add(SMSPPPServices.Phone);
                phone = null;
            }
            catch
            {
            }

            return implemented;

        }

    }


    public enum SMSPPPServices{
        SMS,
        Phone
    }
}
