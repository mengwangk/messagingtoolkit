﻿namespace OCDStudio.SMSPPP.WindowsMobile.Server
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.bg = new System.Windows.Forms.PictureBox();
            this.lstEndpoint = new System.Windows.Forms.ListBox();
            this.lstServices = new System.Windows.Forms.ListBox();
            this.status = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // bg
            // 
            this.bg.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bg.Image = ((System.Drawing.Image)(resources.GetObject("bg.Image")));
            this.bg.Location = new System.Drawing.Point(0, 0);
            this.bg.Name = "bg";
            this.bg.Size = new System.Drawing.Size(240, 320);
            this.bg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bg.MouseDown += new System.Windows.Forms.MouseEventHandler(this.bg_MouseDown);
            // 
            // lstEndpoint
            // 
            this.lstEndpoint.BackColor = System.Drawing.Color.DimGray;
            this.lstEndpoint.Location = new System.Drawing.Point(23, 97);
            this.lstEndpoint.Name = "lstEndpoint";
            this.lstEndpoint.Size = new System.Drawing.Size(190, 44);
            this.lstEndpoint.TabIndex = 1;
            // 
            // lstServices
            // 
            this.lstServices.BackColor = System.Drawing.Color.DimGray;
            this.lstServices.Location = new System.Drawing.Point(158, 154);
            this.lstServices.Name = "lstServices";
            this.lstServices.Size = new System.Drawing.Size(55, 58);
            this.lstServices.TabIndex = 3;
            // 
            // status
            // 
            this.status.BackColor = System.Drawing.Color.DimGray;
            this.status.Location = new System.Drawing.Point(23, 222);
            this.status.Name = "status";
            this.status.Size = new System.Drawing.Size(190, 19);
            this.status.Text = "Ready to start";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(240, 320);
            this.Controls.Add(this.status);
            this.Controls.Add(this.lstServices);
            this.Controls.Add(this.lstEndpoint);
            this.Controls.Add(this.bg);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Location = new System.Drawing.Point(0, 0);
            this.Name = "MainForm";
            this.Text = "SMSPPP";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox bg;
        private System.Windows.Forms.ListBox lstEndpoint;
        private System.Windows.Forms.ListBox lstServices;
        private System.Windows.Forms.Label status;
    }
}

