﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.Specialized;

namespace OCDStudio.SMSPPP.Common.Mobile
{
    public enum SMSPPPCommands
    {
        HEARTBEAT,
        SEND_SMS,
        PHONE_CALL
    }

    public enum SMSPPPCommandsResponses
    {
        HEARTBEAT_OK,
        COMMAND_NOT_UNDERSTOOD,
        MESSAGE_RECEIVED,
        WRONG_MESSAGE_FORMAT,
        WRONG_COMMAND_SYNTAX
    }

    [Serializable]
    public class SMSPPPCommandBody
    {
        public SMSPPPCommandBody()
        {

        }
        
        private List<NameValue> parameters;

        public List<NameValue> Parameters
        {
            get {
                if (parameters == null)
                    parameters = new List<NameValue>();
                return parameters; }
            set { parameters = value; }
        }
    }

    [Serializable]
    public class NameValue
    {
        public NameValue()
        {

        }

        public NameValue(string name,string value)
        {
            this.name = name;
            this.value = value;
        }

        private string name;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        private string value;

        public string Value
        {
            get { return this.value; }
            set { this.value = value; }
        }
    }
}
