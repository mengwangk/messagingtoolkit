﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OCDStudio.SMSPPP.Common.Mobile
{
    public class SMSPPPConstants
    {

        public static string COMMAND_BODY_SEPARATOR = "$";
        public static string PHONE_CALL_RECIPIENT_KEY = "REC";
    }
}
