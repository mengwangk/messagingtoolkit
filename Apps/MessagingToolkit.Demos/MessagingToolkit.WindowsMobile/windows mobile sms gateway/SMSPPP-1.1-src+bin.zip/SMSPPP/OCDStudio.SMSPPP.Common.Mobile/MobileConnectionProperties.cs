﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace OCDStudio.SMSPPP.Common.Mobile
{
    [Serializable]
    public class MobileConnectionProperties:IEnumerator
    {
        public MobileConnectionProperties()
        {

        }

        private List<ConnectionProperties> properties;

        public List<ConnectionProperties> Properties
        {
            get
            {
                if (properties == null) 
                    properties= new List<ConnectionProperties>();
                 return properties;
            }
            set { properties = value; }
        }
        private int selectedAsDefault;

        public int SelectedAsDefault
        {
            get { return selectedAsDefault; }
            set { selectedAsDefault = value; }
        }

        #region IEnumerator Members

        private List<int> ordered = null;
        private int currentIdx = -1;

        public object Current
        {
            get { return properties.ElementAt(ordered.ElementAt(currentIdx)); }
        }



        public bool MoveNext()
        {
            if (ordered == null) Reset();
            if (++currentIdx >= ordered.Count) return false;
            else return true;
        }

        public void Reset()
        {
            ordered = new List<int>();
            int count = properties.Count;
            int def = selectedAsDefault;
            ordered.Add(def);
            for (int i = 0; i < count; i++)
            {
                if (i == def) continue;
                ordered.Add(i);
            }
        }

        #endregion
    }

    [Serializable]
    public class ConnectionProperties
    {
        public ConnectionProperties()
        {

        }

        public ConnectionProperties(string addr, int port,string descr)
        {
            this.address = addr;
            this.port = port;
            this.description = descr;
        }

        private string description;

        public string Description
        {
            get { return description; }
            set { description = value; }
        }

        private string address;

        public string Address
        {
            get { return address; }
            set { address = value; }
        }
        private int port;

        public int Port
        {
            get { return port; }
            set { port = value; }
        }

        public override string ToString()
        {
            return description;
        }
    }
}
