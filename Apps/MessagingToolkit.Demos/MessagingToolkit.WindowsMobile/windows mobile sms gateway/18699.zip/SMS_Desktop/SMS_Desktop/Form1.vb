Public Class Form1
    '---the constants for the commands---
    Const VOTE_COMMAND As String = "VOTE"
    Const SEND_COMMAND As String = "SEND"

    Private WithEvents serialPort As New IO.Ports.SerialPort

    Private Sub Form1_Load( _
       ByVal sender As System.Object, _
       ByVal e As System.EventArgs) _
       Handles MyBase.Load
        '---update the progressbars---
        UpdateBars()

        '---close the serial port if open---
        If serialPort.IsOpen Then
            serialPort.Close()
        End If
        '---open the serial port to connect to server---
        Try
            With serialPort
                .PortName = "COM12"
                .BaudRate = 9600
                .Parity = IO.Ports.Parity.None
                .DataBits = 8
                .StopBits = IO.Ports.StopBits.One
                .Handshake = IO.Ports.Handshake.None
            End With
            serialPort.Open()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    '---data received from Pocket PC---
    Private Sub DataReceived( _
       ByVal sender As Object, _
       ByVal e As System.IO.Ports.SerialDataReceivedEventArgs) _
       Handles serialPort.DataReceived
        '---update it in the textbox---
        TextBox1.BeginInvoke(New _
           myDelegate(AddressOf updateTextBox), _
           New Object() {})
    End Sub

    '---delegate for updating the TextBox control---
    Public Delegate Sub myDelegate()

    '---display data received from Pocket PC---
    Public Sub updateTextBox()
        '---for receiving plan ASCII text---
        Dim data As String = serialPort.ReadLine
        '---e.g. "+123456789,VOTE A 987-65-4329"---

        '---append it to the TextBox control---
        With TextBox1
            .AppendText(data & vbCrLf)
            .ScrollToCaret()
        End With

        '---write to log file---
        WriteToLog(data)

        '---process the received data---
        ProcessData(data)
    End Sub

    Private Sub WriteToLog(ByVal str As String)
        My.Computer.FileSystem.WriteAllText("C:\SMSVotes.txt", str, True)
    End Sub

    '---tabulate the scores---
    Private Sub ProcessData(ByVal str As String)
        Dim fields() As String = str.Split(",")
        '---fields(0) is caller number---
        '---fields(1) contains the data, e.g. VOTE A 987-65-4329

        Dim subFields() As String = fields(1).Split(" ")
        '---subfields(0) is Vote, subfields(1) is choice---
        With My.Settings
            Select Case UCase(subFields(1))
                Case "A"
                    .ChoiceA += 1
                Case "B"
                    .ChoiceB += 1
                Case "C"
                    .ChoiceC += 1
                Case "D"
                    .ChoiceD += 1
            End Select
            .Save()
        End With

        '---send a reply to the user---
        SendReply(fields(0), "Thank you for your vote!")

        '---update the progress bars---
        UpdateBars()
    End Sub

    '---send message to the Pocket PC to ask it 
    ' to send a SMS to the user---
    Private Sub SendReply( _
       ByVal recipientNumber As String, _
       ByVal message As String)
        '---.e.g. "SEND:+123456789:Thank you for your vote!"
        serialPort.Write( _
           SEND_COMMAND & ":" & recipientNumber & _
           ":" & message & vbCrLf)
    End Sub

    '---update the progressbars---
    Private Sub UpdateBars()
        With My.Settings
            Label1.Text = "Choice A (" & .ChoiceA & " vote(s) )"
            ProgressBar1.Value = .ChoiceA

            Label2.Text = "Choice B (" & .ChoiceB & " vote(s) )"
            ProgressBar2.Value = .ChoiceB

            Label3.Text = "Choice C (" & .ChoiceC & " vote(s) )"
            ProgressBar3.Value = .ChoiceC

            Label4.Text = "Choice D (" & .ChoiceD & " vote(s) )"
            ProgressBar4.Value = .ChoiceD
        End With
    End Sub

    '---reset all the scores---
    Private Sub btnReset_Click( _
       ByVal sender As System.Object, _
       ByVal e As System.EventArgs) _
       Handles btnReset.Click
        With My.Settings
            .ChoiceA = 0
            .ChoiceB = 0
            .ChoiceC = 0
            .ChoiceD = 0
            .Save()
        End With
        UpdateBars()
    End Sub
End Class
