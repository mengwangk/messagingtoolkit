Imports Microsoft.WindowsMobile.PocketOutlook
Imports Microsoft.WindowsMobile.PocketOutlook.MessageInterception

Public Class Form1
    '---the constants for the commands---
    Const VOTE_COMMAND As String = "VOTE"
    Const SEND_COMMAND As String = "SEND"

    Private msgInterceptor As MessageInterceptor
    Private WithEvents serialPort As New IO.Ports.SerialPort

    '---Message format---
    ' VOTE <Choice> <SSN>
    ' e.g. VOTE A 987-65-4329

    Private Sub Form1_Load( _
       ByVal sender As System.Object, _
       ByVal e As System.EventArgs) _
       Handles MyBase.Load

        '---create an instance of the MessageInterceptor class---
        msgInterceptor = New MessageInterceptor( _
           InterceptionAction.NotifyAndDelete, True)

        '---set the filter for the message---
        msgInterceptor.MessageCondition = _
           New MessageCondition( _
           MessageProperty.Body, _
           MessagePropertyComparisonType.StartsWith, _
           VOTE_COMMAND, False)

        '---set the event handler for the message interceptor
        AddHandler msgInterceptor.MessageReceived, _
           AddressOf SMSInterceptor_MessageReceived

        '---close the serial port if open---
        If serialPort.IsOpen Then
            serialPort.Close()
        End If

        '---open the serial port to connect to server---
        Try
            With serialPort
                .PortName = "COM6"
                .BaudRate = 9600
                .Parity = IO.Ports.Parity.None
                .DataBits = 8
                .StopBits = IO.Ports.StopBits.One
                .Handshake = IO.Ports.Handshake.None
            End With
            serialPort.Open()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    '---event handler for the MessageReceived event---
    Private Sub SMSInterceptor_MessageReceived( _
       ByVal sender As Object, _
       ByVal e As MessageInterceptorEventArgs)

        '---extract the message received---
        Dim msg As SmsMessage = e.Message

        '---format as "+123456789,VOTE A 987-65-4329"---
        Dim s As String = msg.From.Name & "," & msg.Body

        '---update the textbox with the above data---
        TextBox1.BeginInvoke(New _
           myDelegate(AddressOf updateTextBox1), _
           New Object() {s})
    End Sub

    '---delegate for updating the two TextBox controls---
    Public Delegate Sub myDelegate(ByVal str As String)

    '---display received SMS data---
    Public Sub updateTextBox1(ByVal str As String)
        '---show the received data in the TextBox---
        TextBox1.Text = str & vbCrLf & TextBox1.Text

        '---Send the data to the server---
        SendDatatoServer(str)
    End Sub

    '---sends the received SMS data to the server---
    Private Sub SendDatatoServer(ByVal str As String)
        Try
            '---write to the serial port---
            serialPort.Write(str & vbCrLf)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    '---send a SMS message to a recipient---
    Private Sub SendSMS( _
       ByVal receiptnumber As String, _
       ByVal message As String)
        '---from the Microsoft.WindowsMobile.PocketOutlook namespace---

        '---compose a new SMS message---
        Dim SMS As New SmsMessage
        '---set the body of the message---
        SMS.Body = message
        '---add the recipient---
        SMS.To.Add(New Recipient(receiptnumber))
        '---send the message---
        SMS.Send()
    End Sub

    '---data received by the serial port (from server)---
    Private Sub DataReceived( _
           ByVal sender As Object, _
           ByVal e As System.IO.Ports.SerialDataReceivedEventArgs) _
           Handles serialPort.DataReceived

        Dim data As String = serialPort.ReadLine()

        '---update the textbox with the data from server---
        TextBox2.BeginInvoke(New _
           myDelegate(AddressOf updateTextBox2), _
           New Object() {data})
    End Sub

    '---update the TextBox with the data received from server---
    Public Sub updateTextBox2(ByVal str As String)
        '---show the received data in the TextBox---
        TextBox2.Text = str & vbCrLf & TextBox2.Text

        If str.StartsWith(SEND_COMMAND) Then
            Dim fields() As String = str.Split(":")
            '---.e.g. SEND:+123456789:Thank you for your vote!
            '---fields(0) is SEND, fields(1) is +123456789, 
            '---fields(2) is "Thank you for your vote!"
            '---send SMS to user---
            SendSMS(fields(1), fields(2))
        End If
    End Sub
End Class
