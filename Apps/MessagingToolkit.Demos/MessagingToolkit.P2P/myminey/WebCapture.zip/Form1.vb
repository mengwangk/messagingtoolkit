Imports System.Text.RegularExpressions

Public Class Form1

  Private Sub buttonCapture_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles buttonCapture.Click
    WebBrowser1.Navigate(textWebURL.Text)
    buttonCapture.Enabled = False
  End Sub

  Private Sub WebBrowser1_DocumentCompleted(ByVal sender As System.Object, ByVal e As System.Windows.Forms.WebBrowserDocumentCompletedEventArgs) Handles WebBrowser1.DocumentCompleted
    GetImage()
  End Sub

  Private Sub GetImage()
    If WebBrowser1.Document Is Nothing Then
      Return
    End If
    Try
      Dim scrollWidth As Integer
      Dim scrollHeight As Integer
      scrollHeight = WebBrowser1.Document.Body.ScrollRectangle.Height
      scrollWidth = WebBrowser1.Document.Body.ScrollRectangle.Width
      WebBrowser1.Size = New Size(scrollWidth, scrollHeight)
      Dim bm As New Bitmap(scrollWidth, scrollHeight)
      WebBrowser1.DrawToBitmap(bm, New Rectangle(0, 0, bm.Width, bm.Height))
      Dim SaveAsName As String
      SaveAsName = Regex.Replace(textWebURL.Text, "(\\|\/|\:|\*|\?|\""|\<|\>|\|)?", "")
      bm.Save(SaveAsName & ".png", System.Drawing.Imaging.ImageFormat.Png)
      bm.Dispose()
    Catch ex As Exception
      MessageBox.Show(ex.Message, "Exception", MessageBoxButtons.OK, MessageBoxIcon.Error)
    Finally
      '
    End Try
    buttonCapture.Enabled = True
  End Sub
End Class
