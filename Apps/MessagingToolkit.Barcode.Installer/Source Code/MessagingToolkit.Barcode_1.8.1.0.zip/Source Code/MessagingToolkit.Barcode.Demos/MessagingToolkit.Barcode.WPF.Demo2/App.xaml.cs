﻿using System.Windows;

namespace MessagingToolkit.Barcode.WPF.Demo2
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        public App()
        {

        }
    }
}
