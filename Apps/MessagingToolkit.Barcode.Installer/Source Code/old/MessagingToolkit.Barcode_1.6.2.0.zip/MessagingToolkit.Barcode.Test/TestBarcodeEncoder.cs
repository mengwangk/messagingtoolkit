﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MessagingToolkit.Barcode.Test
{
    /// <summary>
    /// Test class
    /// </summary>
    public class TestBarcodeEncoder
    {
    }
}
