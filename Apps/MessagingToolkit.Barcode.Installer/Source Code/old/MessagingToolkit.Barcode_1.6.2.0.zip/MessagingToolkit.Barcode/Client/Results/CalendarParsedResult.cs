using System;
using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;


namespace MessagingToolkit.Barcode.Client.Results
{

    /// <summary>
    /// Modified: July 07 2012
    /// </summary>
    public sealed class CalendarParsedResult : ParsedResult
    {
        private static readonly Regex DATE_TIME = new Regex("[0-9]{8}(T[0-9]{6}Z?)?"
#if !(SILVERLIGHT)
, RegexOptions.Compiled);
#else
);
#endif

        private const string DATE_FORMAT = "yyyyMMdd";

        private const string DATE_TIME_FORMAT = "yyyyMMdd'T'HHmmss";

        private readonly String summary;
        private readonly DateTime start;
        private readonly bool startAllDay;
        private readonly DateTime? end;
        private readonly bool endAllDay;
        private readonly String location;
        private readonly String organizer;
        private readonly String[] attendees;
        private readonly String description;
        private readonly double latitude;
        private readonly double longitude;

        public CalendarParsedResult(String summary,
                                    String startString,
                                    String endString,
                                    String location,
                                    String organizer,
                                    String[] attendees,
                                    String description,
                                    double latitude,
                                    double longitude)
            : base(ParsedResultType.Calendar)
        {
            this.summary = summary;
            try
            {
                this.start = ParseDate(startString);
                this.end = endString == null ? (DateTime?)null : ParseDate(endString);
            }
            catch (Exception pe)
            {
                throw new ArgumentException(pe.ToString());
            }
            this.startAllDay = startString.Length == 8;
            this.endAllDay = endString != null && endString.Length == 8;
            this.location = location;
            this.organizer = organizer;
            this.attendees = attendees;
            this.description = description;
            this.latitude = latitude;
            this.longitude = longitude;
        }

        public String Summary
        {
            get { return summary; }
        }

        /// <summary>
        /// Gets the start.
        /// </summary>
        public DateTime Start
        {
            get { return start; }
        }

        /// <summary>
        /// Determines whether [is start all day].
        /// </summary>
        /// <returns>if start time was specified as a whole day</returns>
        public bool IsStartAllDay()
        {
            return startAllDay;
        }

        /// <summary>
        /// May return null if the event has no duration.
        /// </summary>
        public DateTime? End
        {
            get { return end; }
        }

        /// <summary>
        /// Gets a value indicating whether this instance is end all day.
        /// </summary>
        /// <value>true if end time was specified as a whole day</value>
        public bool IsEndAllDay
        {
            get { return endAllDay; }
        }

        public String Location
        {
            get { return location; }
        }

        public String Organizer
        {
            get { return organizer; }
        }

        public String[] Attendees
        {
            get { return attendees; }
        }

        public String Description
        {
            get { return description; }
        }

        public double Latitude
        {
            get { return latitude; }
        }

        public double Longitude
        {
            get { return longitude; }
        }

        public override String DisplayResult
        {
            get
            {
                var result = new StringBuilder(100);
                MaybeAppend(summary, result);
                MaybeAppend(Format(startAllDay, start), result);
                MaybeAppend(Format(endAllDay, end), result);
                MaybeAppend(location, result);
                MaybeAppend(organizer, result);
                MaybeAppend(attendees, result);
                MaybeAppend(description, result);
                return result.ToString();
            }
        }

        /// <summary>
        /// Parses a string as a date. RFC 2445 allows the start and end fields to be of type DATE (e.g. 20081021)
        /// or DATE-TIME (e.g. 20081021T123000 for local time, or 20081021T123000Z for UTC).
        /// </summary>
        /// <param name="when">The string to parse</param>
        /// <returns></returns>
        /// <exception cref="ArgumentException">if not a date formatted string</exception>
        private static DateTime ParseDate(String when)
        {
            if (!DATE_TIME.Match(when).Success)
            {
                throw new ArgumentException(String.Format("no date Format: {0}", when));
            }
            if (when.Length == 8)
            {
                // Show only year/month/day
                return DateTime.ParseExact(when, DATE_FORMAT, CultureInfo.InvariantCulture);
            }
            else
            {
                // The when string can be local time, or UTC if it ends with a Z
                DateTime date;
                if (when.Length == 16 && when[15] == 'Z')
                {
                    date = DateTime.ParseExact(when.Substring(0, 15), DATE_TIME_FORMAT, CultureInfo.InvariantCulture);
                    date = TimeZoneInfo.ConvertTime(date, TimeZoneInfo.Local);
                }
                else
                {
                    date = DateTime.ParseExact(when, DATE_TIME_FORMAT, CultureInfo.InvariantCulture);
                }
                return date;
            }
        }

        private static String Format(bool allDay, DateTime? date)
        {
            if (date == null)
            {
                return null;
            }
            if (allDay)
                return date.Value.ToString("D", CultureInfo.CurrentCulture);
            return date.Value.ToString("F", CultureInfo.CurrentCulture);
        }
    }
}