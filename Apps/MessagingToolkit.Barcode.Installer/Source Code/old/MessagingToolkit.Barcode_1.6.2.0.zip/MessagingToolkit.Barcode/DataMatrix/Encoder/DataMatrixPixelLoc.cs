﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MessagingToolkit.Barcode.DataMatrix.Encoder
{
    internal struct DataMatrixPixelLoc
    {
        #region Properties

        internal int X { get; set; }

        internal int Y { get; set; }

        #endregion
    }
}
