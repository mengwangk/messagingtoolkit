using MessagingToolkit.Barcode.Common;
using System.Collections.Generic;


namespace MessagingToolkit.Barcode.QRCode
{
    /// <summary>
    /// This implementation can detect and decode QR Codes in an image.
    /// </summary>
    ///
    public class QRCodeDecoder : IDecoder
    {

        public QRCodeDecoder()
        {
            this.decoder = new MessagingToolkit.Barcode.QRCode.Decoder.Decoder();
        }

        private static readonly ResultPoint[] NO_POINTS = new ResultPoint[0];

        private readonly MessagingToolkit.Barcode.QRCode.Decoder.Decoder decoder;

        protected internal MessagingToolkit.Barcode.QRCode.Decoder.Decoder GetDecoder()
        {
            return decoder;
        }

        /// <summary>
        /// Locates and decodes a QR code in an image.
        /// </summary>
        ///
        /// <returns>a String representing the content encoded by the QR code</returns>
        /// <exception cref="NotFoundException">if a QR code cannot be found</exception>
        /// <exception cref="FormatException">if a QR code cannot be decoded</exception>
        /// <exception cref="ChecksumException">if error correction fails</exception>
        public virtual Result Decode(BinaryBitmap image)
        {
            return Decode(image, null);
        }

        public virtual Result Decode(BinaryBitmap image, Dictionary<DecodeOptions, object> decodingOptions)
        {
            DecoderResult decoderResult;
            ResultPoint[] points;
            if (decodingOptions != null && decodingOptions.ContainsKey(DecodeOptions.PureBarcode))
            {
                BitMatrix bits = ExtractPureBits(image.BlackMatrix);
                decoderResult = decoder.Decode(bits, decodingOptions);
                points = NO_POINTS;
            }
            else
            {
                DetectorResult detectorResult = new MessagingToolkit.Barcode.QRCode.Detector.Detector(image.BlackMatrix).Detect(decodingOptions);
                decoderResult = decoder.Decode(detectorResult.Bits, decodingOptions);
                points = detectorResult.Points;
            }

            Result result = new Result(decoderResult.Text, decoderResult.RawBytes, points, MessagingToolkit.Barcode.BarcodeFormat.QRCode);
            if (decoderResult.ByteSegments != null)
            {
                result.PutMetadata(MessagingToolkit.Barcode.ResultMetadataType.ByteSegments, decoderResult.ByteSegments);
            }
            if (decoderResult.ECLevel != null)
            {
                result.PutMetadata(MessagingToolkit.Barcode.ResultMetadataType.ErrorCorrectionLevel, decoderResult.ECLevel.ToString());
            }
            return result;
        }

        public virtual void Reset()
        {
            // do nothing
        }

        /// <summary>
        /// This method detects a code in a "pure" image -- that is, pure monochrome image
        /// which contains only an unrotated, unskewed, image of a code, with some white border
        /// around it. This is a specialized method that works exceptionally fast in this special
        /// case.
        /// </summary>
        ///
        /// <seealso cref="M:MessagingToolkit.Barcode.QRCode.PDF417Reader.ExtractPureBits(null)"/>
        /// <seealso cref="M:MessagingToolkit.Barcode.QRCode.DataMatrixReader.ExtractPureBits(null)"/>
        private static BitMatrix ExtractPureBits(BitMatrix image)
        {

            int[] leftTopBlack = image.GetTopLeftOnBit();
            int[] rightBottomBlack = image.GetBottomRightOnBit();
            if (leftTopBlack == null || rightBottomBlack == null)
            {
                throw NotFoundException.Instance;
            }

            int moduleSize = ModuleSize(leftTopBlack, image);

            int top = leftTopBlack[1];
            int bottom = rightBottomBlack[1];
            int left = leftTopBlack[0];
            int right = rightBottomBlack[0];

            int matrixWidth = (right - left + 1) / moduleSize;
            int matrixHeight = (bottom - top + 1) / moduleSize;
            if (matrixWidth == 0 || matrixHeight == 0)
            {
                throw NotFoundException.Instance;
            }
            if (matrixHeight != matrixWidth)
            {
                // Only possibly decode square regions
                throw NotFoundException.Instance;
            }

            // Push in the "border" by half the module width so that we start
            // sampling in the middle of the module. Just in case the image is a
            // little off, this will help recover.
            int nudge = moduleSize >> 1;
            top += nudge;
            left += nudge;

            // Now just read off the bits
            BitMatrix bits = new BitMatrix(matrixWidth, matrixHeight);
            for (int y = 0; y < matrixHeight; y++)
            {
                int iOffset = top + y * moduleSize;
                for (int x = 0; x < matrixWidth; x++)
                {
                    if (image.Get(left + x * moduleSize, iOffset))
                    {
                        bits.Set(x, y);
                    }
                }
            }
            return bits;
        }

        private static int ModuleSize(int[] leftTopBlack, BitMatrix image)
        {
            int height = image.Height;
            int width = image.Width;
            int x = leftTopBlack[0];
            int y = leftTopBlack[1];
            while (x < width && y < height && image.Get(x, y))
            {
                x++;
                y++;
            }
            if (x == width || y == height)
            {
                throw NotFoundException.Instance;
            }

            int moduleSize = x - leftTopBlack[0];
            if (moduleSize == 0)
            {
                throw NotFoundException.Instance;
            }
            return moduleSize;
        }

    }
}
