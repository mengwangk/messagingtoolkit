//===============================================================================
// Copyright � TWIT88.COM.  All rights reserved.
//
// This file is part of Open Source Messaging Library.
//
// Open Source Messaging Library is free software: you can redistribute it 
// and/or modify it under the terms of the GNU General Public License version 3.
//
// Open Source Messaging Library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this software.  If not, see <http://www.gnu.org/licenses/>.
//===============================================================================

using System;
using ResultPoint = MessagingToolkit.Barcode.ResultPoint;

namespace MessagingToolkit.Barcode.QRCode.Detector
{
	
	/// <summary>
    /// Encapsulates an alignment pattern, which are the smaller square patterns found in
	/// all but the simplest QR Codes.
	/// </summary>
	public sealed class AlignmentPattern:ResultPoint
	{
        private float estimatedModuleSize;

        /// <summary>
        /// Initializes a new instance of the <see cref="AlignmentPattern"/> class.
        /// </summary>
        /// <param name="posX">The pos X.</param>
        /// <param name="posY">The pos Y.</param>
        /// <param name="estimatedModuleSize">Size of the estimated module.</param>
		internal AlignmentPattern(float posX, float posY, float estimatedModuleSize):base(posX, posY)
		{
			this.estimatedModuleSize = estimatedModuleSize;
		}

        /// <summary>
        /// 	<p>Determines if this alignment pattern "about equals" an alignment pattern at the stated
        /// position and size -- meaning, it is at nearly the same center with nearly the same size.</p>
        /// </summary>
        /// <param name="moduleSize">Size of the module.</param>
        /// <param name="i">The i.</param>
        /// <param name="j">The j.</param>
        /// <returns></returns>
		internal bool AboutEquals(float moduleSize, float i, float j)
		{
			if (System.Math.Abs(i - Y) <= moduleSize && System.Math.Abs(j - X) <= moduleSize)
			{
				float moduleSizeDiff = System.Math.Abs(moduleSize - estimatedModuleSize);
				return moduleSizeDiff <= 1.0f || moduleSizeDiff / estimatedModuleSize <= 1.0f;
			}
			return false;
		}
	}
}