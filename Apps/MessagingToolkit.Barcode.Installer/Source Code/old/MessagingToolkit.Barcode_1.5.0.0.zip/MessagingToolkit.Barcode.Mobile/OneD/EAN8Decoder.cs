//===============================================================================
// Copyright � TWIT88.COM.  All rights reserved.
//
// This file is part of Open Source Messaging Library.
//
// Open Source Messaging Library is free software: you can redistribute it 
// and/or modify it under the terms of the GNU General Public License version 3.
//
// Open Source Messaging Library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this software.  If not, see <http://www.gnu.org/licenses/>.
//===============================================================================

using System;

using BarcodeFormat = MessagingToolkit.Barcode.BarcodeFormat;
using BarcodeDecoderException = MessagingToolkit.Barcode.BarcodeDecoderException;
using BitArray = MessagingToolkit.Barcode.Common.BitArray;

namespace MessagingToolkit.Barcode.OneD
{

    /// <summary>
    /// 	<p>Implements decoding of the EAN-8 format.</p>
    /// </summary>
	public sealed class EAN8Decoder:UPCEANDecoder
	{
        private int[] decodeMiddleCounters;
	
		override internal BarcodeFormat BarcodeFormat
		{
			get
			{
				return BarcodeFormat.EAN8;
			}
			
		}
		
		
		public EAN8Decoder()
		{
			decodeMiddleCounters = new int[4];
		}
		
		protected internal override int DecodeMiddle(BitArray row, int[] startRange, System.Text.StringBuilder result)
		{
			int[] counters = decodeMiddleCounters;
			counters[0] = 0;
			counters[1] = 0;
			counters[2] = 0;
			counters[3] = 0;
			int end = row.Size;
			int rowOffset = startRange[1];
			
			for (int x = 0; x < 4 && rowOffset < end; x++)
			{
				int bestMatch = DecodeDigit(row, counters, rowOffset, LPatterns);
				result.Append((char) ('0' + bestMatch));
				for (int i = 0; i < counters.Length; i++)
				{
					rowOffset += counters[i];
				}
			}
			
			int[] middleRange = FindGuardPattern(row, rowOffset, true, MiddlePattern);
			rowOffset = middleRange[1];
			
			for (int x = 0; x < 4 && rowOffset < end; x++)
			{
				int bestMatch = DecodeDigit(row, counters, rowOffset, LPatterns);
				result.Append((char) ('0' + bestMatch));
				for (int i = 0; i < counters.Length; i++)
				{
					rowOffset += counters[i];
				}
			}
			
			return rowOffset;
		}
	}
}