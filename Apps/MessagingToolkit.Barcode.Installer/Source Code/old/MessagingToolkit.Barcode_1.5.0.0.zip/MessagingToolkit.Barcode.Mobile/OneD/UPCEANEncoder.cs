using MessagingToolkit.Barcode.Common;

using System;
using System.Collections.Generic;

namespace MessagingToolkit.Barcode.OneD
{
    /// <summary>
    /// <p>Encapsulates functionality and implementation that is common to UPC and EAN families
    /// of one-dimensional barcodes.</p>
    /// </summary>
    public abstract class UPCEANEncoder : IEncoder
    {

        public virtual BitMatrix Encode(String contents, BarcodeFormat format, int width, int height)
        {
            return Encode(contents, format, width, height, null);
        }

        public virtual BitMatrix Encode(String contents, BarcodeFormat format, int width, int height, Dictionary<EncodeOptions, object> encodingOptions)
        {
            if (contents == null || contents.Length == 0)
            {
                throw new ArgumentException("Found empty contents");
            }

            if (width < 0 || height < 0)
            {
                throw new ArgumentException("Requested dimensions are too small: " + width + 'x' + height);
            }

            byte[] code = Encode(contents);
            return RenderResult(code, width, height);
        }


        /// <returns>a byte array of horizontal pixels (0 = white, 1 = black)</returns>
        private static BitMatrix RenderResult(byte[] code, int width, int height)
        {
            int inputWidth = code.Length;
            // Add quiet zone on both sides
            int fullWidth = inputWidth + (UPCEANDecoder.StartEndPattern.Length << 1);
            int outputWidth = Math.Max(width, fullWidth);
            int outputHeight = Math.Max(1, height);

            int multiple = outputWidth / fullWidth;
            int leftPadding = (outputWidth - (inputWidth * multiple)) / 2;

            BitMatrix output = new BitMatrix(outputWidth, outputHeight);
            for (int inputX = 0, outputX = leftPadding; inputX < inputWidth; inputX++, outputX += multiple)
            {
                if (code[inputX] == 1)
                {
                    output.SetRegion(outputX, 0, multiple, outputHeight);
                }
            }
            return output;
        }

        /// <summary>
        /// Appends the given pattern to the target array starting at pos.
        /// </summary>
        ///
        /// <param name="startColor">starting color - 0 for white, 1 for black</param>
        /// <returns>the number of elements added to target.</returns>
        protected static internal int AppendPattern(byte[] target, int pos, int[] pattern, int startColor)
        {
            if (startColor != 0 && startColor != 1)
            {
                throw new ArgumentException(
                        "startColor must be either 0 or 1, but got: " + startColor);
            }

            byte color = (byte)startColor;
            int numAdded = 0;
            for (int i = 0; i < pattern.Length; i++)
            {
                for (int j = 0; j < pattern[i]; j++)
                {
                    target[pos] = color;
                    pos += 1;
                    numAdded += 1;
                }
                color ^= 1; // flip color after each segment
            }
            return numAdded;
        }


        /// <returns>a byte array of horizontal pixels (0 = white, 1 = black)</returns>
        public abstract byte[] Encode(String contents);

    }
}
