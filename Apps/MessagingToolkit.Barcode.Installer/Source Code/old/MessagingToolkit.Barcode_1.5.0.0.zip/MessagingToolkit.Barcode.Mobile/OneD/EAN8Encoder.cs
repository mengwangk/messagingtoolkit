//===============================================================================
// Copyright � TWIT88.COM.  All rights reserved.
//
// This file is part of Open Source Messaging Library.
//
// Open Source Messaging Library is free software: you can redistribute it 
// and/or modify it under the terms of the GNU General Public License version 3.
//
// Open Source Messaging Library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this software.  If not, see <http://www.gnu.org/licenses/>.
//===============================================================================

using System;
using System.Collections.Generic;
using BarcodeFormat = MessagingToolkit.Barcode.BarcodeFormat;
using WriterException = MessagingToolkit.Barcode.BarcodeEncoderException;
using BitMatrix = MessagingToolkit.Barcode.Common.BitMatrix;

namespace MessagingToolkit.Barcode.OneD
{

    /// <summary>
    /// This object renders an EAN8 code as a BitMatrix 2D array of greyscale
    /// values.
    /// </summary>
	public sealed class EAN8Encoder:UPCEANEncoder
	{
		
		private const int CodeWidth = 3 + (7 * 4) + 5 + (7 * 4) + 3; // end guard

        public override BitMatrix Encode(string contents, BarcodeFormat format, int width, int height, Dictionary<EncodeOptions, object> encodingOptions)
		{
			if (format != BarcodeFormat.EAN8)
			{
				throw new ArgumentException("Can only encode EAN_8, but got " + format);
			}
			
			return base.Encode(contents, format, width, height, encodingOptions);
		}

        /// <summary>
        /// </summary>
        /// <param name="contents"></param>
        /// <returns>
        /// a byte array of horizontal pixels (0 = white, 1 = black)
        /// </returns>
		public override byte[] Encode(string contents)
		{
			if (contents.Length != 8)
			{
				throw new ArgumentException("Requested contents should be 8 digits long, but got " + contents.Length);
			}
			
			byte[] result = new byte[CodeWidth];
			int pos = 0;
			
			pos += AppendPattern(result, pos, UPCEANDecoder.StartEndPattern, 1);
			
			for (int i = 0; i <= 3; i++)
			{
				int digit = System.Int32.Parse(contents.Substring(i, (i + 1) - (i)));
				pos += AppendPattern(result, pos, UPCEANDecoder.LPatterns[digit], 0);
			}
			
			pos += AppendPattern(result, pos, UPCEANDecoder.MiddlePattern, 0);
			
			for (int i = 4; i <= 7; i++)
			{
				int digit = Int32.Parse(contents.Substring(i, (i + 1) - (i)));
				pos += AppendPattern(result, pos, UPCEANDecoder.LPatterns[digit], 1);
			}
			pos += AppendPattern(result, pos, UPCEANDecoder.StartEndPattern, 1);
			
			return result;
		}
	}
}