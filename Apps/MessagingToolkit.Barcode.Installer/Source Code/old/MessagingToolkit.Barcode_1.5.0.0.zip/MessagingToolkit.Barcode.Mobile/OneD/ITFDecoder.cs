//===============================================================================
// Copyright � TWIT88.COM.  All rights reserved.
//
// This file is part of Open Source Messaging Library.
//
// Open Source Messaging Library is free software: you can redistribute it 
// and/or modify it under the terms of the GNU General Public License version 3.
//
// Open Source Messaging Library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this software.  If not, see <http://www.gnu.org/licenses/>.
//===============================================================================

using System;
using System.Text;
using System.Collections.Generic;

using BarcodeFormat = MessagingToolkit.Barcode.BarcodeFormat;
using DecodeHintType = MessagingToolkit.Barcode.DecodeOptions;
using BarcodeDecoderException = MessagingToolkit.Barcode.BarcodeDecoderException;
using Result = MessagingToolkit.Barcode.Result;
using ResultPoint = MessagingToolkit.Barcode.ResultPoint;
using BitArray = MessagingToolkit.Barcode.Common.BitArray;
using MessagingToolkit.Barcode.Helper;

namespace MessagingToolkit.Barcode.OneD
{

    /// <summary>
    /// 	<p>Implements decoding of the ITF format.</p>
    /// 	<p>"ITF" stands for Interleaved Two of Five. This Reader will scan ITF barcode with 6, 10 or 14
    /// digits. The checksum is optional and is not applied by this Reader. The consumer of the decoded
    /// value will have to apply a checksum if required.</p>
    /// 	<p><a href="http://en.wikipedia.org/wiki/Interleaved_2_of_5">http://en.wikipedia.org/wiki/Interleaved_2_of_5</a>
    /// is a great reference for Interleaved 2 of 5 information.</p>
    /// </summary>
  	public sealed class ITFDecoder:OneDDecoder
	{
		private static readonly int MaxAvgVariance = (int) (PatternMatchResultScaleFactor * 0.42f);
		private static readonly int MaxIndividualVariance = (int) (PatternMatchResultScaleFactor * 0.8f);
		
		private const int W = 3; // Pixel width of a wide line
		private const int N = 1; // Pixed width of a narrow line

        private static readonly int[] DefaultAllowedLengths = new int[] { 6, 8, 10, 12, 14, 16, 20, 24, 44 };
		
		// Stores the actual narrow line width of the image being decoded.
		private int narrowLineWidth = - 1;
		
		/// <summary> 
        /// Start/end guard pattern.
		/// 
		/// Note: The end pattern is reversed because the row is reversed before
		/// searching for the END_PATTERN
		/// </summary>
		private static readonly int[] StartPattern = new int[]{N, N, N, N};
		
        private static readonly int[] EndPatternReversed = new int[]{N, N, W};
		
		/// <summary> Patterns of Wide / Narrow lines to indicate each digit</summary>
		internal static readonly int[][] Patterns = new int[][]{new int[]{N, N, W, W, N}, new int[]{W, N, N, N, W}, new int[]{N, W, N, N, W}, new int[]{W, W, N, N, N}, new int[]{N, N, W, N, W}, new int[]{W, N, W, N, N}, new int[]{N, W, W, N, N}, new int[]{N, N, N, W, W}, new int[]{W, N, N, W, N}, new int[]{N, W, N, W, N}};

        /// <summary>
        /// 	<p>Attempts to decode a one-dimensional barcode format given a single row of
        /// an image.</p>
        /// </summary>
        /// <param name="rowNumber">row number from top of the row</param>
        /// <param name="row">the black/white pixel data of the row</param>
        /// <param name="decodingOptions">decode hints</param>
        /// <returns>
        /// {@link Result} containing encoded string and start/end of barcode
        /// </returns>
        public override Result DecodeRow(int rowNumber, BitArray row, Dictionary<DecodeOptions, object> decodingOptions)
		{
			
			// Find out where the Middle section (payload) starts & ends
			int[] startRange = DecodeStart(row);
			int[] endRange = DecodeEnd(row);
			
			System.Text.StringBuilder result = new System.Text.StringBuilder(20);
			DecodeMiddle(row, startRange[1], endRange[0], result);
			string resultString = result.ToString();
			
			int[] allowedLengths = null;
			if (decodingOptions != null)
			{
				allowedLengths = (int[]) BarcodeHelper.GetDecodeOptionType(decodingOptions,DecodeOptions.AllowedLengths);
			}
			if (allowedLengths == null)
			{
				allowedLengths = DefaultAllowedLengths;
			}
			
			// To avoid false positives with 2D barcodes (and other patterns), make
			// an assumption that the decoded string must be 6, 10 or 14 digits.
			int length = resultString.Length;
			bool lengthOK = false;
			for (int i = 0; i < allowedLengths.Length; i++)
			{
				if (length == allowedLengths[i])
				{
					lengthOK = true;
					break;
				}
			}
			if (!lengthOK)
			{
				throw FormatException.Instance;
			}
		
            return new Result(resultString, null, new ResultPoint[]{new ResultPoint(startRange[1], (float) rowNumber), new ResultPoint(endRange[0], (float) rowNumber)}, 
                BarcodeFormat.ITF14);
		}

        /// <summary>
        /// Decodes the middle.
        /// </summary>
        /// <param name="row">row of black/white values to search</param>
        /// <param name="payloadStart">offset of start pattern</param>
        /// <param name="payloadEnd">The payload end.</param>
        /// <param name="resultString">{@link StringBuffer} to append decoded chars to</param>
		private static void  DecodeMiddle(BitArray row, int payloadStart, int payloadEnd, System.Text.StringBuilder resultString)
		{
			
			// Digits are interleaved in pairs - 5 black lines for one digit, and the
			// 5
			// interleaved white lines for the second digit.
			// Therefore, need to scan 10 lines and then
			// split these into two arrays
			int[] counterDigitPair = new int[10];
			int[] counterBlack = new int[5];
			int[] counterWhite = new int[5];
			
			while (payloadStart < payloadEnd)
			{
				
				// Get 10 runs of black/white.
				RecordPattern(row, payloadStart, counterDigitPair);
				// Split them into each array
				for (int k = 0; k < 5; k++)
				{
					int twoK = k << 1;
					counterBlack[k] = counterDigitPair[twoK];
					counterWhite[k] = counterDigitPair[twoK + 1];
				}
				
				int bestMatch = DecodeDigit(counterBlack);
				resultString.Append((char) ('0' + bestMatch));
				bestMatch = DecodeDigit(counterWhite);
				resultString.Append((char) ('0' + bestMatch));
				
				for (int i = 0; i < counterDigitPair.Length; i++)
				{
					payloadStart += counterDigitPair[i];
				}
			}
		}

        /// <summary>
        /// Identify where the start of the middle / payload section starts.
        /// </summary>
        /// <param name="row">row of black/white values to search</param>
        /// <returns>
        /// Array, containing index of start of 'start block' and end of
        /// 'start block'
        /// </returns>
		internal int[] DecodeStart(BitArray row)
		{
			int endStart = SkipWhiteSpace(row);
			int[] startPattern = FindGuardPattern(row, endStart, StartPattern);
			
			// Determine the width of a narrow line in pixels. We can do this by
			// getting the width of the start pattern and dividing by 4 because its
			// made up of 4 narrow lines.
			this.narrowLineWidth = (startPattern[1] - startPattern[0]) >> 2;
			
			ValidateQuietZone(row, startPattern[0]);
			
			return startPattern;
		}

        /// <summary>
        /// The start and end patterns must be pre/post fixed by a quiet zone. This
        /// zone must be at least 10 times the width of a narrow line.  Scan back until
        /// we either get to the start of the barcode or match the necessary number of
        /// quiet zone pixels.
        /// Note: Its assumed the row is reversed when using this method to find
        /// quiet zone after the end pattern.
        /// ref: http://www.barcode-1.net/i25code.html
        /// </summary>
        /// <param name="row">bit array representing the scanned barcode.</param>
        /// <param name="startPattern">index into row of the start or end pattern.</param>
		private void  ValidateQuietZone(BitArray row, int startPattern)
		{
			
			int quietCount = this.narrowLineWidth * 10; // expect to find this many pixels of quiet zone
			
			for (int i = startPattern - 1; quietCount > 0 && i >= 0; i--)
			{
				if (row.GetValue(i))
				{
					break;
				}
				quietCount--;
			}
			if (quietCount != 0)
			{
				// Unable to find the necessary number of quiet zone pixels.
				throw NotFoundException.Instance;
			}
		}

        /// <summary>
        /// Skip all whitespace until we get to the first black line.
        /// </summary>
        /// <param name="row">row of black/white values to search</param>
        /// <returns>index of the first black line.</returns>
        /// <throws>  ReaderException Throws exception if no black lines are found in the row </throws>
		private static int SkipWhiteSpace(BitArray row)
		{
			int width = row.Size;
			int endStart = 0;
			while (endStart < width)
			{
				if (row.GetValue(endStart))
				{
					break;
				}
				endStart++;
			}
			if (endStart == width)
			{
				throw NotFoundException.Instance;
			}
			
			return endStart;
		}
		
		/// <summary> Identify where the end of the middle / payload section ends.
		/// 
		/// </summary>
		/// <param name="row">row of black/white values to search
		/// </param>
		/// <returns> Array, containing index of start of 'end block' and end of 'end
		/// block'
		/// </returns>
		internal int[] DecodeEnd(BitArray row)
		{
			
			// For convenience, reverse the row and then
			// search from 'the start' for the end block
			row.Reverse();
			try
			{
				int endStart = SkipWhiteSpace(row);
				int[] endPattern = FindGuardPattern(row, endStart, EndPatternReversed);
				
				// The start & end patterns must be pre/post fixed by a quiet zone. This
				// zone must be at least 10 times the width of a narrow line.
				// ref: http://www.barcode-1.net/i25code.html
				ValidateQuietZone(row, endPattern[0]);
				
				// Now recalculate the indices of where the 'endblock' starts & stops to
				// accommodate
				// the reversed nature of the search
				int temp = endPattern[0];
				endPattern[0] = row.Size - endPattern[1];
                endPattern[1] = row.Size - temp;
				
				return endPattern;
			}
			finally
			{
				// Put the row back the right way.
				row.Reverse();
			}
		}

        /// <summary>
        /// Finds the guard pattern.
        /// </summary>
        /// <param name="row">row of black/white values to search</param>
        /// <param name="rowOffset">position to start search</param>
        /// <param name="pattern">pattern of counts of number of black and white pixels that are
        /// being searched for as a pattern</param>
        /// <returns>
        /// start/end horizontal offset of guard pattern, as an array of two
        /// ints
        /// </returns>
        /// <throws>  ReaderException if pattern is not found </throws>
		private static int[] FindGuardPattern(BitArray row, int rowOffset, int[] pattern)
		{
			
			// TODO: This is very similar to implementation in UPCEANReader. Consider if they can be
			// merged to a single method.
			int patternLength = pattern.Length;
			int[] counters = new int[patternLength];
			int width = row.Size;
			bool isWhite = false;
			
			int counterPosition = 0;
			int patternStart = rowOffset;
			for (int x = rowOffset; x < width; x++)
			{
				bool pixel = row.GetValue(x);
				if (pixel ^ isWhite)
				{
					counters[counterPosition]++;
				}
				else
				{
					if (counterPosition == patternLength - 1)
					{
						if (PatternMatchVariance(counters, pattern, MaxIndividualVariance) < MaxAvgVariance)
						{
							return new int[]{patternStart, x};
						}
						patternStart += counters[0] + counters[1];
						for (int y = 2; y < patternLength; y++)
						{
							counters[y - 2] = counters[y];
						}
						counters[patternLength - 2] = 0;
						counters[patternLength - 1] = 0;
						counterPosition--;
					}
					else
					{
						counterPosition++;
					}
					counters[counterPosition] = 1;
					isWhite = !isWhite;
				}
			}
			throw NotFoundException.Instance;
		}

        /// <summary>
        /// Attempts to decode a sequence of ITF black/white lines into single
        /// digit.
        /// </summary>
        /// <param name="counters">the counts of runs of observed black/white/black/... values</param>
        /// <returns>The decoded digit</returns>
		private static int DecodeDigit(int[] counters)
		{
			
			int bestVariance = MaxAvgVariance; // worst variance we'll accept
			int bestMatch = - 1;
			int max = Patterns.Length;
			for (int i = 0; i < max; i++)
			{
				int[] pattern = Patterns[i];
				int variance = PatternMatchVariance(counters, pattern, MaxIndividualVariance);
				if (variance < bestVariance)
				{
					bestVariance = variance;
					bestMatch = i;
				}
			}
			if (bestMatch >= 0)
			{
				return bestMatch;
			}
			else
			{
				throw NotFoundException.Instance;
			}
		}
	}
}