//===============================================================================
// Copyright � TWIT88.COM.  All rights reserved.
//
// This file is part of Open Source Messaging Library.
//
// Open Source Messaging Library is free software: you can redistribute it 
// and/or modify it under the terms of the GNU General Public License version 3.
//
// Open Source Messaging Library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this software.  If not, see <http://www.gnu.org/licenses/>.
//===============================================================================

using System;
using System.Text;
using System.Collections.Generic;
using BarcodeFormat = MessagingToolkit.Barcode.BarcodeFormat;
using BarcodeDecoderException = MessagingToolkit.Barcode.BarcodeDecoderException;
using Result = MessagingToolkit.Barcode.Result;
using ResultPoint = MessagingToolkit.Barcode.ResultPoint;
using BitArray = MessagingToolkit.Barcode.Common.BitArray;

namespace MessagingToolkit.Barcode.OneD
{
	
	/// <summary>
    /// Decodes Code 128 barcodes. 
	/// </summary>
	public sealed class Code128Decoder:OneDDecoder
	{
        internal static readonly int[][] CodePatterns = new int[][]{new int[]{2, 1, 2, 2, 2, 2}, new int[]{2, 2, 2, 1, 2, 2}, new int[]{2, 2, 2, 2, 2, 1}, new int[]{1, 2, 1, 2, 2, 3}, new int[]{1, 2, 1, 3, 2, 2}, new int[]{1, 3, 1, 2, 2, 2}, new int[]{1, 2, 2, 2, 1, 3}, new int[]{1, 2, 2, 3, 1, 2}, new int[]{1, 3, 2, 2, 1, 2}, new int[]{2, 2, 1, 2, 1, 3}, new int[]{2, 2, 1, 3, 1, 2}, new int[]{2, 3, 1, 2, 1, 2}, new int[]{1, 1, 2, 2, 3, 2}, new int[]{1, 2, 2, 1, 3, 2}, new int[]{1, 2, 2, 2, 3, 1}, new int[]{1, 1, 3, 2, 2, 2}, new int[]{1, 2, 3, 1, 2, 2}, new int[]{1, 2, 3, 2, 2, 1}, new int[]{2, 2, 3, 2, 1, 1}, new int[]{2, 2, 1, 1, 3, 2}, new int[]{2, 2, 1, 2, 3, 1}, new int[]{2, 1, 3, 2, 1, 2}, new int[]{2, 2, 3, 1, 1, 2}, new int[]{3, 1, 2, 1, 3, 1}, new int[]{3, 1, 1, 2, 2, 2}, new int[]{3, 2, 1, 1, 2, 2}, new int[]{3, 2, 1, 2, 2, 1}, new int[]{3, 1, 2, 2, 1, 2}, new int[]{3, 2, 2, 1, 1, 2}, new int[]{3, 2, 2, 2, 1, 1}, new int[]{2, 1, 2, 1, 2, 3}, new int[]{2, 1, 2, 3, 2, 1}, new int[]{2, 3, 2, 1, 2, 1}, new int[]{1, 1, 1, 3, 2, 3}, new int[]{1, 3, 1, 1, 2, 3}, new int[]{1, 3, 1, 3, 2, 1}, new int[]{1, 1, 2, 3, 1, 3}, new int[]{1, 3, 2, 1, 1, 3}, new int[]{1, 3, 2, 3, 1, 1}, new int[]{2, 1, 1, 3, 1, 3}, new int[]{2, 3, 1, 1, 1, 3}, new int[]{2, 3, 1, 3, 1, 1}, new int[]{1, 1, 2, 1, 3, 3}, new int[]{1, 1, 2, 3, 3, 1}, new int[]{1, 3, 2, 1, 3, 1}, new int[]{1, 1, 3, 1, 2, 3}, new int[]{1, 1, 3, 3, 2, 1}, new int[]{1, 3, 3, 1, 2, 1}, new int[]{3, 1, 3, 1, 2, 1}, new int[]{2, 1, 1, 3, 3, 1}, new int[]{2, 3, 1, 1, 3, 1}, new int[]{2, 1, 3, 1, 1, 3}, new int[]{2, 1, 3, 3, 1, 1}, new int[]{2, 1, 3, 1, 3, 1}, new int[]{3, 1, 1, 1, 2, 3}, new int[]{3, 1, 1, 3, 2, 1}, new int[]{3, 3, 1, 1, 2, 1}, new int[]{3, 1, 2, 1, 1, 3}, new int[]{3, 1, 2, 3, 1, 1}, new int[]{3, 3, 2, 1, 1, 1}, new int[]{3, 1, 4, 1, 1, 1}, new int[]{2, 2, 1, 4, 1, 1}, new int[]{4, 3, 1, 1, 1, 1}, new int[]{1, 1, 1, 2, 2, 4}, new int[]{1, 1, 1, 4, 2, 2}, new int[]{1, 2, 1, 1, 2, 4}, new int[]{1, 2, 1, 4, 2, 1}, new int[]{1, 4, 1, 1, 2, 2}, new 
			int[]{1, 4, 1, 2, 2, 1}, new int[]{1, 1, 2, 2, 1, 4}, new int[]{1, 1, 2, 4, 1, 2}, new int[]{1, 2, 2, 1, 1, 4}, new int[]{1, 2, 2, 4, 1, 1}, new int[]{1, 4, 2, 1, 1, 2}, new int[]{1, 4, 2, 2, 1, 1}, new int[]{2, 4, 1, 2, 1, 1}, new int[]{2, 2, 1, 1, 1, 4}, new int[]{4, 1, 3, 1, 1, 1}, new int[]{2, 4, 1, 1, 1, 2}, new int[]{1, 3, 4, 1, 1, 1}, new int[]{1, 1, 1, 2, 4, 2}, new int[]{1, 2, 1, 1, 4, 2}, new int[]{1, 2, 1, 2, 4, 1}, new int[]{1, 1, 4, 2, 1, 2}, new int[]{1, 2, 4, 1, 1, 2}, new int[]{1, 2, 4, 2, 1, 1}, new int[]{4, 1, 1, 2, 1, 2}, new int[]{4, 2, 1, 1, 1, 2}, new int[]{4, 2, 1, 2, 1, 1}, new int[]{2, 1, 2, 1, 4, 1}, new int[]{2, 1, 4, 1, 2, 1}, new int[]{4, 1, 2, 1, 2, 1}, new int[]{1, 1, 1, 1, 4, 3}, new int[]{1, 1, 1, 3, 4, 1}, new int[]{1, 3, 1, 1, 4, 1}, new int[]{1, 1, 4, 1, 1, 3}, new int[]{1, 1, 4, 3, 1, 1}, new int[]{4, 1, 1, 1, 1, 3}, new int[]{4, 1, 1, 3, 1, 1}, new int[]{1, 1, 3, 1, 4, 1}, new int[]{1, 1, 4, 1, 3, 1}, new int[]{3, 1, 1, 1, 4, 1}, new int[]{4, 1, 1, 1, 3, 1}, new int[]{2, 1, 1, 4, 1, 2}, new int[]{2, 1, 1, 2, 1, 4}, new int[]{2, 1, 1, 2, 3, 2}, new int[]{2, 3, 3, 1, 1, 1, 2}};
		
		private static readonly int MaxAvgVariance = (int) (PatternMatchResultScaleFactor * 0.25f);
		private static readonly int MaxIndividualVariance = (int) (PatternMatchResultScaleFactor * 0.7f);
		
		private const int CodeShift = 98;
		
		private const int CodeCodeC = 99;
		private const int CodeCodeB = 100;
		private const int CodeCodeA = 101;
		
		private const int CodeFnc1 = 102;
		private const int CodeFnc2 = 97;
		private const int CodeFnc3 = 96;
		private const int CodeFnc4A = 101;
		private const int CodeFnc4B = 100;
		
		private const int CodeStartA = 103;
		private const int CodeStartB = 104;
		private const int CodeStartC = 105;
		private const int CodeStop = 106;

        /// <summary>
        /// Finds the start pattern.
        /// </summary>
        /// <param name="row">The row.</param>
        /// <returns></returns>
		private static int[] FindStartPattern(BitArray row)
		{
            int width = row.Size;
			int rowOffset = 0;
			while (rowOffset < width)
			{
				if (row.GetValue(rowOffset))
				{
					break;
				}
				rowOffset++;
			}
			
			int counterPosition = 0;
			int[] counters = new int[6];
			int patternStart = rowOffset;
			bool isWhite = false;
			int patternLength = counters.Length;
			
			for (int i = rowOffset; i < width; i++)
			{
				bool pixel = row.GetValue(i);
				if (pixel ^ isWhite)
				{
					counters[counterPosition]++;
				}
				else
				{
					if (counterPosition == patternLength - 1)
					{
						int bestVariance = MaxAvgVariance;
						int bestMatch = - 1;
						for (int startCode = CodeStartA; startCode <= CodeStartC; startCode++)
						{
							int variance = PatternMatchVariance(counters, CodePatterns[startCode], MaxIndividualVariance);
							if (variance < bestVariance)
							{
								bestVariance = variance;
								bestMatch = startCode;
							}
						}
						if (bestMatch >= 0)
						{
							// Look for whitespace before start pattern, >= 50% of width of start pattern
							if (row.IsRange(System.Math.Max(0, patternStart - (i - patternStart) / 2), patternStart, false))
							{
								return new int[]{patternStart, i, bestMatch};
							}
						}
						patternStart += counters[0] + counters[1];
						for (int y = 2; y < patternLength; y++)
						{
							counters[y - 2] = counters[y];
						}
						counters[patternLength - 2] = 0;
						counters[patternLength - 1] = 0;
						counterPosition--;
					}
					else
					{
						counterPosition++;
					}
					counters[counterPosition] = 1;
					isWhite = !isWhite;
				}
			}
			throw NotFoundException.Instance;
		}
		
		private static int DecodeCode(BitArray row, int[] counters, int rowOffset)
		{
			RecordPattern(row, rowOffset, counters);
			int bestVariance = MaxAvgVariance; // worst variance we'll accept
			int bestMatch = - 1;
			for (int d = 0; d < CodePatterns.Length; d++)
			{
				int[] pattern = CodePatterns[d];
				int variance = PatternMatchVariance(counters, pattern, MaxIndividualVariance);
				if (variance < bestVariance)
				{
					bestVariance = variance;
					bestMatch = d;
				}
			}
			// TODO We're overlooking the fact that the STOP pattern has 7 values, not 6.
			if (bestMatch >= 0)
			{
				return bestMatch;
			}
			else
			{
				throw NotFoundException.Instance;
			}
		}

        public override Result DecodeRow(int rowNumber, BitArray row, Dictionary<DecodeOptions, object> decodingOptions)
		{
			
			int[] startPatternInfo = FindStartPattern(row);
			int startCode = startPatternInfo[2];
			int codeSet;
			switch (startCode)
			{
				
				case CodeStartA: 
					codeSet = CodeCodeA;
					break;
				
				case CodeStartB: 
					codeSet = CodeCodeB;
					break;
				
				case CodeStartC: 
					codeSet = CodeCodeC;
					break;
				
				default: 
					throw FormatException.Instance;
				
			}
			
			bool done = false;
			bool isNextShifted = false;
			
			System.Text.StringBuilder result = new System.Text.StringBuilder(20);
			int lastStart = startPatternInfo[0];
			int nextStart = startPatternInfo[1];
			int[] counters = new int[6];
			
			int lastCode = 0;
			int code = 0;
			int checksumTotal = startCode;
			int multiplier = 0;
			bool lastCharacterWasPrintable = true;
			
			while (!done)
			{
				
				bool unshift = isNextShifted;
				isNextShifted = false;
				
				// Save off last code
				lastCode = code;
				
				// Decode another code from image
				code = DecodeCode(row, counters, nextStart);
				
				// Remember whether the last code was printable or not (excluding CODE_STOP)
				if (code != CodeStop)
				{
					lastCharacterWasPrintable = true;
				}
				
				// Add to checksum computation (if not CODE_STOP of course)
				if (code != CodeStop)
				{
					multiplier++;
					checksumTotal += multiplier * code;
				}
				
				// Advance to where the next code will to start
				lastStart = nextStart;
				for (int i = 0; i < counters.Length; i++)
				{
					nextStart += counters[i];
				}
				
				// Take care of illegal start codes
				switch (code)
				{
					
					case CodeStartA: 
					case CodeStartB: 
					case CodeStartC: 
						throw FormatException.Instance;
					}
				
				switch (codeSet)
				{
					
					
					case CodeCodeA: 
						if (code < 64)
						{
							result.Append((char) (' ' + code));
						}
						else if (code < 96)
						{
							result.Append((char) (code - 64));
						}
						else
						{
							// Don't let CODE_STOP, which always appears, affect whether whether we think the last
							// code was printable or not.
							if (code != CodeStop)
							{
								lastCharacterWasPrintable = false;
							}
							switch (code)
							{
								
								case CodeFnc1: 
								case CodeFnc2: 
								case CodeFnc3: 
								case CodeFnc4A: 
									// do nothing?
									break;
								
								case CodeShift: 
									isNextShifted = true;
									codeSet = CodeCodeB;
									break;
								
								case CodeCodeB: 
									codeSet = CodeCodeB;
									break;
								
								case CodeCodeC: 
									codeSet = CodeCodeC;
									break;
								
								case CodeStop: 
									done = true;
									break;
								}
						}
						break;
					
					case CodeCodeB: 
						if (code < 96)
						{
							result.Append((char) (' ' + code));
						}
						else
						{
							if (code != CodeStop)
							{
								lastCharacterWasPrintable = false;
							}
							switch (code)
							{
								
								case CodeFnc1: 
								case CodeFnc2: 
								case CodeFnc3: 
								case CodeFnc4B: 
									// do nothing?
									break;
								
								case CodeShift: 
									isNextShifted = true;
									codeSet = CodeCodeA;
									break;
								
								case CodeCodeA: 
									codeSet = CodeCodeA;
									break;
								
								case CodeCodeC: 
									codeSet = CodeCodeC;
									break;
								
								case CodeStop: 
									done = true;
									break;
								}
						}
						break;
					
					case CodeCodeC: 
						if (code < 100)
						{
							if (code < 10)
							{
								result.Append('0');
							}
							result.Append(code);
						}
						else
						{
							if (code != CodeStop)
							{
								lastCharacterWasPrintable = false;
							}
							switch (code)
							{
								
								case CodeFnc1: 
									// do nothing?
									break;
								
								case CodeCodeA: 
									codeSet = CodeCodeA;
									break;
								
								case CodeCodeB: 
									codeSet = CodeCodeB;
									break;
								
								case CodeStop: 
									done = true;
									break;
								}
						}
						break;
					}
				
				// Unshift back to another code set if we were shifted
				if (unshift)
                {
                    codeSet = codeSet == CodeCodeA ? CodeCodeB : CodeCodeA;

				}
			}
			
			// Check for ample whitespace following pattern, but, to do this we first need to remember that
			// we fudged decoding CODE_STOP since it actually has 7 bars, not 6. There is a black bar left
			// to read off. Would be slightly better to properly read. Here we just skip it:
			int width = row.Size;
			while (nextStart < width && row.GetValue(nextStart))
			{
				nextStart++;
			}
			if (!row.IsRange(nextStart, System.Math.Min(width, nextStart + (nextStart - lastStart) / 2), false))
			{
				throw NotFoundException.Instance;
			}
			
			// Pull out from sum the value of the penultimate check code
			checksumTotal -= multiplier * lastCode;
			// lastCode is the checksum then:
			if (checksumTotal % 103 != lastCode)
			{
				throw ChecksumException.Instance;
			}
			
			// Need to pull out the check digits from string
			int resultLength = result.Length;
			// Only bother if the result had at least one character, and if the checksum digit happened to
			// be a printable character. If it was just interpreted as a control code, nothing to remove.
			if (resultLength > 0 && lastCharacterWasPrintable)
			{
				if (codeSet == CodeCodeC)
				{
					result.Remove(resultLength - 2, resultLength - (resultLength - 2));
				}
				else
				{
					result.Remove(resultLength - 1, resultLength - (resultLength - 1));
				}
			}
			
			string resultString = result.ToString();
			
			if (resultString.Length == 0)
			{
				// Almost surely a false positive
				throw FormatException.Instance;
			}
			
			float left = (float) (startPatternInfo[1] + startPatternInfo[0]) / 2.0f;
			float right = (float) (nextStart + lastStart) / 2.0f;
			return new Result(resultString, null, new ResultPoint[]{new ResultPoint(left, (float) rowNumber), new ResultPoint(right, (float) rowNumber)}, BarcodeFormat.Code128);
		}
	}
}