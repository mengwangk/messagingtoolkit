//===============================================================================
// Copyright � TWIT88.COM.  All rights reserved.
//
// This file is part of Open Source Messaging Library.
//
// Open Source Messaging Library is free software: you can redistribute it 
// and/or modify it under the terms of the GNU General Public License version 3.
//
// Open Source Messaging Library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this software.  If not, see <http://www.gnu.org/licenses/>.
//===============================================================================

using System;
using System.Collections.Generic;

using BarcodeFormat = MessagingToolkit.Barcode.BarcodeFormat;
using DecodeHintType = MessagingToolkit.Barcode.DecodeOptions;
using BarcodeDecoderException = MessagingToolkit.Barcode.BarcodeDecoderException;
using Result = MessagingToolkit.Barcode.Result;
using BitArray = MessagingToolkit.Barcode.Common.BitArray;
using MessagingToolkit.Barcode.Helper;

namespace MessagingToolkit.Barcode.OneD
{

    /// <summary>
    /// A reader that can read all available UPC/EAN formats. If a caller wants to try to
    /// read all such formats, it is most efficient to use this implementation rather than invoke
    /// individual readers.
    /// </summary>
	public sealed class BarcodeUPCEANDecoder:OneDDecoder
	{
		private List<IDecoder> decoders;

        /// <summary>
        /// Initializes a new instance of the <see cref="BarcodeUPCEANDecoder"/> class.
        /// </summary>
        /// <param name="decodingOptions">The hints.</param>
        public BarcodeUPCEANDecoder(Dictionary<DecodeOptions, object> decodingOptions)
        {
            List<BarcodeFormat> possibleFormats = decodingOptions == null ? null : (List<BarcodeFormat>)BarcodeHelper.GetDecodeOptionType(decodingOptions, DecodeOptions.PossibleFormats);
            decoders = new List<IDecoder>(10);
			if (possibleFormats != null)
			{
				if (possibleFormats.Contains(BarcodeFormat.EAN13))
				{
					decoders.Add(new EAN13Decoder());
				}
				else if (possibleFormats.Contains(BarcodeFormat.UPCA))
				{
					decoders.Add(new UPCADecoder());
				}
				if (possibleFormats.Contains(BarcodeFormat.EAN8))
				{
					decoders.Add(new EAN8Decoder());
				}
				if (possibleFormats.Contains(BarcodeFormat.UPCE))
				{
					decoders.Add(new UPCEDecoder());
				}
			}
			if ((decoders.Count == 0))
			{
				decoders.Add(new EAN13Decoder());
				// UPC-A is covered by EAN-13
				decoders.Add(new EAN8Decoder());
				decoders.Add(new UPCEDecoder());
			}
		}

        /// <summary>
        ///   <p>Attempts to decode a one-dimensional barcode format given a single row of
        /// an image.</p>
        /// </summary>
        /// <param name="rowNumber">row number from top of the row</param>
        /// <param name="row">the black/white pixel data of the row</param>
        /// <param name="decodingOptions">decode hints</param>
        /// <returns>
        /// {@link Result} containing encoded string and start/end of barcode
        /// </returns>
        /// <throws>  ReaderException if an error occurs or barcode cannot be found </throws>
        public override Result DecodeRow(int rowNumber, BitArray row, Dictionary<DecodeOptions, object> decodingOptions)
		{
			// Compute this location once and reuse it on multiple implementations
			int[] startGuardPattern = UPCEANDecoder.FindStartGuardPattern(row);
			int size = decoders.Count;
			for (int i = 0; i < size; i++)
			{
				UPCEANDecoder decoder = (UPCEANDecoder) decoders[i];
				Result result;
				try
				{
					result = decoder.DecodeRow(rowNumber, row, startGuardPattern, decodingOptions);
				}
				catch (BarcodeDecoderException re)
				{
					continue;
				}
				// Special case: a 12-digit code encoded in UPC-A is identical to a "0"
				// followed by those 12 digits encoded as EAN-13. Each will recognize such a code,
				// UPC-A as a 12-digit string and EAN-13 as a 13-digit string starting with "0".
				// Individually these are correct and their readers will both read such a code
				// and correctly call it EAN-13, or UPC-A, respectively.
				//
				// In this case, if we've been looking for both types, we'd like to call it
				// a UPC-A code. But for efficiency we only run the EAN-13 decoder to also read
				// UPC-A. So we special case it here, and convert an EAN-13 result to a UPC-A
				// result if appropriate.
                bool ean13MayBeUPCA = BarcodeFormat.EAN13 == result.BarcodeFormat && result.Text[0] == '0';
                List<BarcodeFormat> possibleFormats = (decodingOptions == null) ? null : (List<BarcodeFormat>)BarcodeHelper.GetDecodeOptionType(decodingOptions, DecodeOptions.PossibleFormats);
                bool canReturnUPCA = possibleFormats == null || possibleFormats.Contains(BarcodeFormat.UPCA);

                if (ean13MayBeUPCA && canReturnUPCA)
                {
                    return new Result(result.Text.Substring(1), null, result.ResultPoints, BarcodeFormat.UPCA);
                }
                return result;
			}
			
			throw NotFoundException.Instance;
		}

        public override void Reset()
        {
            int size = decoders.Count;
            for (int i = 0; i < size; i++)
            {
                IDecoder decoder = (IDecoder)decoders[i];
                decoder.Reset();
            }
        }
	}
}