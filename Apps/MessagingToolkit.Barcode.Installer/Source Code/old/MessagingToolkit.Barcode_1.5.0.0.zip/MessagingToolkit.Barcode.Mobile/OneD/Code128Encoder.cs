﻿using MessagingToolkit.Barcode.Common;
using System;
using System.Collections;
using System.Collections.Generic;

namespace MessagingToolkit.Barcode.OneD
{
    /// <summary>
    /// This object renders a CODE128 code as a <see cref="null"/>.
    /// </summary>
    public sealed class Code128Encoder : UPCEANEncoder
    {

        private const int CodeStartB = 104;
        private const int CodeStartC = 105;
        private const int CodeCodeB = 100;
        private const int CodeCodeC = 99;
        private const int CodeStop = 106;

        public override BitMatrix Encode(String contents, BarcodeFormat format, int width, int height, Dictionary<EncodeOptions, object> encodingOptions)
        {
            if (format != MessagingToolkit.Barcode.BarcodeFormat.Code128)
            {
                throw new ArgumentException(
                        "Can only encode CODE_128, but got " + format);
            }
            return base.Encode(contents, format, width, height, encodingOptions);
        }

        public override byte[] Encode(String contents)
        {
            int length = contents.Length;
            // Check length
            if (length < 1 || length > 80)
            {
                throw new ArgumentException(
                        "Contents length should be between 1 and 80 characters, but got "
                                + length);
            }
            // Check content
            for (int i = 0; i < length; i++)
            {
                char c = contents[i];
                if (c < ' ' || c > '~')
                {
                    throw new ArgumentException(
                            "Contents should only contain characters between ' ' and '~'");
                }
            }

            List<int[]> patterns = new List<int[]>(); // temporary storage for patterns
            int checkSum = 0;
            int checkWeight = 1;
            int codeSet = 0; // selected code (CODE_CODE_B or CODE_CODE_C)
            int position = 0; // position in contents

            while (position < length)
            {
                //Select code to use
                int requiredDigitCount = (codeSet == CodeCodeC) ? 2 : 4;
                int newCodeSet;
                if (length - position >= requiredDigitCount
                        && IsDigits(contents, position, requiredDigitCount))
                {
                    newCodeSet = CodeCodeC;
                }
                else
                {
                    newCodeSet = CodeCodeB;
                }

                //Get the pattern index
                int patternIndex;
                if (newCodeSet == codeSet)
                {
                    // Encode the current character
                    if (codeSet == CodeCodeB)
                    {
                        patternIndex = contents[position] - ' ';
                        position += 1;
                    }
                    else
                    { // CODE_CODE_C
                        patternIndex = Int32.Parse(contents.Substring(position, (position + 2) - (position)));
                        position += 2;
                    }
                }
                else
                {
                    // Should we change the current code?
                    // Do we have a code set?
                    if (codeSet == 0)
                    {
                        // No, we don't have a code set
                        if (newCodeSet == CodeCodeB)
                        {
                            patternIndex = CodeStartB;
                        }
                        else
                        {
                            // CODE_CODE_C
                            patternIndex = CodeStartC;
                        }
                    }
                    else
                    {
                        // Yes, we have a code set
                        patternIndex = newCodeSet;
                    }
                    codeSet = newCodeSet;
                }

                // Get the pattern
                patterns.Add(MessagingToolkit.Barcode.OneD.Code128Decoder.CodePatterns[patternIndex]);

                // Compute checksum
                checkSum += patternIndex * checkWeight;
                if (position != 0)
                {
                    checkWeight++;
                }
            }

            // Compute and append checksum
            checkSum %= 103;
            patterns.Add(MessagingToolkit.Barcode.OneD.Code128Decoder.CodePatterns[checkSum]);

            // Append stop code
            patterns.Add(MessagingToolkit.Barcode.OneD.Code128Decoder.CodePatterns[CodeStop]);

            // Compute code width
            int codeWidth = 0;
            System.Collections.IEnumerator patternEnumeration = patterns.GetEnumerator();
            while (patternEnumeration.MoveNext())
            {
                int[] pattern = (int[])patternEnumeration.Current;
                for (int i = 0; i < pattern.Length; i++)
                {
                    codeWidth += pattern[i];
                }
            }

            // Compute result
            byte[] result = new byte[codeWidth];
            patternEnumeration = patterns.GetEnumerator();
            int pos = 0;
            while (patternEnumeration.MoveNext())
            {
                int[] pattern = (int[])patternEnumeration.Current;
                pos += MessagingToolkit.Barcode.OneD.UPCEANEncoder.AppendPattern(result, pos, pattern, 1);
            }

            return result;
        }

        private static bool IsDigits(String val, int start, int length)
        {
            int end = start + length;
            for (int i = start; i < end; i++)
            {
                char c = val[i];
                if (c < '0' || c > '9')
                {
                    return false;
                }
            }
            return true;
        }

    }
}
