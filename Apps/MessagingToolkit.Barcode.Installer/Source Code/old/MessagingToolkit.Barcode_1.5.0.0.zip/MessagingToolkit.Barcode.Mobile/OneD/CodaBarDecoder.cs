﻿using MessagingToolkit.Barcode.Common;

using System;
using System.Text;
using System.Collections.Generic;

namespace MessagingToolkit.Barcode.OneD
{
    /// <summary>
    /// <p>Decodes Codabar barcodes.</p>
    /// </summary>
    public sealed class CodaBarDecoder : OneDDecoder
    {

        private const String AlphabetString = "0123456789-$:/.+ABCDTN";
        private static readonly char[] Alphabet = AlphabetString.ToCharArray();

        /// <summary>
        /// These represent the encodings of characters, as patterns of wide and narrow bars. The 7 least-significant bits of
        /// each int correspond to the pattern of wide and narrow, with 1s representing "wide" and 0s representing narrow. NOTE
        /// : c is equal to the /// pattern NOTE : d is equal to the e pattern
        /// </summary>
        ///
        private static readonly int[] CharacterEncodings = { 0x003, 0x006, 0x009,
				0x060, 0x012, 0x042, 0x021, 0x024, 0x030,
				0x048, // 0-9
				0x00c, 0x018, 0x045, 0x051, 0x054, 0x015, 0x01A, 0x029, 0x00B,
				0x00E, // -$:/.+ABCD
				0x01A, 0x029 //TN
		};

        // minimal number of characters that should be present (inclusing start and stop characters)
        // this check has been added to reduce the number of false positive on other formats
        // until the cause for this behaviour has been determined
        // under normal circumstances this should be set to 3
        private const int minCharacterLength = 6;

        // multiple start/end patterns
        // official start and end patterns
        private static readonly char[] StartEndEncoding = { 'E', '*', 'A', 'B', 'C',
				'D', 'T', 'N' };

        // some codabar generator allow the codabar string to be closed by every character
        //private static final char[] STARTEND_ENCODING = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '-', '$', ':', '/', '.', '+', 'A', 'B', 'C', 'D', 'T', 'N'};

        // some industries use a checksum standard but this is not part of the original codabar standard
        // for more information see : http://www.mecsw.com/specs/codabar.html

        public override Result DecodeRow(int rowNumber, BitArray row, Dictionary<DecodeOptions, object> decodingOptions)
        {
            int[] start = FindAsteriskPattern(row);
            start[1] = 0; // BAS: settings this to 0 improves the recognition rate somehow?
            int nextStart = start[1];
            int end = row.GetSize();

            // Read off white space
            while (nextStart < end && !row.Get(nextStart))
            {
                nextStart++;
            }

            StringBuilder result = new StringBuilder();
            //int[] counters = new int[7];
            int[] counters;
            int lastStart;

            do
            {
                counters = new int[] { 0, 0, 0, 0, 0, 0, 0 }; // reset counters
                MessagingToolkit.Barcode.OneD.OneDDecoder.RecordPattern(row, nextStart, counters);

                char decodedChar = ToNarrowWidePattern(counters);
                if (decodedChar == '!')
                {
                    throw NotFoundException.Instance;
                }
                result.Append(decodedChar);
                lastStart = nextStart;
                for (int i = 0; i < counters.Length; i++)
                {
                    nextStart += counters[i];
                }

                // Read off white space
                while (nextStart < end && !row.Get(nextStart))
                {
                    nextStart++;
                }
            } while (nextStart < end); // no fixed end pattern so keep on reading while data is available

            // Look for whitespace after pattern:
            int lastPatternSize = 0;
            for (int i_0 = 0; i_0 < counters.Length; i_0++)
            {
                lastPatternSize += counters[i_0];
            }

            int whiteSpaceAfterEnd = nextStart - lastStart - lastPatternSize;
            // If 50% of last pattern size, following last pattern, is not whitespace, fail
            // (but if it's whitespace to the very end of the image, that's OK)
            if (nextStart != end && (whiteSpaceAfterEnd / 2 < lastPatternSize))
            {
                throw NotFoundException.Instance;
            }

            // valid result?
            if (result.Length < 2)
            {
                throw NotFoundException.Instance;
            }

            char startchar = result[0];
            if (!ArrayContains(StartEndEncoding, startchar))
            {
                //invalid start character
                throw NotFoundException.Instance;
            }

            // find stop character
            for (int k = 1; k < result.Length; k++)
            {
                if (result[k] == startchar)
                {
                    // found stop character -> discard rest of the string
                    if ((k + 1) != result.Length)
                    {
                        result.Remove(k + 1, result.Length - 1 - (k + 1));
                        k = result.Length;// break out of loop
                    }
                }
            }

            // remove stop/start characters character and check if a string longer than 5 characters is contained
            if (result.Length > minCharacterLength)
            {
                result.Remove(result.Length - 1, 1);
                result.Remove(0, 1);
            }
            else
            {
                // Almost surely a false positive ( start + stop + at least 1 character)
                throw NotFoundException.Instance;
            }

            float left = (float)(start[1] + start[0]) / 2.0f;
            float right = (float)(nextStart + lastStart) / 2.0f;
            return new Result(result.ToString(), null, new ResultPoint[] {
					new ResultPoint(left, (float) rowNumber),
					new ResultPoint(right, (float) rowNumber) },
                    MessagingToolkit.Barcode.BarcodeFormat.Codabar);
        }

        private static int[] FindAsteriskPattern(BitArray row)
        {
            int width = row.GetSize();
            int rowOffset = 0;
            while (rowOffset < width)
            {
                if (row.Get(rowOffset))
                {
                    break;
                }
                rowOffset++;
            }

            int counterPosition = 0;
            int[] counters = new int[7];
            int patternStart = rowOffset;
            bool isWhite = false;
            int patternLength = counters.Length;

            for (int i = rowOffset; i < width; i++)
            {
                bool pixel = row.Get(i);
                if (pixel ^ isWhite)
                {
                    counters[counterPosition]++;
                }
                else
                {
                    if (counterPosition == patternLength - 1)
                    {
                        try
                        {
                            if (ArrayContains(StartEndEncoding,
                                    ToNarrowWidePattern(counters)))
                            {
                                // Look for whitespace before start pattern, >= 50% of width of start pattern
                                if (row.IsRange(
                                        Math.Max(0, patternStart - (i - patternStart) / 2),
                                        patternStart, false))
                                {
                                    return new int[] { patternStart, i };
                                }
                            }
                        }
                        catch (ArgumentException re)
                        {
                            // no match, continue
                        }
                        patternStart += counters[0] + counters[1];
                        for (int y = 2; y < patternLength; y++)
                        {
                            counters[y - 2] = counters[y];
                        }
                        counters[patternLength - 2] = 0;
                        counters[patternLength - 1] = 0;
                        counterPosition--;
                    }
                    else
                    {
                        counterPosition++;
                    }
                    counters[counterPosition] = 1;
                    isWhite ^= true; // isWhite = !isWhite;
                }
            }
            throw NotFoundException.Instance;
        }

        private static bool ArrayContains(char[] array, char key)
        {
            if (array != null)
            {
                for (int i = 0; i < array.Length; i++)
                {
                    if (array[i] == key)
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        private static char ToNarrowWidePattern(int[] counters)
        {
            // ----------- change start
            int numCounters = counters.Length;
            int maxNarrowCounter = 0;

            int minCounter = Int32.MaxValue;
            for (int i = 0; i < numCounters; i++)
            {
                if (counters[i] < minCounter)
                {
                    minCounter = counters[i];
                }
                if (counters[i] > maxNarrowCounter)
                {
                    maxNarrowCounter = counters[i];
                }
            }
            // ---------- change end

            do
            {
                int wideCounters = 0;
                int pattern = 0;
                for (int i_0 = 0; i_0 < numCounters; i_0++)
                {
                    if (counters[i_0] > maxNarrowCounter)
                    {
                        pattern |= 1 << (numCounters - 1 - i_0);
                        wideCounters++;
                    }
                }

                if ((wideCounters == 2) || (wideCounters == 3))
                {
                    for (int i_1 = 0; i_1 < CharacterEncodings.Length; i_1++)
                    {
                        if (CharacterEncodings[i_1] == pattern)
                        {
                            return Alphabet[i_1];
                        }
                    }
                }
                maxNarrowCounter--;
            } while (maxNarrowCounter > minCounter);
            return '!';
        }

    }
}
