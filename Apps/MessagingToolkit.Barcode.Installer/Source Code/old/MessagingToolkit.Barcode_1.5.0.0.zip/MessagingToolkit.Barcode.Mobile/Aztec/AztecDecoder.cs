using System;
using System.Collections;
using System.ComponentModel;
using System.IO;
using System.Runtime.CompilerServices;
using System.Collections.Generic;

using MessagingToolkit.Barcode;
using MessagingToolkit.Barcode.Aztec;
using MessagingToolkit.Barcode.Aztec.Detector;
using MessagingToolkit.Barcode.Common;
using MessagingToolkit.Barcode.Aztec.Decoder;

namespace MessagingToolkit.Barcode.Aztec
{
    /// <summary>
    /// This implementation can detect and decode Aztec codes in an image.
    /// </summary>
    public sealed class AztecDecoder : IDecoder
    {

        /// <summary>
        /// Locates and decodes a Data Matrix code in an image.
        /// </summary>
        /// <param name="image">image of barcode to decode</param>
        /// <returns>
        /// a String representing the content encoded by the Data Matrix code
        /// </returns>
        /// <exception cref="NotFoundException">if a Data Matrix code cannot be found</exception>
        ///   
        /// <exception cref="FormatException">if a Data Matrix code cannot be decoded</exception>
        ///   
        /// <exception cref="ChecksumException">if error correction fails</exception>
        public Result Decode(BinaryBitmap image)
        {
            return Decode(image, null);
        }

        public Result Decode(BinaryBitmap image, Dictionary<DecodeOptions, object> decodingOptions)
        {

            AztecDetectorResult detectorResult = new AztecDetector(image.BlackMatrix).Detect();
            ResultPoint[] points = detectorResult.Points;

            if (decodingOptions != null && detectorResult.Points != null)
            {
                ResultPointCallback rpcb = (ResultPointCallback)decodingOptions[DecodeOptions.NeedResultPointCallback];
                if (rpcb != null)
                {
                    for (int i = 0; i < detectorResult.Points.Length; i++)
                    {
                        rpcb.FoundPossibleResultPoint(detectorResult.Points[i]);
                    }
                }
            }

            DecoderResult decoderResult = new MessagingToolkit.Barcode.Aztec.Decoder.Decoder().Decode(detectorResult);

            Result result = new Result(decoderResult.Text, decoderResult.RawBytes, points, BarcodeFormat.Aztec);

            if (decoderResult.ByteSegments != null)
            {
                result.PutMetadata(ResultMetadataType.ByteSegments, decoderResult.ByteSegments);
            }
            if (decoderResult.ECLevel != null)
            {
                result.PutMetadata(ResultMetadataType.ErrorCorrectionLevel, decoderResult.ECLevel);
            }

            return result;
        }

        public void Reset()
        {
            // do nothing
        }

    }
}
