using System;
using System.Collections;
using System.IO;
using System.Text;

using MessagingToolkit.Barcode.Common;
using MessagingToolkit.Barcode.Aztec;
using MessagingToolkit.Barcode.Common.ReedSolomon;

namespace MessagingToolkit.Barcode.Aztec.Decoder
{

    /// <summary>
    /// The main class which implements Aztec Code decoding -- as opposed to locating and extracting
    /// the Aztec Code from an image.
    /// </summary>
    public sealed class Decoder
    {
        private const int Upper = 0;
        private const int Lower = 1;
        private const int Mixed = 2;
        private const int Digit = 3;
        private const int Punct = 4;
        private const int Binary = 5;

        private static readonly int[] NbBitsCompact = { 0, 104, 240, 408, 608 };

        private static readonly int[] NbBits = { 0, 128, 288, 480, 704, 960, 1248,
				1568, 1920, 2304, 2720, 3168, 3648, 4160, 4704, 5280, 5888, 6528,
				7200, 7904, 8640, 9408, 10208, 11040, 11904, 12800, 13728, 14688,
				15680, 16704, 17760, 18848, 19968 };

        private static readonly int[] NbDataBlockCompact = { 0, 17, 40, 51, 76 };

        private static readonly int[] NbDataBlock = { 0, 21, 48, 60, 88, 120, 156,
				196, 240, 230, 272, 316, 364, 416, 470, 528, 588, 652, 720, 790,
				864, 940, 1020, 920, 992, 1066, 1144, 1224, 1306, 1392, 1480, 1570,
				1664 };

        private static readonly String[] UpperTable = { "CTRL_PS", " ", "A", "B",
				"C", "D", "E", "F", "G", "h", "I", "J", "K", "L", "M", "N", "O",
				"P", "Q", "R", "S", "T", "U", "V", "w", "X", "Y", "Z", "CTRL_LL",
				"CTRL_ML", "CTRL_DL", "CTRL_BS" };

        private static readonly String[] LowerTable = { "CTRL_PS", " ", "a", "b",
				"c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o",
				"p", "q", "r", "s", "t", "u", "v", "w", "X", "Y", "z", "CTRL_US",
				"CTRL_ML", "CTRL_DL", "CTRL_BS" };

        private static readonly String[] MixedTable = { "CTRL_PS", " ", @"\1", @"\2",
				@"\3", @"\4", @"\5", @"\6", @"\7", "\b", "\t", "\n", @"\13", "\f", "\r",
				@"\33", @"\34", @"\35", @"\36", @"\37", "@", "\\", "^", "_", "`", "|",
				"~", @"\177", "CTRL_LL", "CTRL_UL", "CTRL_PL", "CTRL_BS" };

        private static readonly String[] PunctTable = { "", "\r", "\r\n", ". ", ", ",
				": ", "!", "\"", "#", "$", "%", "&", "'", "(", ")", "*", "+", ",",
				"-", ".", "/", ":", ";", "<", "=", ">", "?", "[", "]", "{", "}",
				"CTRL_UL" };

        private static readonly String[] DigitTable = { "CTRL_PS", " ", "0", "1",
				"2", "3", "4", "5", "6", "7", "8", "9", ",", ".", "CTRL_UL",
				"CTRL_US" };

        private int numCodewords;
        private int codewordSize;
        private AztecDetectorResult ddata;
        private int invertedBitCount;

        public DecoderResult Decode(AztecDetectorResult detectorResult)
        {
            ddata = detectorResult;
            BitMatrix matrix = detectorResult.Bits;

            if (!ddata.IsCompact())
            {
                matrix = RemoveDashedLines(ddata.Bits);
            }

            bool[] rawbits = ExtractBits(matrix);

            bool[] correctedBits = CorrectBits(rawbits);

            String result = GetEncodedData(correctedBits);

            return new DecoderResult(null, result, null, null);
        }

        /// <summary>
        /// Gets the string encoded in the aztec code bits
        /// </summary>
        ///
        /// <returns>the decoded string</returns>
        /// <exception cref="FormatException">if the input is not valid</exception>
        private String GetEncodedData(bool[] correctedBits)
        {

            int endIndex = codewordSize * ddata.GetNbDatablocks()- invertedBitCount;
            if (endIndex > correctedBits.Length)
            {
                throw FormatException.Instance;
            }

            int lastTable = Upper;
            int table = Upper;
            int startIndex = 0;
            StringBuilder result = new StringBuilder(20);
            bool end = false;
            bool shift = false;
            bool switchShift = false;

            while (!end)
            {

                if (shift)
                {
                    // the table is for the next character only
                    switchShift = true;
                }
                else
                {
                    // save the current table in case next one is a shift
                    lastTable = table;
                }

                int code;
                switch (table)
                {
                    case Binary:
                        if (endIndex - startIndex < 8)
                        {
                            end = true;
                            break;
                        }
                        code = ReadCode(correctedBits, startIndex, 8);
                        startIndex += 8;

                        result.Append((char)code);
                        break;

                    default:
                        int size = 5;

                        if (table == Digit)
                        {
                            size = 4;
                        }

                        if (endIndex - startIndex < size)
                        {
                            end = true;
                            break;
                        }

                        code = ReadCode(correctedBits, startIndex, size);
                        startIndex += size;

                        String str = GetCharacter(table, code);
                        if (str.StartsWith("CTRL_"))
                        {
                            // Table changes
                            table = GetTable(str[5]);

                            if (str[6] == 'S')
                            {
                                shift = true;
                            }
                        }
                        else
                        {
                            result.Append(str);
                        }

                        break;
                }

                if (switchShift)
                {
                    table = lastTable;
                    shift = false;
                    switchShift = false;
                }

            }
            return result.ToString();
        }

        /// <summary>
        /// gets the table corresponding to the char passed
        /// </summary>
        ///
        private static int GetTable(char t)
        {
            int table = Upper;

            switch ((int)t)
            {
                case 'U':
                    table = Upper;
                    break;
                case 'L':
                    table = Lower;
                    break;
                case 'P':
                    table = Punct;
                    break;
                case 'M':
                    table = Mixed;
                    break;
                case 'D':
                    table = Digit;
                    break;
                case 'B':
                    table = Binary;
                    break;
            }

            return table;
        }

        /// <summary>
        /// Gets the character (or string) corresponding to the passed code in the given table
        /// </summary>
        ///
        /// <param name="table">the table used</param>
        /// <param name="code">the code of the character</param>
        private static String GetCharacter(int table, int code)
        {
            switch (table)
            {
                case Upper:
                    return UpperTable[code];
                case Lower:
                    return LowerTable[code];
                case Mixed:
                    return MixedTable[code];
                case Punct:
                    return PunctTable[code];
                case Digit:
                    return DigitTable[code];
                default:
                    return "";
            }
        }

        /// <summary>
        /// <p> performs RS error correction on an array of bits </p>
        /// </summary>
        ///
        /// <returns>the corrected array</returns>
        /// <exception cref="FormatException">if the input contains too many errors</exception>
        private bool[] CorrectBits(bool[] rawbits)
        {
            GenericGF gf;

            if (ddata.GetNbLayers() <= 2)
            {
                codewordSize = 6;
                gf = GenericGF.AztechData6;
            }
            else if (ddata.GetNbLayers() <= 8)
            {
                codewordSize = 8;
                gf = GenericGF.AztecData8;
            }
            else if (ddata.GetNbLayers() <= 22)
            {
                codewordSize = 10;
                gf = GenericGF.AztecData10;
            }
            else
            {
                codewordSize = 12;
                gf = GenericGF.AztecData12;
            }

            int numDataCodewords = ddata.GetNbDatablocks();
            int numECCodewords;
            int offset;

            if (ddata.IsCompact())
            {
                offset = NbBitsCompact[ddata.GetNbLayers()] - numCodewords
                        * codewordSize;
                numECCodewords = NbDataBlockCompact[ddata.GetNbLayers()]
                        - numDataCodewords;
            }
            else
            {
                offset = NbBits[ddata.GetNbLayers()] - numCodewords * codewordSize;
                numECCodewords = NbDataBlock[ddata.GetNbLayers()]
                        - numDataCodewords;
            }

            int[] dataWords = new int[numCodewords];
            for (int i = 0; i < numCodewords; i++)
            {
                int flag = 1;
                for (int j = 1; j <= codewordSize; j++)
                {
                    if (rawbits[codewordSize * i + codewordSize - j + offset])
                    {
                        dataWords[i] += flag;
                    }
                    flag <<= 1;
                }

                //if (dataWords[i] >= flag) {
                //  flag++;
                //}
            }

            try
            {
                ReedSolomonDecoder rsDecoder = new ReedSolomonDecoder(gf);
                rsDecoder.Decode(dataWords, numECCodewords);
            }
            catch (ReedSolomonException rse)
            {
                throw FormatException.Instance;
            }

            offset = 0;
            invertedBitCount = 0;

            bool[] correctedBits = new bool[numDataCodewords * codewordSize];
            for (int i_0 = 0; i_0 < numDataCodewords; i_0++)
            {

                bool seriesColor = false;
                int seriesCount = 0;
                int flag_1 = 1 << (codewordSize - 1);

                for (int j_2 = 0; j_2 < codewordSize; j_2++)
                {

                    bool color = (dataWords[i_0] & flag_1) == flag_1;

                    if (seriesCount == codewordSize - 1)
                    {

                        if (color == seriesColor)
                        {
                            //bit must be inverted
                            throw FormatException.Instance;
                        }

                        seriesColor = false;
                        seriesCount = 0;
                        offset++;
                        invertedBitCount++;
                    }
                    else
                    {

                        if (seriesColor == color)
                        {
                            seriesCount++;
                        }
                        else
                        {
                            seriesCount = 1;
                            seriesColor = color;
                        }

                        correctedBits[i_0 * codewordSize + j_2 - offset] = color;

                    }

                    flag_1 = (int)(((uint)flag_1) >> 1);
                }
            }

            return correctedBits;
        }

        /// <summary>
        /// Gets the array of bits from an Aztec Code matrix
        /// </summary>
        ///
        /// <returns>the array of bits</returns>
        /// <exception cref="FormatException">if the matrix is not a valid aztec code</exception>
        private bool[] ExtractBits(BitMatrix matrix)
        {

            bool[] rawbits;
            if (ddata.IsCompact())
            {
                if (ddata.GetNbLayers() > NbBitsCompact.Length)
                {
                    throw FormatException.Instance;
                }
                rawbits = new bool[NbBitsCompact[ddata.GetNbLayers()]];
                numCodewords = NbDataBlockCompact[ddata.GetNbLayers()];
            }
            else
            {
                if (ddata.GetNbLayers() > NbBits.Length)
                {
                    throw FormatException.Instance;
                }
                rawbits = new bool[NbBits[ddata.GetNbLayers()]];
                numCodewords = NbDataBlock[ddata.GetNbLayers()];
            }

            int layer = ddata.GetNbLayers();
            int size = matrix.Height;
            int rawbitsOffset = 0;
            int matrixOffset = 0;

            while (layer != 0)
            {

                int flip = 0;
                for (int i = 0; i < 2 * size - 4; i++)
                {
                    rawbits[rawbitsOffset + i] = matrix.Get(matrixOffset + flip,
                            matrixOffset + i / 2);
                    rawbits[rawbitsOffset + 2 * size - 4 + i] = matrix.Get(
                            matrixOffset + i / 2, matrixOffset + size - 1 - flip);
                    flip = (flip + 1) % 2;
                }

                flip = 0;
                for (int i_0 = 2 * size + 1; i_0 > 5; i_0--)
                {
                    rawbits[rawbitsOffset + 4 * size - 8 + (2 * size - i_0) + 1] = matrix
                            .Get(matrixOffset + size - 1 - flip, matrixOffset + i_0
                                    / 2 - 1);
                    rawbits[rawbitsOffset + 6 * size - 12 + (2 * size - i_0) + 1] = matrix
                            .Get(matrixOffset + i_0 / 2 - 1, matrixOffset + flip);
                    flip = (flip + 1) % 2;
                }

                matrixOffset += 2;
                rawbitsOffset += 8 * size - 16;
                layer--;
                size -= 4;
            }

            return rawbits;
        }

        /// <summary>
        /// Transforms an Aztec code matrix by removing the control dashed lines
        /// </summary>
        ///
        private static BitMatrix RemoveDashedLines(BitMatrix matrix)
        {
            int nbDashed = 1 + 2 * ((matrix.Width - 1) / 2 / 16);
            BitMatrix newMatrix = new BitMatrix(matrix.Width - nbDashed,
                    matrix.Height - nbDashed);

            int nx = 0;

            for (int x = 0; x < matrix.Width; x++)
            {

                if ((matrix.Width / 2 - x) % 16 == 0)
                {
                    continue;
                }

                int ny = 0;
                for (int y = 0; y < matrix.Height; y++)
                {

                    if ((matrix.Width / 2 - y) % 16 == 0)
                    {
                        continue;
                    }

                    if (matrix.Get(x, y))
                    {
                        newMatrix.Set(nx, ny);
                    }
                    ny++;
                }
                nx++;
            }

            return newMatrix;
        }

        /// <summary>
        /// Reads a code of given length and at given index in an array of bits
        /// </summary>
        /// <param name="rawbits">The rawbits.</param>
        /// <param name="startIndex">The start index.</param>
        /// <param name="length">The length.</param>
        /// <returns></returns>
        private static int ReadCode(bool[] rawbits, int startIndex, int length)
        {
            int res = 0;

            for (int i = startIndex; i < startIndex + length; i++)
            {
                res <<= 1;
                if (rawbits[i])
                {
                    res++;
                }
            }

            return res;
        }

    }
}
