//===============================================================================
// OSML - Open Source Messaging Library
//
//===============================================================================
// Copyright � TWIT88.COM.  All rights reserved.
//
// This file is part of Open Source Messaging Library.
//
// Open Source Messaging Library is free software: you can redistribute it 
// and/or modify it under the terms of the GNU General Public License version 3.
//
// Open Source Messaging Library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this software.  If not, see <http://www.gnu.org/licenses/>.
//===============================================================================

using System;

using BarcodeFormat = MessagingToolkit.Barcode.BarcodeFormat;
using Result = MessagingToolkit.Barcode.Result;

namespace MessagingToolkit.Barcode.Client.Results
{

    /// <summary>
    /// Parses strings of digits that represent a ISBN.
    /// </summary>
	public class ISBNResultParser:ResultParser
	{
		
		private ISBNResultParser()
		{
		}
		
		// ISBN-13 For Dummies 
		// http://www.bisg.org/isbn-13/for.dummies.html

		public static ISBNParsedResult Parse(Result result)
		{
			BarcodeFormat format = result.BarcodeFormat;
			if (!(BarcodeFormat.EAN13 == format))
			{
				return null;
			}
			string rawText = result.Text;
			if (rawText == null)
			{
				return null;
			}
			int length = rawText.Length;
			if (length != 13)
			{
				return null;
			}
			if (!rawText.StartsWith("978") && !rawText.StartsWith("979"))
			{
				return null;
			}
			
			return new ISBNParsedResult(rawText);
		}
	}
}