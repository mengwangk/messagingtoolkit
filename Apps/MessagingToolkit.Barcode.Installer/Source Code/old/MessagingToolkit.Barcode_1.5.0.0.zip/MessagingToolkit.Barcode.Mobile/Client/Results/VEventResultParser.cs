//===============================================================================
// OSML - Open Source Messaging Library
//
//===============================================================================
// Copyright � TWIT88.COM.  All rights reserved.
//
// This file is part of Open Source Messaging Library.
//
// Open Source Messaging Library is free software: you can redistribute it 
// and/or modify it under the terms of the GNU General Public License version 3.
//
// Open Source Messaging Library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this software.  If not, see <http://www.gnu.org/licenses/>.
//===============================================================================

using System;
using Result = MessagingToolkit.Barcode.Result;

namespace MessagingToolkit.Barcode.Client.Results
{

    /// <summary>
    /// Partially implements the iCalendar format's "VEVENT" format for specifying a
    /// calendar event. See RFC 2445. This supports SUMMARY, LOCATION, GEO, DTSTART and DTEND fields.
    /// </summary>
    internal sealed class VEventResultParser : ResultParser
    {

        private VEventResultParser()
        {
        }

        public static CalendarParsedResult Parse(Result result)
        {
            String rawText = result.Text;
            if (rawText == null)
            {
                return null;
            }
            int vEventStart = rawText.IndexOf("BEGIN:VEVENT");
            if (vEventStart < 0)
            {
                return null;
            }

            String summary = VCardResultParser.MatchSingleVCardPrefixedField("SUMMARY", rawText, true);
            String start = VCardResultParser.MatchSingleVCardPrefixedField("DTSTART", rawText, true);
            String end = VCardResultParser.MatchSingleVCardPrefixedField("DTEND", rawText, true);
            String location = VCardResultParser.MatchSingleVCardPrefixedField("LOCATION", rawText, true);
            String description = VCardResultParser.MatchSingleVCardPrefixedField("DESCRIPTION", rawText, true);

            String geoString = VCardResultParser.MatchSingleVCardPrefixedField("GEO", rawText, true);
            double latitude;
            double longitude;
            if (geoString == null)
            {
                latitude = System.Double.NaN;
                longitude = System.Double.NaN;
            }
            else
            {
                int semicolon = geoString.IndexOf(';');
                try
                {
                    latitude = Double.Parse(geoString.Substring(0, (semicolon) - (0)));
                    longitude = Double.Parse(geoString.Substring(semicolon + 1));
                }
                catch (FormatException nfe)
                {
                    return null;
                }
            }

            try
            {
                return new CalendarParsedResult(summary, start, end, location,
                        null, description, latitude, longitude);
            }
            catch (ArgumentException iae)
            {
                return null;
            }
        }

    }
}