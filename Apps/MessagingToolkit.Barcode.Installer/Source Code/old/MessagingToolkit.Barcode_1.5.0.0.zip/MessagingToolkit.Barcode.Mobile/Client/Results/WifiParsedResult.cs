﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MessagingToolkit.Barcode.Client.Results
{
    public sealed class WifiParsedResult : ParsedResult
    {
        private readonly String ssid;
        private readonly String networkEncryption;
        private readonly String password;

        public WifiParsedResult(String networkEncryption, String ssid, String password)
            : base(ParsedResultType.Wifi)
        {
            this.ssid = ssid;
            this.networkEncryption = networkEncryption;
            this.password = password;
        }

        public String GetSsid()
        {
            return ssid;
        }

        public String GetNetworkEncryption()
        {
            return networkEncryption;
        }

        public String GetPassword()
        {
            return password;
        }

        public override String DisplayResult
        {
            get
            {
                StringBuilder result = new StringBuilder(80);
                MaybeAppend(ssid, result);
                MaybeAppend(networkEncryption, result);
                MaybeAppend(password, result);
                return result.ToString();
            }
        }
    }
}