//===============================================================================
// OSML - Open Source Messaging Library
//
//===============================================================================
// Copyright � TWIT88.COM.  All rights reserved.
//
// This file is part of Open Source Messaging Library.
//
// Open Source Messaging Library is free software: you can redistribute it 
// and/or modify it under the terms of the GNU General Public License version 3.
//
// Open Source Messaging Library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this software.  If not, see <http://www.gnu.org/licenses/>.
//===============================================================================

using System;
using System.Text;
using System.Collections.Generic;
using System.IO;
using Result = MessagingToolkit.Barcode.Result;

namespace MessagingToolkit.Barcode.Client.Results
{

    /// <summary>
    /// Parses contact information formatted according to the VCard (2.1) format. This is not a complete
    /// implementation but should parse information as commonly encoded in 2D barcodes.
    /// </summary>
    internal sealed class VCardResultParser : ResultParser
    {

        private VCardResultParser()
        {
        }

        public static AddressBookParsedResult Parse(Result result)
        {
            // Although we should insist on the raw text ending with "END:VCARD", there's no reason
            // to throw out everything else we parsed just because this was omitted. In fact, Eclair
            // is doing just that, and we can't parse its contacts without this leniency.
            String rawText = result.Text;
            if (rawText == null || !rawText.StartsWith("BEGIN:VCARD"))
            {
                return null;
            }
            String[] names = MatchVCardPrefixedField("FN", rawText, true);
            if (names == null)
            {
                // If no display names found, look for regular name fields and format them
                names = MatchVCardPrefixedField("N", rawText, true);
                FormatNames(names);
            }
            String[] phoneNumbers = MatchVCardPrefixedField("TEL", rawText, true);
            String[] emails = MatchVCardPrefixedField("EMAIL", rawText, true);
            String note = MatchSingleVCardPrefixedField("NOTE", rawText, false);
            String[] addresses = MatchVCardPrefixedField("ADR", rawText, true);
            if (addresses != null)
            {
                for (int i = 0; i < addresses.Length; i++)
                {
                    addresses[i] = FormatAddress(addresses[i]);
                }
            }
            String org = MatchSingleVCardPrefixedField("ORG", rawText, true);
            String birthday = MatchSingleVCardPrefixedField("BDAY", rawText, true);
            if (!IsLikeVCardDate(birthday))
            {
                birthday = null;
            }
            String title = MatchSingleVCardPrefixedField("TITLE", rawText, true);
            String url = MatchSingleVCardPrefixedField("URL", rawText, true);
            return new AddressBookParsedResult(names, null, phoneNumbers, emails,
                    note, addresses, org, birthday, title, url);
        }

        private static String[] MatchVCardPrefixedField(String prefix,
                String rawText, bool trim)
        {
            List<string> matches = null;
            int i = 0;
            int max = rawText.Length;

            while (i < max)
            {
                i = rawText.IndexOf(prefix, i);
                if (i < 0)
                {
                    break;
                }

                if (i > 0 && rawText[i - 1] != '\n')
                {
                    // then this didn't start a new token, we matched in the middle of something
                    i++;
                    continue;
                }
                i += prefix.Length; // Skip past this prefix we found to start
                if (rawText[i] != ':' && rawText[i] != ';')
                {
                    continue;
                }

                int metadataStart = i;
                while (rawText[i] != ':')
                { // Skip until a colon
                    i++;
                }

                bool quotedPrintable = false;
                String quotedPrintableCharset = null;
                if (i > metadataStart)
                {
                    // There was something after the tag, before colon
                    int j = metadataStart + 1;
                    while (j <= i)
                    {
                        if (rawText[j] == ';' || rawText[j] == ':')
                        {
                            String metadata = rawText.Substring(metadataStart + 1, (j) - (metadataStart + 1));
                            int equals = metadata.IndexOf('=');
                            if (equals >= 0)
                            {
                                String key = metadata.Substring(0, (equals) - (0));
                                String val = metadata.Substring(equals + 1);
                                if ("ENCODING".Equals(key, StringComparison.InvariantCultureIgnoreCase))
                                {
                                    if ("QUOTED-PRINTABLE".Equals(val, StringComparison.InvariantCultureIgnoreCase))
                                    {
                                        quotedPrintable = true;
                                    }
                                }
                                else if ("CHARSET".Equals(key, StringComparison.InvariantCultureIgnoreCase))
                                {
                                    quotedPrintableCharset = val;
                                }
                            }
                            metadataStart = j;
                        }
                        j++;
                    }
                }

                i++; // skip colon

                int matchStart = i; // Found the start of a match here

                while ((i = rawText.IndexOf('\n', i)) >= 0)
                { // Really, end in \r\n
                    if (i < rawText.Length - 1 && // But if followed by tab or space,
                            (rawText[i + 1] == ' ' || // this is only a continuation
                            rawText[i + 1] == '\t'))
                    {
                        i += 2; // Skip \n and continutation whitespace
                    }
                    else if (quotedPrintable && // If preceded by = in quoted printable
                          (rawText[i - 1] == '=' || // this is a continuation
                          rawText[i - 2] == '='))
                    {
                        i++; // Skip \n
                    }
                    else
                    {
                        break;
                    }
                }

                if (i < 0)
                {
                    // No terminating end character? uh, done. Set i such that loop terminates and break
                    i = max;
                }
                else if (i > matchStart)
                {
                    // found a match
                    if (matches == null)
                    {
                        matches = new List<string>(1); // lazy init
                    }
                    if (rawText[i - 1] == '\r')
                    {
                        i--; // Back up over \r, which really should be there
                    }
                    String element = rawText.Substring(matchStart, (i) - (matchStart));
                    if (trim)
                    {
                        element = element.Trim();
                    }
                    if (quotedPrintable)
                    {
                        element = DecodeQuotedPrintable(element,
                                quotedPrintableCharset);
                    }
                    else
                    {
                        element = StripContinuationCRLF(element);
                    }
                    matches.Add(element);
                    i++;
                }
                else
                {
                    i++;
                }

            }

            if (matches == null || (matches.Count == 0))
            {
                return null;
            }
            return ToStringArray(matches);
        }

        private static String StripContinuationCRLF(String value)
        {
            int length = value.Length;
            StringBuilder result = new StringBuilder(length);
            bool lastWasLF = false;
            for (int i = 0; i < length; i++)
            {
                if (lastWasLF)
                {
                    lastWasLF = false;
                    continue;
                }
                char c = value[i];
                lastWasLF = false;
                switch ((int)c)
                {
                    case '\n':
                        lastWasLF = true;
                        break;
                    case '\r':
                        break;
                    default:
                        result.Append(c);
                        break;
                }
            }
            return result.ToString();
        }

        private static String DecodeQuotedPrintable(String val, String charset)
        {
            int length = val.Length;
            StringBuilder result = new StringBuilder(length);
            MemoryStream fragmentBuffer = new MemoryStream();
            for (int i = 0; i < length; i++)
            {
                char c = val[i];
                switch ((int)c)
                {
                    case '\r':
                    case '\n':
                        break;
                    case '=':
                        if (i < length - 2)
                        {
                            char nextChar = val[i + 1];
                            if (nextChar == '\r' || nextChar == '\n')
                            {
                                // Ignore, it's just a continuation symbol
                            }
                            else
                            {
                                char nextNextChar = val[i + 2];
                                try
                                {
                                    int encodedByte = 16 * ToHexValue(nextChar)
                                            + ToHexValue(nextNextChar);
                                    fragmentBuffer.WriteByte((byte)encodedByte);
                                }
                                catch (ArgumentException iae)
                                {
                                    // continue, assume it was incorrectly encoded
                                }
                                i += 2;
                            }
                        }
                        break;
                    default:
                        MaybeAppendFragment(fragmentBuffer, charset, result);
                        result.Append(c);
                        break;
                }
            }
            MaybeAppendFragment(fragmentBuffer, charset, result);
            return result.ToString();
        }

        private static int ToHexValue(char c)
        {
            if (c >= '0' && c <= '9')
            {
                return c - '0';
            }
            else if (c >= 'A' && c <= 'F')
            {
                return c - 'A' + 10;
            }
            else if (c >= 'a' && c <= 'f')
            {
                return c - 'a' + 10;
            }
            throw new ArgumentException();
        }

        private static void MaybeAppendFragment(
                MemoryStream fragmentBuffer, String charset,
                StringBuilder result)
        {
            if (fragmentBuffer.Length > 0)
            {
                byte[] fragmentBytes = fragmentBuffer.ToArray();
                String fragment;
                if (charset == null)
                {
                    fragment = Encoding.GetEncoding("CP437").GetString(fragmentBytes,0, fragmentBytes.Length);
                }
                else
                {
                    try
                    {
                        // @TODO: May need to revisit this part
                        fragment = Encoding.GetEncoding(charset).GetString(fragmentBytes, 0, fragmentBytes.Length); ;
                    }
                    catch (IOException e)
                    {
                        // Yikes, well try anyway:
                        fragment = Encoding.GetEncoding("CP437").GetString(fragmentBytes,0, fragmentBytes.Length);
                    }
                }
                fragmentBuffer.SetLength(0);
                result.Append(fragment);
            }
        }

        static internal String MatchSingleVCardPrefixedField(String prefix, String rawText,
                bool trim)
        {
            String[] values = MatchVCardPrefixedField(prefix, rawText, trim);
            return (values == null) ? null : values[0];
        }

        private static bool IsLikeVCardDate(String value)
        {
            if (value == null)
            {
                return true;
            }
            // Not really sure this is true but matches practice
            // Mach YYYYMMDD
            if (IsStringOfDigits(value, 8))
            {
                return true;
            }
            // or YYYY-MM-DD
            return value.Length == 10 && value[4] == '-'
                    && value[7] == '-' && IsSubstringOfDigits(value, 0, 4)
                    && IsSubstringOfDigits(value, 5, 2)
                    && IsSubstringOfDigits(value, 8, 2);
        }

        private static String FormatAddress(String address)
        {
            if (address == null)
            {
                return null;
            }
            int length = address.Length;
            StringBuilder newAddress = new StringBuilder(length);
            for (int j = 0; j < length; j++)
            {
                char c = address[j];
                if (c == ';')
                {
                    newAddress.Append(' ');
                }
                else
                {
                    newAddress.Append(c);
                }
            }
            return newAddress.ToString().Trim();
        }

        /// <summary>
        /// Formats name fields of the form "Public;John;Q.;Reverend;III" into a form like
        /// "Reverend John Q. Public III".
        /// </summary>
        ///
        /// <param name="names">name values to format, in place</param>
        private static void FormatNames(String[] names)
        {
            if (names != null)
            {
                for (int i = 0; i < names.Length; i++)
                {
                    String name = names[i];
                    String[] components = new String[5];
                    int start = 0;
                    int end;
                    int componentIndex = 0;
                    while ((end = name.IndexOf(';', start)) > 0)
                    {
                        components[componentIndex] = name.Substring(start, (end) - (start));
                        componentIndex++;
                        start = end + 1;
                    }
                    components[componentIndex] = name.Substring(start);
                    StringBuilder newName = new StringBuilder(100);
                    MaybeAppendComponent(components, 3, newName);
                    MaybeAppendComponent(components, 1, newName);
                    MaybeAppendComponent(components, 2, newName);
                    MaybeAppendComponent(components, 0, newName);
                    MaybeAppendComponent(components, 4, newName);
                    names[i] = newName.ToString().Trim();
                }
            }
        }

        private static void MaybeAppendComponent(String[] components, int i,
                StringBuilder newName)
        {
            if (components[i] != null)
            {
                newName.Append(' ');
                newName.Append(components[i]);
            }
        }

    }
}