//===============================================================================
// OSML - Open Source Messaging Library
//
//===============================================================================
// Copyright � TWIT88.COM.  All rights reserved.
//
// This file is part of Open Source Messaging Library.
//
// Open Source Messaging Library is free software: you can redistribute it 
// and/or modify it under the terms of the GNU General Public License version 3.
//
// Open Source Messaging Library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this software.  If not, see <http://www.gnu.org/licenses/>.
//===============================================================================

using System;

namespace MessagingToolkit.Barcode.Client.Results
{		
	public sealed class AddressBookParsedResult:ParsedResult
	{
        private string[] names;
        private string pronunciation;
        private string[] phoneNumbers;
        private string[] emails;
        private string note;
        private string[] addresses;
        private string org;
        private string birthday;
        private string title;
        private string url;


        /// <summary>
        /// Gets the names.
        /// </summary>
        /// <value>The names.</value>
		public string[] Names
		{
			get
			{
				return names;
			}
			
		}
        /// <summary>
        /// In Japanese, the name is written in kanji, which can have multiple readings. Therefore a hint
        /// is often provided, called furigana, which spells the name phonetically.
        /// </summary>
        /// <value>The pronunciation.</value>
        /// <returns> The pronunciation of the getNames() field, often in hiragana or katakana.
        /// </returns>
		public string Pronunciation
		{
			get
			{
				return pronunciation;
			}
			
		}
        /// <summary>
        /// Gets the phone numbers.
        /// </summary>
        /// <value>The phone numbers.</value>
		public string[] PhoneNumbers
		{
			get
			{
				return phoneNumbers;
			}
			
		}
        /// <summary>
        /// Gets the emails.
        /// </summary>
        /// <value>The emails.</value>
		public string[] Emails
		{
			get
			{
				return emails;
			}
			
		}
        /// <summary>
        /// Gets the note.
        /// </summary>
        /// <value>The note.</value>
		public string Note
		{
			get
			{
				return note;
			}
			
		}
        /// <summary>
        /// Gets the addresses.
        /// </summary>
        /// <value>The addresses.</value>
		public string[] Addresses
		{
			get
			{
				return addresses;
			}
			
		}
        /// <summary>
        /// Gets the title.
        /// </summary>
        /// <value>The title.</value>
		public string Title
		{
			get
			{
				return title;
			}			
		}


        /// <summary>
        /// Gets the org.
        /// </summary>
        /// <value>The org.</value>
		public string Org
		{
			get
			{
				return org;
			}
			
		}
		public string URL
		{
			get
			{
				return url;
			}
			
		}
        /// <summary>
        /// Gets the birthday.
        /// </summary>
        /// <value>The birthday.</value>
        /// <returns> birthday formatted as yyyyMMdd (e.g. 19780917)
        /// </returns>
		public string Birthday
		{
			get
			{
				return birthday;
			}
			
		}

		override public string DisplayResult
		{
			get
			{
				System.Text.StringBuilder result = new System.Text.StringBuilder(100);
				MaybeAppend(names, result);
				MaybeAppend(pronunciation, result);
				MaybeAppend(title, result);
				MaybeAppend(org, result);
				MaybeAppend(addresses, result);
				MaybeAppend(phoneNumbers, result);
				MaybeAppend(emails, result);
				MaybeAppend(url, result);
				MaybeAppend(birthday, result);
				MaybeAppend(note, result);
				return result.ToString();
			}
			
		}
		
		
		public AddressBookParsedResult(string[] names, string pronunciation, string[] phoneNumbers, string[] emails, string note, string[] addresses, string org, string birthday, string title, string url):base(ParsedResultType.AddessBook)
		{
			this.names = names;
			this.pronunciation = pronunciation;
			this.phoneNumbers = phoneNumbers;
			this.emails = emails;
			this.note = note;
			this.addresses = addresses;
			this.org = org;
			this.birthday = birthday;
			this.title = title;
			this.url = url;
		}
	}
}