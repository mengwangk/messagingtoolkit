﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace MessagingToolkit.Barcode.Client.Results
{
    public class ExpandedProductParsedResult : ParsedResult
    {
        public const String Kilogram = "KG";
        public const String Pound = "LB";

        private readonly String productID;
        private readonly String sscc;
        private readonly String lotNumber;
        private readonly String productionDate;
        private readonly String packagingDate;
        private readonly String bestBeforeDate;
        private readonly String expirationDate;
        private readonly String weight;
        private readonly String weightType;
        private readonly String weightIncrement;
        private readonly String price;
        private readonly String priceIncrement;
        private readonly String priceCurrency;

        // For AIS that not exist in this object
        private readonly Dictionary<string, string> uncommonAIs;

        internal ExpandedProductParsedResult()
            : base(ParsedResultType.Product)
        {
            this.productID = "";
            this.sscc = "";
            this.lotNumber = "";
            this.productionDate = "";
            this.packagingDate = "";
            this.bestBeforeDate = "";
            this.expirationDate = "";
            this.weight = "";
            this.weightType = "";
            this.weightIncrement = "";
            this.price = "";
            this.priceIncrement = "";
            this.priceCurrency = "";
            this.uncommonAIs = new Dictionary<string, string>();
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ExpandedProductParsedResult"/> class.
        /// </summary>
        /// <param name="productID">The product ID.</param>
        /// <param name="sscc">The SSCC.</param>
        /// <param name="lotNumber">The lot number.</param>
        /// <param name="productionDate">The production date.</param>
        /// <param name="packagingDate">The packaging date.</param>
        /// <param name="bestBeforeDate">The best before date.</param>
        /// <param name="expirationDate">The expiration date.</param>
        /// <param name="weight">The weight.</param>
        /// <param name="weightType">Type of the weight.</param>
        /// <param name="weightIncrement">The weight increment.</param>
        /// <param name="price">The price.</param>
        /// <param name="priceIncrement">The price increment.</param>
        /// <param name="priceCurrency">The price currency.</param>
        /// <param name="uncommonAIs">The uncommon A is.</param>
        public ExpandedProductParsedResult(String productID, String sscc,
                String lotNumber, String productionDate, String packagingDate,
                String bestBeforeDate, String expirationDate, String weight,
                String weightType, String weightIncrement, String price,
                String priceIncrement, String priceCurrency, Dictionary<string, string> uncommonAIs)
            : base(ParsedResultType.Product)
        {
            this.productID = productID;
            this.sscc = sscc;
            this.lotNumber = lotNumber;
            this.productionDate = productionDate;
            this.packagingDate = packagingDate;
            this.bestBeforeDate = bestBeforeDate;
            this.expirationDate = expirationDate;
            this.weight = weight;
            this.weightType = weightType;
            this.weightIncrement = weightIncrement;
            this.price = price;
            this.priceIncrement = priceIncrement;
            this.priceCurrency = priceCurrency;
            this.uncommonAIs = uncommonAIs;
        }

        public override bool Equals(Object o)
        {
            if (!(o is ExpandedProductParsedResult))
            {
                return false;
            }

            ExpandedProductParsedResult other = (ExpandedProductParsedResult)o;

            return this.productID.Equals(other.productID)
                    && this.sscc.Equals(other.sscc)
                    && this.lotNumber.Equals(other.lotNumber)
                    && this.productionDate.Equals(other.productionDate)
                    && this.bestBeforeDate.Equals(other.bestBeforeDate)
                    && this.expirationDate.Equals(other.expirationDate)
                    && this.weight.Equals(other.weight)
                    && this.weightType.Equals(other.weightType)
                    && this.weightIncrement.Equals(other.weightIncrement)
                    && this.price.Equals(other.price)
                    && this.priceIncrement.Equals(other.priceIncrement)
                    && this.priceCurrency.Equals(other.priceCurrency)
                    && this.uncommonAIs.Equals(other.uncommonAIs);
        }

        public override int GetHashCode()
        {
            int hash1 = this.productID.GetHashCode();
            hash1 = 31 * hash1 + this.sscc.GetHashCode();
            hash1 = 31 * hash1 + this.lotNumber.GetHashCode();
            hash1 = 31 * hash1 + this.productionDate.GetHashCode();
            hash1 = 31 * hash1 + this.bestBeforeDate.GetHashCode();
            hash1 = 31 * hash1 + this.expirationDate.GetHashCode();
            hash1 = 31 * hash1 + this.weight.GetHashCode();

            int hash2 = this.weightType.GetHashCode();
            hash2 = 31 * hash2 + this.weightIncrement.GetHashCode();
            hash2 = 31 * hash2 + this.price.GetHashCode();
            hash2 = 31 * hash2 + this.priceIncrement.GetHashCode();
            hash2 = 31 * hash2 + this.priceCurrency.GetHashCode();
            hash2 = 31 * hash2 + this.uncommonAIs.GetHashCode();
            return hash1 ^ hash2;
        }

        public String ProductID
        {
            get
            {
                return productID;
            }
        }

        public String Sscc
        {
            get
            {
                return sscc;
            }
        }

        public String LotNumber
        {
            get
            {
                return lotNumber;
            }
        }

        public String ProductionDate
        {
            get
            {
                return productionDate;
            }
        }

        public String PackagingDate
        {
            get
            {
                return packagingDate;
            }
        }

        public String BestBeforeDate
        {
            get
            {
                return bestBeforeDate;
            }
        }

        public String ExpirationDate
        {
            get
            {
                return expirationDate;
            }
        }

        public String Weight
        {
            get
            {
                return weight;
            }
        }

        public String WeightType
        {
            get
            {
                return weightType;
            }
        }

        public String WeightIncrement
        {
            get
            {
                return weightIncrement;
            }
        }

        public String Price
        {
            get
            {
                return price;
            }
        }

        public String PriceIncrement
        {
            get
            {
                return priceIncrement;
            }
        }

        public String PriceCurrency
        {
            get
            {
                return priceCurrency;
            }
        }

        public Dictionary<string, string> UncommonAIs
        {
            get
            {
                return uncommonAIs;
            }
        }

        public override String DisplayResult
        {
            get
            {
                return productID;
            }
        }
    }
}
