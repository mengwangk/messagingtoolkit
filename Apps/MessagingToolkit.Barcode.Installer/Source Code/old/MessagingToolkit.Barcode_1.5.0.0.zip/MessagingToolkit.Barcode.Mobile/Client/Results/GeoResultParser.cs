//===============================================================================
// OSML - Open Source Messaging Library
//
//===============================================================================
// Copyright � TWIT88.COM.  All rights reserved.
//
// This file is part of Open Source Messaging Library.
//
// Open Source Messaging Library is free software: you can redistribute it 
// and/or modify it under the terms of the GNU General Public License version 3.
//
// Open Source Messaging Library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this software.  If not, see <http://www.gnu.org/licenses/>.
//===============================================================================

using System;
using Result = MessagingToolkit.Barcode.Result;

namespace MessagingToolkit.Barcode.Client.Results
{
    /// <summary>
    /// Parses a "geo:" URI result, which specifies a location on the surface of
    /// the Earth as well as an optional altitude above the surface. See
    /// <a href="http://tools.ietf.org/html/draft-mayrhofer-geo-uri-00">
    /// http://tools.ietf.org/html/draft-mayrhofer-geo-uri-00</a>.
    /// </summary>
    internal sealed class GeoResultParser : ResultParser
    {

        private GeoResultParser()
        {
        }

        public static GeoParsedResult Parse(Result result)
        {
            String rawText = result.Text;
            if (rawText == null
                    || (!rawText.StartsWith("geo:") && !rawText.StartsWith("GEO:")))
            {
                return null;
            }
            // Drop geo, query portion
            int queryStart = rawText.IndexOf('?', 4);
            String query;
            String geoURIWithoutQuery;
            if (queryStart < 0)
            {
                query = null;
                geoURIWithoutQuery = rawText.Substring(4);
            }
            else
            {
                query = rawText.Substring(queryStart + 1);
                geoURIWithoutQuery = rawText.Substring(4, (queryStart) - (4));
            }
            int latitudeEnd = geoURIWithoutQuery.IndexOf(',');
            if (latitudeEnd < 0)
            {
                return null;
            }
            int longitudeEnd = geoURIWithoutQuery.IndexOf(',', latitudeEnd + 1);
            double latitude;
            double longitude;
            double altitude;
            try
            {
                latitude = Double.Parse(geoURIWithoutQuery.Substring(0, (latitudeEnd) - (0)));
                if (latitude > 90.0d || latitude < -90.0d)
                {
                    return null;
                } 
                if (longitudeEnd < 0)
                {
                    longitude = Double.Parse(geoURIWithoutQuery.Substring(latitudeEnd + 1));
                    altitude = 0.0d;
                }
                else
                {
                    longitude = Double.Parse(geoURIWithoutQuery.Substring(latitudeEnd + 1, (longitudeEnd) - (latitudeEnd + 1)));
                    altitude = Double.Parse(geoURIWithoutQuery.Substring(longitudeEnd + 1));
                }
                if (longitude > 180.0d || longitude < -180.0d || altitude < 0)
                {
                    return null;
                }
            }
            catch (FormatException nfe)
            {
                return null;
            }
            return new GeoParsedResult(latitude, longitude, altitude, query);
        }

    }
}