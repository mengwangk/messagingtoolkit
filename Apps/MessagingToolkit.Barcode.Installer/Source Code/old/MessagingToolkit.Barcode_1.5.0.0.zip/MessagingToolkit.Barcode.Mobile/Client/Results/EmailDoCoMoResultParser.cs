//===============================================================================
// OSML - Open Source Messaging Library
//
//===============================================================================
// Copyright � TWIT88.COM.  All rights reserved.
//
// This file is part of Open Source Messaging Library.
//
// Open Source Messaging Library is free software: you can redistribute it 
// and/or modify it under the terms of the GNU General Public License version 3.
//
// Open Source Messaging Library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this software.  If not, see <http://www.gnu.org/licenses/>.
//===============================================================================

using System;
using Result = MessagingToolkit.Barcode.Result;

namespace MessagingToolkit.Barcode.Client.Results
{
	
	/// <summary> I
    /// mplements the "MATMSG" email message entry format.
	/// Supported keys: TO, SUB, BODY
	/// </summary>
	sealed class EmailDoCoMoResultParser:AbstractDoCoMoResultParser
	{
		
		private static readonly char[] ATextSymbols = new char[]{'@', '.', '!', '#', '$', '%', '&', '\'', '*', '+', '-', '/', '=', '?', '^', '_', '`', '{', '|', '}', '~'};
		
		public static EmailAddressParsedResult Parse(Result result)
		{
			string rawText = result.Text;
			if (rawText == null || !rawText.StartsWith("MATMSG:"))
			{
				return null;
			}
			string[] rawTo = MatchDoCoMoPrefixedField("TO:", rawText, true);
			if (rawTo == null)
			{
				return null;
			}
			string to = rawTo[0];
			if (!IsBasicallyValidEmailAddress(to))
			{
				return null;
			}
			string subject = MatchSingleDoCoMoPrefixedField("SUB:", rawText, false);
			string body = MatchSingleDoCoMoPrefixedField("BODY:", rawText, false);
			return new EmailAddressParsedResult(to, subject, body, "mailto:" + to);
		}

        /// <summary>
        /// This implements only the most basic checking for an email address's validity -- that it contains
        /// an '@' contains no characters disallowed by RFC 2822. This is an overly lenient definition of
        /// validity. We want to generally be lenient here since this class is only intended to encapsulate what's
        /// in a barcode, not "judge" it.
        /// </summary>
        /// <param name="email">The email.</param>
        /// <returns>
        /// 	<c>true</c> if [is basically valid email address] [the specified email]; otherwise, <c>false</c>.
        /// </returns>
		internal static bool IsBasicallyValidEmailAddress(string email)
		{
			if (email == null)
			{
				return false;
			}
			bool atFound = false;
			for (int i = 0; i < email.Length; i++)
			{
				char c = email[i];
				if ((c < 'a' || c > 'z') && (c < 'A' || c > 'Z') && (c < '0' || c > '9') && !IsAtextSymbol(c))
				{
					return false;
				}
				if (c == '@')
				{
					if (atFound)
					{
						return false;
					}
					atFound = true;
				}
			}
			return atFound;
		}
		
		private static bool IsAtextSymbol(char c)
		{
			for (int i = 0; i < ATextSymbols.Length; i++)
			{
				if (c == ATextSymbols[i])
				{
					return true;
				}
			}
			return false;
		}
	}
}