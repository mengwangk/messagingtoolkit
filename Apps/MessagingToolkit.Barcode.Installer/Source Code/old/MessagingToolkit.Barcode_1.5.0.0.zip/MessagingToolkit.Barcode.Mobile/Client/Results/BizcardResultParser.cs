//===============================================================================
// OSML - Open Source Messaging Library
//
//===============================================================================
// Copyright � TWIT88.COM.  All rights reserved.
//
// This file is part of Open Source Messaging Library.
//
// Open Source Messaging Library is free software: you can redistribute it 
// and/or modify it under the terms of the GNU General Public License version 3.
//
// Open Source Messaging Library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this software.  If not, see <http://www.gnu.org/licenses/>.
//===============================================================================

using System;
using System.Collections.Generic;
using Result = MessagingToolkit.Barcode.Result;

namespace MessagingToolkit.Barcode.Client.Results
{

    /// <summary>
    /// Implements the "BIZCARD" address book entry format, though this has been
    /// largely reverse-engineered from examples observed in the wild -- still
    /// looking for a definitive reference.
    /// </summary>
	sealed class BizcardResultParser:AbstractDoCoMoResultParser
	{
		
		// Yes, we extend AbstractDoCoMoResultParser since the format is very much
		// like the DoCoMo MECARD format, but this is not technically one of 
		// DoCoMo's proposed formats
		
		public static AddressBookParsedResult Parse(Result result)
		{
			string rawText = result.Text;
			if (rawText == null || !rawText.StartsWith("BIZCARD:"))
			{
				return null;
			}
			string firstName = MatchSingleDoCoMoPrefixedField("N:", rawText, true);
			string lastName = MatchSingleDoCoMoPrefixedField("X:", rawText, true);
			string fullName = BuildName(firstName, lastName);
			string title = MatchSingleDoCoMoPrefixedField("T:", rawText, true);
			string org = MatchSingleDoCoMoPrefixedField("C:", rawText, true);
			string[] addresses = MatchDoCoMoPrefixedField("A:", rawText, true);
			string phoneNumber1 = MatchSingleDoCoMoPrefixedField("B:", rawText, true);
			string phoneNumber2 = MatchSingleDoCoMoPrefixedField("M:", rawText, true);
			string phoneNumber3 = MatchSingleDoCoMoPrefixedField("F:", rawText, true);
			string email = MatchSingleDoCoMoPrefixedField("E:", rawText, true);
			
			return new AddressBookParsedResult(MaybeWrap(fullName), null, BuildPhoneNumbers(phoneNumber1, phoneNumber2, phoneNumber3), MaybeWrap(email), null, addresses, org, null, title, null);
		}
		
		private static string[] BuildPhoneNumbers(string number1, string number2, string number3)
		{
			List<string> numbers = new List<string>(3);
			if (number1 != null)
			{
				numbers.Add(number1);
			}
			if (number2 != null)
			{
				numbers.Add(number2);
			}
			if (number3 != null)
			{
				numbers.Add(number3);
			}
			int size = numbers.Count;
			if (size == 0)
			{
				return null;
			}
			string[] result = new string[size];
			for (int i = 0; i < size; i++)
			{
				result[i] = numbers[i];
			}
			return result;
		}
		
		private static string BuildName(string firstName, string lastName)
		{
			if (firstName == null)
			{
				return lastName;
			}
			else
			{
				return lastName == null?firstName:firstName + ' ' + lastName;
			}
		}
	}
}