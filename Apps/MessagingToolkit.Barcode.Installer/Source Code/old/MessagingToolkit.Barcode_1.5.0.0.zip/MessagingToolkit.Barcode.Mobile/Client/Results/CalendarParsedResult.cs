//===============================================================================
// OSML - Open Source Messaging Library
//
//===============================================================================
// Copyright � TWIT88.COM.  All rights reserved.
//
// This file is part of Open Source Messaging Library.
//
// Open Source Messaging Library is free software: you can redistribute it 
// and/or modify it under the terms of the GNU General Public License version 3.
//
// Open Source Messaging Library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this software.  If not, see <http://www.gnu.org/licenses/>.
//===============================================================================

using System;
using System.Text;

namespace MessagingToolkit.Barcode.Client.Results
{

    public sealed class CalendarParsedResult : ParsedResult
    {

        private readonly String summary;
        private readonly String start;
        private readonly String end;
        private readonly String location;
        private readonly String attendee;
        private readonly String description;
        private readonly double latitude;
        private readonly double longitude;

        public CalendarParsedResult(String summary, String start, String end,
                String location, String attendee, String description)
            : this(summary, start, end, location, attendee, description, Double.NaN, System.Double.NaN)
        {
        }

        public CalendarParsedResult(String summary, String start, String end,
                String location, String attendee, String description,
                double latitude, double longitude)
            : base(ParsedResultType.Calendar)
        {
            // Start is required, end is not
            if (start == null)
            {
                throw new ArgumentException();
            }
            ValidateDate(start);
            if (end == null)
            {
                end = start;
            }
            else
            {
                ValidateDate(end);
            }
            this.summary = summary;
            this.start = start;
            this.end = end;
            this.location = location;
            this.attendee = attendee;
            this.description = description;
            this.latitude = latitude;
            this.longitude = longitude;
        }

        public String Summary
        {
            get
            {
                return summary;
            }
        }

        /// <summary>
        /// <p>We would return the start and end date as a <see cref="T:System.DateTime"/> except that this code
        /// needs to work under JavaME / MIDP and there is no date parsing library available there, such
        /// as <c>java.text.SimpleDateFormat</c>.</p> See validateDate() for the return format.
        /// </summary>
        /// <returns>start time formatted as a RFC 2445 DATE or DATE-TIME.</p></returns>
        public String Start
        {
            get
            {
                return start;
            }
        }


        /// <summary>
        /// Gets the end.
        /// </summary>
        /// <returns></returns>
        public String End
        {
            get
            {
                return end;
            }
        }

        public String Location
        {
            get
            {
                return location;
            }
        }

        public String Attendee
        {
            get
            {
                return attendee;
            }
        }

        public String Description
        {
            get
            {
                return description;
            }
        }

        public double Latitude
        {
            get
            {
                return latitude;
            }
        }

        public double Longitude
        {
            get
            {
                return longitude;
            }
        }

        public override String DisplayResult
        {
            get
            {
                StringBuilder result = new StringBuilder(100);
                ParsedResult.MaybeAppend(summary, result);
                ParsedResult.MaybeAppend(start, result);
                ParsedResult.MaybeAppend(end, result);
                ParsedResult.MaybeAppend(location, result);
                ParsedResult.MaybeAppend(attendee, result);
                ParsedResult.MaybeAppend(description, result);
                return result.ToString();
            }
        }

        /// <summary>
        /// RFC 2445 allows the start and end fields to be of type DATE (e.g. 20081021) or DATE-TIME
        /// (e.g. 20081021T123000 for local time, or 20081021T123000Z for UTC).
        /// </summary>
        ///
        /// <param name="date">The string to validate</param>
        private static void ValidateDate(String date)
        {
            if (date != null)
            {
                int length = date.Length;
                if (length != 8 && length != 15 && length != 16)
                {
                    throw new ArgumentException();
                }
                for (int i = 0; i < 8; i++)
                {
                    if (!Char.IsDigit(date[i]))
                    {
                        throw new ArgumentException();
                    }
                }
                if (length > 8)
                {
                    if (date[8] != 'T')
                    {
                        throw new ArgumentException();
                    }
                    for (int i_0 = 9; i_0 < 15; i_0++)
                    {
                        if (!Char.IsDigit(date[i_0]))
                        {
                            throw new ArgumentException();
                        }
                    }
                    if (length == 16 && date[15] != 'Z')
                    {
                        throw new ArgumentException();
                    }
                }
            }
        }

    }
}