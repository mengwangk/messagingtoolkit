//===============================================================================
// OSML - Open Source Messaging Library
//
//===============================================================================
// Copyright � TWIT88.COM.  All rights reserved.
//
// This file is part of Open Source Messaging Library.
//
// Open Source Messaging Library is free software: you can redistribute it 
// and/or modify it under the terms of the GNU General Public License version 3.
//
// Open Source Messaging Library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this software.  If not, see <http://www.gnu.org/licenses/>.
//===============================================================================

using System;
using System.Text;
using Result = MessagingToolkit.Barcode.Result;

namespace MessagingToolkit.Barcode.Client.Results
{

    /// <summary>
    /// Abstract class representing the result of decoding a barcode, as more than
    /// a String -- as some type of structured data. This might be a subclass which represents
    /// a URL, or an e-mail address. {@link ResultParser#parseResult(Result)} will turn a raw
    /// decoded string into the most appropriate type of structured representation.
    /// </summary>
	public abstract class ParsedResult
	{
        private ParsedResultType type;
		
		virtual public ParsedResultType Type
		{
			get
			{
				return type;
			}
			
		}
		
        public abstract string DisplayResult
        {
            get;
        }
			
		protected internal ParsedResult(ParsedResultType type)
		{
			this.type = type;
		}
		
		public override string ToString()
		{
			return DisplayResult;
		}
		
		public static void  MaybeAppend(string value, StringBuilder result)
		{
			if (value != null && value.Length > 0)
			{
				// Don't add a newline before the first value
				if (result.Length > 0)
				{
					result.Append('\n');
				}
				result.Append(value);
			}
		}
		
		public static void  MaybeAppend(string[] value, StringBuilder result)
		{
			if (value != null)
			{
				for (int i = 0; i < value.Length; i++)
				{
					if (value[i] != null && value[i].Length > 0)
					{
						if (result.Length > 0)
						{
							result.Append('\n');
						}
						result.Append(value[i]);
					}
				}
			}
		}
	}
}