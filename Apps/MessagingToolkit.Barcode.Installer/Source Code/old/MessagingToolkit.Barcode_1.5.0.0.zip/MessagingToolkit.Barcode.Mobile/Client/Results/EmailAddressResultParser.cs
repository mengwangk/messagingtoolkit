//===============================================================================
// OSML - Open Source Messaging Library
//
//===============================================================================
// Copyright � TWIT88.COM.  All rights reserved.
//
// This file is part of Open Source Messaging Library.
//
// Open Source Messaging Library is free software: you can redistribute it 
// and/or modify it under the terms of the GNU General Public License version 3.
//
// Open Source Messaging Library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this software.  If not, see <http://www.gnu.org/licenses/>.
//===============================================================================

using System;
using System.Collections.Generic;
using Result = MessagingToolkit.Barcode.Result;

namespace MessagingToolkit.Barcode.Client.Results
{

    /// <summary>
    /// Represents a result that encodes an e-mail address, either as a plain address
    /// like "joe@example.org" or a mailto: URL like "mailto:joe@example.org".
    /// </summary>
	sealed class EmailAddressResultParser:ResultParser
	{
		
		public static EmailAddressParsedResult Parse(Result result)
		{
			string rawText = result.Text;
			if (rawText == null)
			{
				return null;
			}
			string emailAddress;
			if (rawText.StartsWith("mailto:") || rawText.StartsWith("MAILTO:"))
			{
				// If it starts with mailto:, assume it is definitely trying to be an email address
				emailAddress = rawText.Substring(7);
				int queryStart = emailAddress.IndexOf('?');
				if (queryStart >= 0)
				{
					emailAddress = emailAddress.Substring(0, (queryStart) - (0));
				}
                Dictionary<string, string> nameValues = ParseNameValuePairs(rawText);
				string subject = null;
				string body = null;
				if (nameValues != null)
				{
					if (emailAddress.Length == 0)
					{
						emailAddress = nameValues["to"];
					}
					subject = nameValues["subject"];
					body = nameValues["body"];
				}
				return new EmailAddressParsedResult(emailAddress, subject, body, rawText);
			}
			else
			{
				if (!EmailDoCoMoResultParser.IsBasicallyValidEmailAddress(rawText))
				{
					return null;
				}
				emailAddress = rawText;
				return new EmailAddressParsedResult(emailAddress, null, null, "mailto:" + emailAddress);
			}
		}
	}
}