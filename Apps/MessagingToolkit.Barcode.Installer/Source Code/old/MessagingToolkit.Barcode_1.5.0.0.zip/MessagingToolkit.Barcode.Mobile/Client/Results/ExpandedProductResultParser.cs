﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace MessagingToolkit.Barcode.Client.Results
{
    /// <summary>
    /// Parses strings of digits that represent a RSS Extended code.
    /// </summary>
    internal sealed class ExpandedProductResultParser : ResultParser
    {

        private ExpandedProductResultParser()
        {
        }

        // Treat all RSS EXPANDED, in the sense that they are all
        // product barcodes with complementary data.
        public static ExpandedProductParsedResult Parse(Result result)
        {
            BarcodeFormat format = result.BarcodeFormat;
            if (BarcodeFormat.RSSExpanded != format)
            {
                // ExtendedProductParsedResult NOT created. Not a RSS Expanded barcode
                return null;
            }
            // Really neither of these should happen:
            String rawText = result.Text;
            if (rawText == null)
            {
                // ExtendedProductParsedResult NOT created. Input text is NULL
                return null;
            }

            String productID = "-";
            String sscc = "-";
            String lotNumber = "-";
            String productionDate = "-";
            String packagingDate = "-";
            String bestBeforeDate = "-";
            String expirationDate = "-";
            String weight = "-";
            String weightType = "-";
            String weightIncrement = "-";
            String price = "-";
            String priceIncrement = "-";
            String priceCurrency = "-";
            Dictionary<string, string> uncommonAIs = new Dictionary<string, string>();

            int i = 0;

            while (i < rawText.Length)
            {
                String ai = FindAIvalue(i, rawText);
                if ("ERROR".Equals(ai))
                {
                    // Error. Code doesn't match with RSS expanded pattern
                    // ExtendedProductParsedResult NOT created. Not match with RSS Expanded pattern
                    return null;
                }
                i += ai.Length + 2;
                String val = FindValue(i, rawText);
                i += val.Length;

                if ("00".Equals(ai))
                {
                    sscc = val;
                }
                else if ("01".Equals(ai))
                {
                    productID = val;
                }
                else if ("10".Equals(ai))
                {
                    lotNumber = val;
                }
                else if ("11".Equals(ai))
                {
                    productionDate = val;
                }
                else if ("13".Equals(ai))
                {
                    packagingDate = val;
                }
                else if ("15".Equals(ai))
                {
                    bestBeforeDate = val;
                }
                else if ("17".Equals(ai))
                {
                    expirationDate = val;
                }
                else if ("3100".Equals(ai) || "3101".Equals(ai)
                      || "3102".Equals(ai) || "3103".Equals(ai)
                      || "3104".Equals(ai) || "3105".Equals(ai)
                      || "3106".Equals(ai) || "3107".Equals(ai)
                      || "3108".Equals(ai) || "3109".Equals(ai))
                {
                    weight = val;
                    weightType = ExpandedProductParsedResult.Kilogram;
                    weightIncrement = ai.Substring(3);
                }
                else if ("3200".Equals(ai) || "3201".Equals(ai)
                      || "3202".Equals(ai) || "3203".Equals(ai)
                      || "3204".Equals(ai) || "3205".Equals(ai)
                      || "3206".Equals(ai) || "3207".Equals(ai)
                      || "3208".Equals(ai) || "3209".Equals(ai))
                {
                    weight = val;
                    weightType = ExpandedProductParsedResult.Pound;
                    weightIncrement = ai.Substring(3);
                }
                else if ("3920".Equals(ai) || "3921".Equals(ai)
                      || "3922".Equals(ai) || "3923".Equals(ai))
                {
                    price = val;
                    priceIncrement = ai.Substring(3);
                }
                else if ("3930".Equals(ai) || "3931".Equals(ai)
                      || "3932".Equals(ai) || "3933".Equals(ai))
                {
                    if (val.Length < 4)
                    {
                        // The value must have more of 3 symbols (3 for currency and
                        // 1 at least for the price)
                        // ExtendedProductParsedResult NOT created. Not match with RSS Expanded pattern
                        return null;
                    }
                    price = val.Substring(3);
                    priceCurrency = val.Substring(0, (3) - (0));
                    priceIncrement = ai.Substring(3);
                }
                else
                {
                    // No match with common AIs
                    uncommonAIs.Add(ai, val);
                }
            }

            return new ExpandedProductParsedResult(productID, sscc, lotNumber,
                    productionDate, packagingDate, bestBeforeDate, expirationDate,
                    weight, weightType, weightIncrement, price, priceIncrement,
                    priceCurrency, uncommonAIs);
        }

        private static String FindAIvalue(int i, String rawText)
        {
            StringBuilder buf = new StringBuilder();
            char c = rawText[i];
            // First character must be a open parenthesis.If not, ERROR
            if (c != '(')
            {
                return "ERROR";
            }

            String rawTextAux = rawText.Substring(i + 1);

            for (int index = 0; index < rawTextAux.Length; index++)
            {
                char currentChar = rawTextAux[index];
                switch ((int)currentChar)
                {
                    case '0':
                    case '1':
                    case '2':
                    case '3':
                    case '4':
                    case '5':
                    case '6':
                    case '7':
                    case '8':
                    case '9':
                        buf.Append(currentChar);
                        break;
                    case ')':
                        return buf.ToString();
                    default:
                        return "ERROR";
                }
            }
            return buf.ToString();
        }

        private static String FindValue(int i, String rawText)
        {
            StringBuilder buf = new StringBuilder();
            String rawTextAux = rawText.Substring(i);

            for (int index = 0; index < rawTextAux.Length; index++)
            {
                char c = rawTextAux[index];
                if (c == '(')
                {
                    // We look for a new AI. If it doesn't exist (ERROR), we coninue
                    // with the iteration
                    if ("ERROR".Equals(FindAIvalue(index, rawTextAux)))
                    {
                        buf.Append('(');
                    }
                    else
                    {
                        break;
                    }
                }
                else
                {
                    buf.Append(c);
                }
            }
            return buf.ToString();
        }
    }
}
