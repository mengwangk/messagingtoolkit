//===============================================================================
// OSML - Open Source Messaging Library
//
//===============================================================================
// Copyright � TWIT88.COM.  All rights reserved.
//
// This file is part of Open Source Messaging Library.
//
// Open Source Messaging Library is free software: you can redistribute it 
// and/or modify it under the terms of the GNU General Public License version 3.
//
// Open Source Messaging Library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this software.  If not, see <http://www.gnu.org/licenses/>.
//===============================================================================

using System;

namespace MessagingToolkit.Barcode.Client.Results
{

	public sealed class URIParsedResult:ParsedResult
	{
        private string uri;
        private string title;

		public string Uri
		{
			get
			{
				return uri;
			}
			
		}
		public string Title
		{
			get
			{
				return title;
			}
			
		}
        /// <summary>
        /// Gets a value indicating whether [possibly malicious URI].
        /// </summary>
        /// <value>
        /// 	<c>true</c> if [possibly malicious URI]; otherwise, <c>false</c>.
        /// </value>
        /// <returns> true if the URI contains suspicious patterns that may suggest it intends to
        /// mislead the user about its true nature. At the moment this looks for the presence
        /// of user/password syntax in the host/authority portion of a URI which may be used
        /// in attempts to make the URI's host appear to be other than it is. Example:
        /// http://yourbank.com@phisher.com  This URI connects to phisher.com but may appear
        /// to connect to yourbank.com at first glance.
        /// </returns>
		public bool PossiblyMaliciousUri
		{
			get
			{
				return ContainsUser();
			}
			
		}
		override public string DisplayResult
		{
			get
			{
				System.Text.StringBuilder result = new System.Text.StringBuilder(30);
				MaybeAppend(title, result);
				MaybeAppend(uri, result);
				return result.ToString();
			}
			
		}	
		
		public URIParsedResult(string uri, string title):base(ParsedResultType.Uri)
		{
			this.uri = MassageURI(uri);
			this.title = title;
		}
		
		private bool ContainsUser()
		{
			// This method is likely not 100% RFC compliant yet
			int hostStart = uri.IndexOf(':'); // we should always have scheme at this point
			hostStart++;
			// Skip slashes preceding host
			int uriLength = uri.Length;
			while (hostStart < uriLength && uri[hostStart] == '/')
			{
				hostStart++;
			}
			int hostEnd = uri.IndexOf('/', hostStart);
			if (hostEnd < 0)
			{
				hostEnd = uriLength;
			}
			int at = uri.IndexOf('@', hostStart);
			return at >= hostStart && at < hostEnd;
		}

        /// <summary>
        /// Transforms a string that represents a URI into something more proper, by adding or canonicalizing
        /// the protocol.
        /// </summary>
        /// <param name="uri">The URI.</param>
        /// <returns></returns>
		private static string MassageURI(string uri)
		{
            uri = uri.Trim();
			int protocolEnd = uri.IndexOf(':');
			if (protocolEnd < 0)
			{
				// No protocol, assume http
				uri = "http://" + uri;
			}
			else if (IsColonFollowedByPortNumber(uri, protocolEnd))
			{
				// Found a colon, but it looks like it is after the host, so the protocol is still missing
				uri = "http://" + uri;
			}
			else
			{
				// Lowercase protocol to avoid problems
				uri = uri.Substring(0, (protocolEnd) - (0)).ToLower() + uri.Substring(protocolEnd);
			}
			return uri;
		}

        /// <summary>
        /// Determines whether [is colon followed by port number] [the specified URI].
        /// </summary>
        /// <param name="uri">The URI.</param>
        /// <param name="protocolEnd">The protocol end.</param>
        /// <returns>
        /// 	<c>true</c> if [is colon followed by port number] [the specified URI]; otherwise, <c>false</c>.
        /// </returns>
		private static bool IsColonFollowedByPortNumber(string uri, int protocolEnd)
		{
			int nextSlash = uri.IndexOf('/', protocolEnd + 1);
			if (nextSlash < 0)
			{
				nextSlash = uri.Length;
			}
			if (nextSlash <= protocolEnd + 1)
			{
				return false;
			}
			for (int x = protocolEnd + 1; x < nextSlash; x++)
			{
				if (uri[x] < '0' || uri[x] > '9')
				{
					return false;
				}
			}
			return true;
		}
	}
}