//===============================================================================
// OSML - Open Source Messaging Library
//
//===============================================================================
// Copyright � TWIT88.COM.  All rights reserved.
//
// This file is part of Open Source Messaging Library.
//
// Open Source Messaging Library is free software: you can redistribute it 
// and/or modify it under the terms of the GNU General Public License version 3.
//
// Open Source Messaging Library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this software.  If not, see <http://www.gnu.org/licenses/>.
//===============================================================================

using System;
using Result = MessagingToolkit.Barcode.Result;

namespace MessagingToolkit.Barcode.Client.Results
{
	
	/// <summary> 
    /// Implements the "MECARD" address book entry format.
	/// Supported keys: N, SOUND, TEL, EMAIL, NOTE, ADR, BDAY, URL, plus ORG
	/// Unsupported keys: TEL-AV, NICKNAME
	/// 
	/// Except for TEL, multiple values for keys are also not supported;
	/// the first one found takes precedence.
	/// 
	/// Our understanding of the MECARD format is based on this document:
	/// 
	/// http://www.mobicode.org.tw/files/OMIA%20Mobile%20Bar%20Code%20Standard%20v3.2.1.doc 
	/// 
	/// </summary>	
	sealed class AddressBookDoCoMoResultParser:AbstractDoCoMoResultParser
	{
		
		public static AddressBookParsedResult Parse(Result result)
		{
			string rawText = result.Text;
			if (rawText == null || !rawText.StartsWith("MECARD:"))
			{
				return null;
			}
			string[] rawName = MatchDoCoMoPrefixedField("N:", rawText, true);
			if (rawName == null)
			{
				return null;
			}
			string name = ParseName(rawName[0]);
			string pronunciation = MatchSingleDoCoMoPrefixedField("SOUND:", rawText, true);
			string[] phoneNumbers = MatchDoCoMoPrefixedField("TEL:", rawText, true);
			string[] emails = MatchDoCoMoPrefixedField("EMAIL:", rawText, true);
			string note = MatchSingleDoCoMoPrefixedField("NOTE:", rawText, false);
			string[] addresses = MatchDoCoMoPrefixedField("ADR:", rawText, true);
			string birthday = MatchSingleDoCoMoPrefixedField("BDAY:", rawText, true);
			if (birthday != null && !IsStringOfDigits(birthday, 8))
			{
				// No reason to throw out the whole card because the birthday is formatted wrong.
				birthday = null;
			}
			string url = MatchSingleDoCoMoPrefixedField("URL:", rawText, true);
			
			// Although ORG may not be strictly legal in MECARD, it does exist in VCARD and we might as well
			// honor it when found in the wild.
			string org = MatchSingleDoCoMoPrefixedField("ORG:", rawText, true);
			
			return new AddressBookParsedResult(MaybeWrap(name), pronunciation, phoneNumbers, emails, note, addresses, org, birthday, null, url);
		}
		
		private static string ParseName(string name)
		{
			int comma = name.IndexOf(',');
			if (comma >= 0)
			{
				// Format may be last,first; switch it around
				return name.Substring(comma + 1) + ' ' + name.Substring(0, (comma) - (0));
			}
			return name;
		}
	}
}