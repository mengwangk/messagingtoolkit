//===============================================================================
// OSML - Open Source Messaging Library
//
//===============================================================================
// Copyright � TWIT88.COM.  All rights reserved.
//
// This file is part of Open Source Messaging Library.
//
// Open Source Messaging Library is free software: you can redistribute it 
// and/or modify it under the terms of the GNU General Public License version 3.
//
// Open Source Messaging Library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this software.  If not, see <http://www.gnu.org/licenses/>.
//===============================================================================


using System;
using Result = MessagingToolkit.Barcode.Result;

namespace MessagingToolkit.Barcode.Client.Results
{
	
	/// <summary> 
    /// Parses a "tel:" URI result, which specifies a phone number.
	/// </summary>
	sealed class TelResultParser:ResultParser
	{
		
		private TelResultParser()
		{
		}
		
		public static TelParsedResult Parse(Result result)
		{
			string rawText = result.Text;
			if (rawText == null || (!rawText.StartsWith("tel:") && !rawText.StartsWith("TEL:")))
			{
				return null;
			}
			// Normalize "TEL:" to "tel:"
			string telURI = rawText.StartsWith("TEL:")?"tel:" + rawText.Substring(4):rawText;
			// Drop tel, query portion
			int queryStart = rawText.IndexOf('?', 4);
			string number = queryStart < 0?rawText.Substring(4):rawText.Substring(4, (queryStart) - (4));
			return new TelParsedResult(number, telURI, null);
		}
	}
}