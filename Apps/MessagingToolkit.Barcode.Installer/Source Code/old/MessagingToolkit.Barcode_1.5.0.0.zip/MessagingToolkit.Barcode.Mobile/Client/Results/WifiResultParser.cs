﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MessagingToolkit.Barcode.Client.Results
{
    /// <summary>
    /// Parses a WIFI configuration string.  Strings will be of the form:
    /// WIFI:T:WPA;S:mynetwork;P:mypass;;
    /// The fields can come in any order, and there should be tests to see
    /// if we can parse them all correctly.
    /// </summary>
    internal sealed class WifiResultParser : ResultParser
    {

        private WifiResultParser()
        {
        }

        public static WifiParsedResult Parse(Result result)
        {
            String rawText = result.Text;

            if (rawText == null || !rawText.StartsWith("WIFI:"))
            {
                return null;
            }

            // Don't remove leading or trailing whitespace
            bool trim = false;
            String ssid = MatchSinglePrefixedField("S:", rawText, ';', trim);
            String pass = MatchSinglePrefixedField("P:", rawText, ';', trim);
            String type = MatchSinglePrefixedField("T:", rawText, ';', trim);

            return new WifiParsedResult(type, ssid, pass);
        }
    }
}
