//===============================================================================
// OSML - Open Source Messaging Library
//
//===============================================================================
// Copyright � TWIT88.COM.  All rights reserved.
//
// This file is part of Open Source Messaging Library.
//
// Open Source Messaging Library is free software: you can redistribute it 
// and/or modify it under the terms of the GNU General Public License version 3.
//
// Open Source Messaging Library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this software.  If not, see <http://www.gnu.org/licenses/>.
//===============================================================================

using System;
using System.Collections.Generic;
using Result = MessagingToolkit.Barcode.Result;

namespace MessagingToolkit.Barcode.Client.Results
{

    /// <summary>
    ///   <p>Parses an "sms:" URI result, which specifies a number to SMS.
    /// See <a href="http://tools.ietf.org/html/rfc5724"> RFC 5724</a> on this.</p>
    ///   <p>This class supports "via" syntax for numbers, which is not part of the spec.
    /// For example "+12125551212;via=+12124440101" may appear as a number.
    /// It also supports a "subject" query parameter, which is not mentioned in the spec.
    /// These are included since they were mentioned in earlier IETF drafts and might be
    /// used.</p>
    ///   <p>This actually also parses URIs starting with "mms:" and treats them all the same way,
    /// and effectively converts them to an "sms:" URI for purposes of forwarding to the platform.</p>
    /// </summary>
    internal sealed class SMSMMSResultParser : ResultParser
    {

        private SMSMMSResultParser()
        {
        }

        public static SMSParsedResult Parse(Result result)
        {
            String rawText = result.Text;
            if (rawText == null)
            {
                return null;
            }
            if (!(rawText.StartsWith("sms:") || rawText.StartsWith("SMS:")
                    || rawText.StartsWith("mms:") || rawText.StartsWith("MMS:")))
            {
                return null;
            }

            // Check up front if this is a URI syntax string with query arguments
            Dictionary<string, string> nameValuePairs = ParseNameValuePairs(rawText);
            String subject = null;
            String body = null;
            bool querySyntax = false;
            if (nameValuePairs != null && !(nameValuePairs.Count == 0))
            {
                if (nameValuePairs.ContainsKey("subject"))
                    subject = nameValuePairs["subject"];
                if (nameValuePairs.ContainsKey("body"))
                    body = nameValuePairs["body"];
                querySyntax = true;
            }

            // Drop sms, query portion
            int queryStart = rawText.IndexOf('?', 4);
            String smsURIWithoutQuery;
            // If it's not query syntax, the question mark is part of the subject or message
            if (queryStart < 0 || !querySyntax)
            {
                smsURIWithoutQuery = rawText.Substring(4);
            }
            else
            {
                smsURIWithoutQuery = rawText.Substring(4, (queryStart) - (4));
            }

            int lastComma = -1;
            int comma;
            List<string> numbers = new List<string>(1);
            List<string> vias = new List<string>(1);
            while ((comma = smsURIWithoutQuery.IndexOf(',', lastComma + 1)) > lastComma)
            {
                String numberPart = smsURIWithoutQuery.Substring(lastComma + 1, (comma) - (lastComma + 1));
                AddNumberVia(numbers, vias, numberPart);
                lastComma = comma;
            }
            AddNumberVia(numbers, vias, smsURIWithoutQuery.Substring(lastComma + 1));

            return new SMSParsedResult(ToStringArray(numbers), ToStringArray(vias), subject, body);
        }

        private static void AddNumberVia(List<string> numbers, List<string> vias, String numberPart)
        {
            int numberEnd = numberPart.IndexOf(';');
            if (numberEnd < 0)
            {
                numbers.Add(numberPart);
                vias.Add(null);
            }
            else
            {
                numbers.Add(numberPart.Substring(0, (numberEnd) - (0)));
                String maybeVia = numberPart.Substring(numberEnd + 1);
                String via;
                if (maybeVia.StartsWith("via="))
                {
                    via = maybeVia.Substring(4);
                }
                else
                {
                    via = null;
                }
                vias.Add(via);
            }
        }

    }
}