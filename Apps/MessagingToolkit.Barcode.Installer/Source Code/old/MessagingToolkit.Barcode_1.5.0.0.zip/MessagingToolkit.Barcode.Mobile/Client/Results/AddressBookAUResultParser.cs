//===============================================================================
// OSML - Open Source Messaging Library
//
//===============================================================================
// Copyright � TWIT88.COM.  All rights reserved.
//
// This file is part of Open Source Messaging Library.
//
// Open Source Messaging Library is free software: you can redistribute it 
// and/or modify it under the terms of the GNU General Public License version 3.
//
// Open Source Messaging Library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this software.  If not, see <http://www.gnu.org/licenses/>.
//===============================================================================

using System;
using System.Collections.Generic;
using System.Collections;
using Result = MessagingToolkit.Barcode.Result;


namespace MessagingToolkit.Barcode.Client.Results
{
	
	/// <summary> 
    /// Implements KDDI AU's address book format. See
	/// <a href="http://www.au.kddi.com/ezfactory/tec/two_dimensions/index.html">
	/// http://www.au.kddi.com/ezfactory/tec/two_dimensions/index.html</a>.
	/// </summary>	
	sealed class AddressBookAUResultParser:ResultParser
	{
		
		public static AddressBookParsedResult Parse(Result result)
		{
			string rawText = result.Text;
			// MEMORY is mandatory; seems like a decent indicator, as does end-of-record separator CR/LF
			if (rawText == null || rawText.IndexOf("MEMORY") < 0 || rawText.IndexOf("\r\n") < 0)
			{
				return null;
			}
			
			// NAME1 and NAME2 have specific uses, namely written name and pronunciation, respectively.
			// Therefore we treat them specially instead of as an array of names.
			string name = MatchSinglePrefixedField("NAME1:", rawText, '\r', true);
			string pronunciation = MatchSinglePrefixedField("NAME2:", rawText, '\r', true);
			
			string[] phoneNumbers = MatchMultipleValuePrefix("TEL", 3, rawText, true);
			string[] emails = MatchMultipleValuePrefix("MAIL", 3, rawText, true);
			string note = MatchSinglePrefixedField("MEMORY:", rawText, '\r', false);
			string address = MatchSinglePrefixedField("ADD:", rawText, '\r', true);
			string[] addresses = address == null?null:new string[]{address};
			return new AddressBookParsedResult(MaybeWrap(name), pronunciation, phoneNumbers, emails, note, addresses, null, null, null, null);
		}
		
		private static string[] MatchMultipleValuePrefix(string prefix, int max, string rawText, bool trim)
		{
			List<string> values = null;
			for (int i = 1; i <= max; i++)
			{
				string val = MatchSinglePrefixedField(prefix + i + ':', rawText, '\r', trim);
				if (val == null)
				{
					break;
				}
				if (values == null)
				{
					values = new List<string>(max); // lazy init
				}
				values.Add(val);
			}
			if (values == null)
			{
				return null;
			}
			return ToStringArray(values);
		}
	}
}