//===============================================================================
// OSML - Open Source Messaging Library
//
//===============================================================================
// Copyright � TWIT88.COM.  All rights reserved.
//
// This file is part of Open Source Messaging Library.
//
// Open Source Messaging Library is free software: you can redistribute it 
// and/or modify it under the terms of the GNU General Public License version 3.
//
// Open Source Messaging Library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this software.  If not, see <http://www.gnu.org/licenses/>.
//===============================================================================


using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;

using Result = MessagingToolkit.Barcode.Result;

namespace MessagingToolkit.Barcode.Client.Results
{
    /// <summary>
    /// <p>Abstract class representing the result of decoding a barcode, as more than
    /// a String -- as some type of structured data. This might be a subclass which represents
    /// a URL, or an e-mail address. <see cref="M:MessagingToolkit.Barcode.Client.Result.ResultParser.ParseResult(MessagingToolkit.Barcode.Client.Result.Result)"/> will turn a raw
    /// decoded string into the most appropriate type of structured representation.</p>
    /// <p>Thanks to Jeff Griffin for proposing rewrite of these classes that relies less
    /// on exception-based mechanisms during parsing.</p>
    /// </summary>
    public abstract class ResultParser
    {

        public static ParsedResult ParseResult(Result theResult)
        {
            // This is a bit messy, but given limited options in MIDP / CLDC, this may well be the simplest
            // way to go about this. For example, we have no reflection available, really.
            // Order is important here.
            ParsedResult result;
            if ((result = BookmarkDoCoMoResultParser.Parse(theResult)) != null)
            {
                return result;
            }
            else if ((result = AddressBookDoCoMoResultParser.Parse(theResult)) != null)
            {
                return result;
            }
            else if ((result = EmailDoCoMoResultParser.Parse(theResult)) != null)
            {
                return result;
            }
            else if ((result = AddressBookAUResultParser.Parse(theResult)) != null)
            {
                return result;
            }
            else if ((result = VCardResultParser.Parse(theResult)) != null)
            {
                return result;
            }
            else if ((result = BizcardResultParser.Parse(theResult)) != null)
            {
                return result;
            }
            else if ((result = VEventResultParser.Parse(theResult)) != null)
            {
                return result;
            }
            else if ((result = EmailAddressResultParser.Parse(theResult)) != null)
            {
                return result;
            }
            else if ((result = SMTPResultParser.Parse(theResult)) != null)
            {
                return result;
            }
            else if ((result = TelResultParser.Parse(theResult)) != null)
            {
                return result;
            }
            else if ((result = SMSMMSResultParser.Parse(theResult)) != null)
            {
                return result;
            }
            else if ((result = SmsToMmsToResultParser.Parse(theResult)) != null)
            {
                return result;
            }
            else if ((result = GeoResultParser.Parse(theResult)) != null)
            {
                return result;
            }
            else if ((result = WifiResultParser.Parse(theResult)) != null)
            {
                return result;
            }
            else if ((result = URLTOResultParser.Parse(theResult)) != null)
            {
                return result;
            }
            else if ((result = URIResultParser.Parse(theResult)) != null)
            {
                // URI is a catch-all for protocol: contents that we don't handle explicitly above.
                return result;
            }
            else if ((result = ISBNResultParser.Parse(theResult)) != null)
            {
                // We depend on ISBN parsing coming before UPC, as it is a subset.
                return result;
            }
            else if ((result = ProductResultParser.Parse(theResult)) != null)
            {
                return result;
            }
            else if ((result = ExpandedProductResultParser.Parse(theResult)) != null)
            {
                return result;
            }
            return new TextParsedResult(theResult.Text, null);
        }

        protected static internal void MaybeAppend(String val, StringBuilder result)
        {
            if (val != null)
            {
                result.Append('\n');
                result.Append(val);
            }
        }

        protected static internal void MaybeAppend(String[] val, StringBuilder result)
        {
            if (val != null)
            {
                for (int i = 0; i < val.Length; i++)
                {
                    result.Append('\n');
                    result.Append(val[i]);
                }
            }
        }

        protected static internal String[] MaybeWrap(String val)
        {
            return (val == null) ? null : new String[] { val };
        }

        protected static internal String UnescapeBackslash(String escaped)
        {
            if (escaped != null)
            {
                int backslash = escaped.IndexOf('\\');
                if (backslash >= 0)
                {
                    int max = escaped.Length;
                    StringBuilder unescaped = new StringBuilder(max - 1);
                    unescaped.Append(escaped.ToCharArray(), 0, backslash);
                    bool nextIsEscaped = false;
                    for (int i = backslash; i < max; i++)
                    {
                        char c = escaped[i];
                        if (nextIsEscaped || c != '\\')
                        {
                            unescaped.Append(c);
                            nextIsEscaped = false;
                        }
                        else
                        {
                            nextIsEscaped = true;
                        }
                    }
                    return unescaped.ToString();
                }
            }
            return escaped;
        }

        private static String UrlDecode(String escaped)
        {
            // No we can't use java.net.URLDecoder here. JavaME doesn't have it.
            if (escaped == null)
            {
                return null;
            }
            char[] escapedArray = escaped.ToCharArray();

            int first = FindFirstEscape(escapedArray);
            if (first < 0)
            {
                return escaped;
            }

            int max = escapedArray.Length;
            // Final length is at most 2 less than original due to at least 1 unescaping.
            StringBuilder unescaped = new StringBuilder(max - 2);
            // Can append everything up to first escape character
            unescaped.Append(escapedArray, 0, first);

            for (int i = first; i < max; i++)
            {
                char c = escapedArray[i];
                switch ((int)c)
                {
                    case '+':
                        // + is translated directly into a space
                        unescaped.Append(' ');
                        break;
                    case '%':
                        // Are there even two more chars? If not we'll just copy the escaped sequence and be done.
                        if (i >= max - 2)
                        {
                            unescaped.Append('%'); // append that % and move on
                        }
                        else
                        {
                            int firstDigitValue = ParseHexDigit(escapedArray[++i]);
                            int secondDigitValue = ParseHexDigit(escapedArray[++i]);
                            if (firstDigitValue < 0 || secondDigitValue < 0)
                            {
                                // Bad digit, just move on.
                                unescaped.Append('%');
                                unescaped.Append(escapedArray[i - 1]);
                                unescaped.Append(escapedArray[i]);
                            }
                            unescaped
                                    .Append((char)((firstDigitValue << 4) + secondDigitValue));
                        }
                        break;
                    default:
                        unescaped.Append(c);
                        break;
                }
            }
            return unescaped.ToString();
        }

        private static int FindFirstEscape(char[] escapedArray)
        {
            int max = escapedArray.Length;
            for (int i = 0; i < max; i++)
            {
                char c = escapedArray[i];
                if (c == '+' || c == '%')
                {
                    return i;
                }
            }
            return -1;
        }

        private static int ParseHexDigit(char c)
        {
            if (c >= 'a')
            {
                if (c <= 'f')
                {
                    return 10 + (c - 'a');
                }
            }
            else if (c >= 'A')
            {
                if (c <= 'F')
                {
                    return 10 + (c - 'A');
                }
            }
            else if (c >= '0')
            {
                if (c <= '9')
                {
                    return c - '0';
                }
            }
            return -1;
        }

        protected static internal bool IsStringOfDigits(String val, int length)
        {
            if (val == null)
            {
                return false;
            }
            int stringLength = val.Length;
            if (length != stringLength)
            {
                return false;
            }
            for (int i = 0; i < length; i++)
            {
                char c = val[i];
                if (c < '0' || c > '9')
                {
                    return false;
                }
            }
            return true;
        }

        protected static internal bool IsSubstringOfDigits(String val, int offset,
                int length)
        {
            if (val == null)
            {
                return false;
            }
            int stringLength = val.Length;
            int max = offset + length;
            if (stringLength < max)
            {
                return false;
            }
            for (int i = offset; i < max; i++)
            {
                char c = val[i];
                if (c < '0' || c > '9')
                {
                    return false;
                }
            }
            return true;
        }

        static internal Dictionary<string,string> ParseNameValuePairs(String uri)
        {
            int paramStart = uri.IndexOf('?');
            if (paramStart < 0)
            {
                return null;
            }
            Dictionary<string, string> result = new Dictionary<string, string>(3);
            paramStart++;
            int paramEnd;
            while ((paramEnd = uri.IndexOf('&', paramStart)) >= 0)
            {
                AppendKeyValue(uri, paramStart, paramEnd, result);
                paramStart = paramEnd + 1;
            }
            AppendKeyValue(uri, paramStart, uri.Length, result);
            return result;
        }

        private static void AppendKeyValue(String uri, int paramStart,
                int paramEnd, Dictionary<string, string> result)
        {
            int separator = uri.IndexOf('=', paramStart);
            if (separator >= 0)
            {
                // key = value
                String key = uri.Substring(paramStart, (separator) - (paramStart));
                String val = uri.Substring(separator + 1, (paramEnd) - (separator + 1));
                val = UrlDecode(val);
                result.Add(key, val);
            }
            // Can't put key, null into a dictionary
        }

        static internal String[] MatchPrefixedField(String prefix, String rawText,
                char endChar, bool trim)
        {
            List<string> matches = null;
            int i = 0;
            int max = rawText.Length;
            while (i < max)
            {
                i = rawText.IndexOf(prefix, i);
                if (i < 0)
                {
                    break;
                }
                i += prefix.Length; // Skip past this prefix we found to start
                int start = i; // Found the start of a match here
                bool done = false;
                while (!done)
                {
                    i = rawText.IndexOf(endChar, i);
                    if (i < 0)
                    {
                        // No terminating end character? uh, done. Set i such that loop terminates and break
                        i = rawText.Length;
                        done = true;
                    }
                    else if (rawText[i - 1] == '\\')
                    {
                        // semicolon was escaped so continue
                        i++;
                    }
                    else
                    {
                        // found a match
                        if (matches == null)
                        {
                            matches = new List<string>(3); // lazy init
                        }
                        String element = UnescapeBackslash(rawText.Substring(start, (i) - (start)));
                        if (trim)
                        {
                            element = element.Trim();
                        }
                        matches.Add(element);
                        i++;
                        done = true;
                    }
                }
            }
            if (matches == null || (matches.Count == 0))
            {
                return null;
            }
            return ToStringArray(matches);
        }

        static internal String MatchSinglePrefixedField(String prefix, String rawText,
                char endChar, bool trim)
        {
            String[] matches = MatchPrefixedField(prefix, rawText, endChar, trim);
            return (matches == null) ? null : matches[0];
        }

        static internal String[] ToStringArray(List<string> strings)
        {
            int size = strings.Count;
            String[] result = new String[size];
            for (int j = 0; j < size; j++)
            {
                result[j] = strings[j];
            }
            return result;
        }

    }
}