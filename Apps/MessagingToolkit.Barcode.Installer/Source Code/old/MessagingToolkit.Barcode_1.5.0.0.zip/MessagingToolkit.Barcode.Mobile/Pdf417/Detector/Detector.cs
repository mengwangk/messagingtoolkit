using MessagingToolkit.Barcode.Common;
using System;
using System.Collections.Generic;

namespace MessagingToolkit.Barcode.Pdf417.Detector
{
    /// <summary>
    /// <p>Encapsulates logic that can detect a PDF417 Code in an image, even if the
    /// PDF417 Code is rotated or skewed, or partially obscured.</p>
    /// </summary>
    public sealed class Detector
    {
        private const int MaxAvgVariance = (int)((1 << 8) * 0.42f);
        private const int MaxIndividualVariance = (int)((1 << 8) * 0.8f);
        private const int SkewThreshold = 2;

        // B S B S B S B S Bar/Space pattern
        // 11111111 0 1 0 1 0 1 000
        private static readonly int[] StartPattern = { 8, 1, 1, 1, 1, 1, 1, 3 };

        // 11111111 0 1 0 1 0 1 000
        private static readonly int[] StartPatternReverse = { 3, 1, 1, 1, 1, 1, 1, 8 };

        // 1111111 0 1 000 1 0 1 00 1
        private static readonly int[] StopPattern = { 7, 1, 1, 3, 1, 1, 1, 2, 1 };

        // B S B S B S B S B Bar/Space pattern
        // 1111111 0 1 000 1 0 1 00 1
        private static readonly int[] StopPatternReverse = { 1, 2, 1, 1, 1, 3, 1, 1, 7 };

        private readonly BinaryBitmap image;

        public Detector(BinaryBitmap image)
        {
            this.image = image;
        }

        /// <summary>
        ///   <p>Detects a PDF417 Code in an image, simply.</p>
        /// </summary>
        /// <returns>
        /// /// <see cref="null"/>
        /// encapsulating results of detecting a PDF417 Code
        /// </returns>
        /// <exception cref="NotFoundException">if no QR Code can be found</exception>
        public DetectorResult Detect()
        {
            return Detect(null);
        }

        /// <summary>
        /// <p>Detects a PDF417 Code in an image. Only checks 0 and 180 degree rotations.</p>
        /// </summary>
        ///
        /// <param name="hints">optional hints to detector</param>
        /// <returns>/// <see cref="null"/>
        ///  encapsulating results of detecting a PDF417 Code</returns>
        /// <exception cref="NotFoundException">if no PDF417 Code can be found</exception>
        public DetectorResult Detect(Dictionary<DecodeOptions, object> decodingOptions)
        {
            // Fetch the 1 bit matrix once up front.
            BitMatrix matrix = image.BlackMatrix;

            // Try to find the vertices assuming the image is upright.
            ResultPoint[] vertices = FindVertices(matrix);
            if (vertices == null)
            {
                // Maybe the image is rotated 180 degrees?
                vertices = FindVertices180(matrix);
                if (vertices != null)
                {
                    CorrectCodeWordVertices(vertices, true);
                }
            }
            else
            {
                CorrectCodeWordVertices(vertices, false);
            }

            if (vertices == null)
            {
                throw NotFoundException.Instance;
            }

            float moduleWidth = ComputeModuleWidth(vertices);
            if (moduleWidth < 1.0f)
            {
                throw NotFoundException.Instance;
            }

            int dimension = ComputeDimension(vertices[4], vertices[6], vertices[5], vertices[7], moduleWidth);
            if (dimension < 1)
            {
                throw NotFoundException.Instance;
            }

            // Deskew and sample image.
            BitMatrix bits = SampleGrid(matrix, vertices[4], vertices[5], vertices[6], vertices[7], dimension);
            return new DetectorResult(bits, new ResultPoint[] { vertices[4], vertices[5], vertices[6], vertices[7] });
        }

        /// <summary>
        /// Locate the vertices and the codewords area of a black blob using the Start
        /// and Stop patterns as locators.
        /// TODO: Scanning every row is very expensive. We should only do this for TRY_HARDER.
        /// </summary>
        ///
        /// <param name="matrix">the scanned barcode image.</param>
        /// <returns>an array containing the vertices:
        /// vertices[0] x, y top left barcode
        /// vertices[1] x, y bottom left barcode
        /// vertices[2] x, y top right barcode
        /// vertices[3] x, y bottom right barcode
        /// vertices[4] x, y top left codeword area
        /// vertices[5] x, y bottom left codeword area
        /// vertices[6] x, y top right codeword area
        /// vertices[7] x, y bottom right codeword area</returns>
        private static ResultPoint[] FindVertices(BitMatrix matrix)
        {
            int height = matrix.Height;
            int width = matrix.Width;

            ResultPoint[] result = new ResultPoint[8];
            bool found = false;

            // Top Left
            for (int i = 0; i < height; i++)
            {
                int[] loc = FindGuardPattern(matrix, 0, i, width, false,
                        StartPattern);
                if (loc != null)
                {
                    result[0] = new ResultPoint(loc[0], i);
                    result[4] = new ResultPoint(loc[1], i);
                    found = true;
                    break;
                }
            }
            // Bottom left
            if (found)
            { // Found the Top Left vertex
                found = false;
                for (int i = height - 1; i > 0; i--)
                {
                    int[] loc_1 = FindGuardPattern(matrix, 0, i, width, false,
                            StartPattern);
                    if (loc_1 != null)
                    {
                        result[1] = new ResultPoint(loc_1[0], i);
                        result[5] = new ResultPoint(loc_1[1], i);
                        found = true;
                        break;
                    }
                }
            }
            // Top right
            if (found)
            { // Found the Bottom Left vertex
                found = false;
                for (int i = 0; i < height; i++)
                {
                    int[] loc = FindGuardPattern(matrix, 0, i, width, false,
                            StopPattern);
                    if (loc != null)
                    {
                        result[2] = new ResultPoint(loc[1], i);
                        result[6] = new ResultPoint(loc[0], i);
                        found = true;
                        break;
                    }
                }
            }
            // Bottom right
            if (found)
            { // Found the Top right vertex
                found = false;
                for (int i = height - 1; i > 0; i--)
                {
                    int[] loc_5 = FindGuardPattern(matrix, 0, i, width, false,
                            StopPattern);
                    if (loc_5 != null)
                    {
                        result[3] = new ResultPoint(loc_5[1], i);
                        result[7] = new ResultPoint(loc_5[0], i);
                        found = true;
                        break;
                    }
                }
            }
            return (found) ? result : null;
        }

        /// <summary>
        /// Locate the vertices and the codewords area of a black blob using the Start
        /// and Stop patterns as locators. This assumes that the image is rotated 180
        /// degrees and if it locates the start and stop patterns at it will re-map
        /// the vertices for a 0 degree rotation.
        /// TODO: Change assumption about barcode location.
        /// TODO: Scanning every row is very expensive. We should only do this for TRY_HARDER.
        /// </summary>
        ///
        /// <param name="matrix">the scanned barcode image.</param>
        /// <returns>an array containing the vertices:
        /// vertices[0] x, y top left barcode
        /// vertices[1] x, y bottom left barcode
        /// vertices[2] x, y top right barcode
        /// vertices[3] x, y bottom right barcode
        /// vertices[4] x, y top left codeword area
        /// vertices[5] x, y bottom left codeword area
        /// vertices[6] x, y top right codeword area
        /// vertices[7] x, y bottom right codeword area</returns>
        private static ResultPoint[] FindVertices180(BitMatrix matrix)
        {
            int height = matrix.Height;
            int width = matrix.Width;
            int halfWidth = width >> 1;

            ResultPoint[] result = new ResultPoint[8];
            bool found = false;

            // Top Left
            for (int i = height - 1; i > 0; i--)
            {
                int[] loc = FindGuardPattern(matrix, halfWidth, i, halfWidth, true,
                        StartPatternReverse);
                if (loc != null)
                {
                    result[0] = new ResultPoint(loc[1], i);
                    result[4] = new ResultPoint(loc[0], i);
                    found = true;
                    break;
                }
            }
            // Bottom Left
            if (found)
            { // Found the Top Left vertex
                found = false;
                for (int i_0 = 0; i_0 < height; i_0++)
                {
                    int[] loc_1 = FindGuardPattern(matrix, halfWidth, i_0, halfWidth,
                            true, StartPatternReverse);
                    if (loc_1 != null)
                    {
                        result[1] = new ResultPoint(loc_1[1], i_0);
                        result[5] = new ResultPoint(loc_1[0], i_0);
                        found = true;
                        break;
                    }
                }
            }
            // Top Right
            if (found)
            { // Found the Bottom Left vertex
                found = false;
                for (int i = height - 1; i > 0; i--)
                {
                    int[] loc = FindGuardPattern(matrix, 0, i, halfWidth, false,
                            StopPatternReverse);
                    if (loc != null)
                    {
                        result[2] = new ResultPoint(loc[0], i);
                        result[6] = new ResultPoint(loc[1], i);
                        found = true;
                        break;
                    }
                }
            }
            // Bottom Right
            if (found)
            { // Found the Top Right vertex
                found = false;
                for (int i = 0; i < height; i++)
                {
                    int[] loc = FindGuardPattern(matrix, 0, i, halfWidth, false,
                            StopPatternReverse);
                    if (loc != null)
                    {
                        result[3] = new ResultPoint(loc[0], i);
                        result[7] = new ResultPoint(loc[1], i);
                        found = true;
                        break;
                    }
                }
            }
            return (found) ? result : null;
        }

        /// <summary>
        /// Because we scan horizontally to detect the start and stop patterns, the vertical component of
        /// the codeword coordinates will be slightly wrong if there is any skew or rotation in the image.
        /// This method moves those points back onto the edges of the theoretically perfect bounding
        /// quadrilateral if needed.
        /// </summary>
        ///
        /// <param name="vertices">The eight vertices located by findVertices().</param>
        private static void CorrectCodeWordVertices(ResultPoint[] vertices, bool upsideDown)
        {
            float skew = vertices[4].Y - vertices[6].Y;
            if (upsideDown)
            {
                skew = -skew;
            }
            if (skew > SkewThreshold)
            {
                // Fix v4
                float length = vertices[4].X - vertices[0].X;
                float deltax = vertices[6].X - vertices[0].X;
                float deltay = vertices[6].Y - vertices[0].Y;
                float correction = length * deltay / deltax;
                vertices[4] = new ResultPoint(vertices[4].X, vertices[4].Y + correction);
            }
            else if (-skew > SkewThreshold)
            {
                // Fix v6
                float length_0 = vertices[2].X - vertices[6].X;
                float deltax_1 = vertices[2].X - vertices[4].X;
                float deltay_2 = vertices[2].Y - vertices[4].Y;
                float correction = length_0 * deltay_2 / deltax_1;
                vertices[6] = new ResultPoint(vertices[6].X, vertices[6].Y - correction);
            }

            skew = vertices[7].Y - vertices[5].Y;
            if (upsideDown)
            {
                skew = -skew;
            }
            if (skew > SkewThreshold)
            {
                // Fix v5
                float length_4 = vertices[5].X - vertices[1].X;
                float deltax_5 = vertices[7].X - vertices[1].X;
                float deltay_6 = vertices[7].Y - vertices[1].Y;
                float correction_7 = length_4 * deltay_6 / deltax_5;
                vertices[5] = new ResultPoint(vertices[5].X, vertices[5].Y + correction_7);
            }
            else if (-skew > SkewThreshold)
            {
                // Fix v7
                float length_8 = vertices[3].X - vertices[7].X;
                float deltax_9 = vertices[3].X - vertices[5].X;
                float deltay_10 = vertices[3].Y - vertices[5].Y;
                float correction_11 = length_8 * deltay_10 / deltax_9;
                vertices[7] = new ResultPoint(vertices[7].X, vertices[7].Y - correction_11);
            }
        }

        /// <summary>
        /// <p>Estimates module size (pixels in a module) based on the Start and End
        /// finder patterns.</p>
        /// </summary>
        ///
        /// <param name="vertices">vertices[1] x, y bottom left barcode vertices[2] x, y top right barcode vertices[3] x, y bottom right barcode vertices[4] x, y top left codeword area vertices[5] x, y bottom left codeword area vertices[6] x, y top right codeword area vertices[7] x, y bottom right codeword area</param>
        /// <returns>the module size.</returns>
        private static float ComputeModuleWidth(ResultPoint[] vertices)
        {
            float pixels1 = MessagingToolkit.Barcode.ResultPoint.Distance(vertices[0], vertices[4]);
            float pixels2 = MessagingToolkit.Barcode.ResultPoint.Distance(vertices[1], vertices[5]);
            float moduleWidth1 = (pixels1 + pixels2) / (17 * 2.0f);
            float pixels3 = MessagingToolkit.Barcode.ResultPoint.Distance(vertices[6], vertices[2]);
            float pixels4 = MessagingToolkit.Barcode.ResultPoint.Distance(vertices[7], vertices[3]);
            float moduleWidth2 = (pixels3 + pixels4) / (18 * 2.0f);
            return (moduleWidth1 + moduleWidth2) / 2.0f;
        }

        /// <summary>
        /// Computes the dimension (number of modules in a row) of the PDF417 Code
        /// based on vertices of the codeword area and estimated module size.
        /// </summary>
        ///
        /// <param name="topLeft">of codeword area</param>
        /// <param name="topRight">of codeword area</param>
        /// <param name="bottomLeft">of codeword area</param>
        /// <param name="bottomRight">of codeword are</param>
        /// <param name="moduleWidth">estimated module size</param>
        /// <returns>the number of modules in a row.</returns>
        private static int ComputeDimension(ResultPoint topLeft,
                ResultPoint topRight, ResultPoint bottomLeft,
                ResultPoint bottomRight, float moduleWidth)
        {
            int topRowDimension = Round(MessagingToolkit.Barcode.ResultPoint.Distance(topLeft, topRight)
                    / moduleWidth);
            int bottomRowDimension = Round(MessagingToolkit.Barcode.ResultPoint.Distance(bottomLeft,
                    bottomRight) / moduleWidth);
            return ((((topRowDimension + bottomRowDimension) >> 1) + 8) / 17) * 17;
            /*
            * int topRowDimension = round(ResultPoint.distance(topLeft,
            * topRight)); //moduleWidth); int bottomRowDimension =
            * round(ResultPoint.distance(bottomLeft, bottomRight)); //
            * moduleWidth); int dimension = ((topRowDimension + bottomRowDimension)
            * >> 1); // Round up to nearest 17 modules i.e. there are 17 modules per
            * codeword //int dimension = ((((topRowDimension + bottomRowDimension) >>
            * 1) + 8) / 17) * 17; return dimension;
            */
        }

        private static BitMatrix SampleGrid(BitMatrix matrix, ResultPoint topLeft,
                ResultPoint bottomLeft, ResultPoint topRight,
                ResultPoint bottomRight, int dimension)
        {

            // Note that unlike the QR Code sampler, we didn't find the center of modules, but the
            // very corners. So there is no 0.5f here; 0.0f is right.
            GridSampler sampler = MessagingToolkit.Barcode.Common.GridSampler.GetInstance();

            return sampler.SampleGrid(matrix, dimension, dimension, 0.0f, // p1ToX
                    0.0f, // p1ToY
                    dimension, // p2ToX
                    0.0f, // p2ToY
                    dimension, // p3ToX
                    dimension, // p3ToY
                    0.0f, // p4ToX
                    dimension, // p4ToY
                    topLeft.X, // p1FromX
                    topLeft.Y, // p1FromY
                    topRight.X, // p2FromX
                    topRight.Y, // p2FromY
                    bottomRight.X, // p3FromX
                    bottomRight.Y, // p3FromY
                    bottomLeft.X, // p4FromX
                    bottomLeft.Y); // p4FromY
        }

        /// <summary>
        /// Ends up being a bit faster than Math.round(). This merely rounds its
        /// argument to the nearest int, where x.5 rounds up.
        /// </summary>
        ///
        private static int Round(float d)
        {
            return (int)(d + 0.5f);
        }


        /// <param name="matrix">row of black/white values to search</param>
        /// <param name="column">x position to start search</param>
        /// <param name="row">y position to start search</param>
        /// <param name="width">the number of pixels to search on this row</param>
        /// <param name="pattern"></param>
        /// <returns>start/end horizontal offset of guard pattern, as an array of two ints.</returns>
        private static int[] FindGuardPattern(BitMatrix matrix, int column,
                int row, int width, bool whiteFirst, int[] pattern)
        {
            int patternLength = pattern.Length;
            // TODO: Find a way to cache this array, as this method is called hundreds of times
            // per image, and we want to allocate as seldom as possible.
            int[] counters = new int[patternLength];
            bool isWhite = whiteFirst;

            int counterPosition = 0;
            int patternStart = column;
            for (int x = column; x < column + width; x++)
            {
                bool pixel = matrix.Get(x, row);
                if (pixel ^ isWhite)
                {
                    counters[counterPosition]++;
                }
                else
                {
                    if (counterPosition == patternLength - 1)
                    {
                        if (PatternMatchVariance(counters, pattern,
                                MaxIndividualVariance) < MaxAvgVariance)
                        {
                            return new int[] { patternStart, x };
                        }
                        patternStart += counters[0] + counters[1];
                        for (int y = 2; y < patternLength; y++)
                        {
                            counters[y - 2] = counters[y];
                        }
                        counters[patternLength - 2] = 0;
                        counters[patternLength - 1] = 0;
                        counterPosition--;
                    }
                    else
                    {
                        counterPosition++;
                    }
                    counters[counterPosition] = 1;
                    isWhite = !isWhite;
                }
            }
            return null;
        }

        /// <summary>
        /// Determines how closely a set of observed counts of runs of black/white
        /// values matches a given target pattern. This is reported as the ratio of
        /// the total variance from the expected pattern proportions across all
        /// pattern elements, to the length of the pattern.
        /// </summary>
        ///
        /// <param name="counters">observed counters</param>
        /// <param name="pattern">expected pattern</param>
        /// <param name="maxIndividualVariance">The most any counter can differ before we give up</param>
        /// <returns>ratio of total variance between counters and pattern compared to
        /// total pattern size, where the ratio has been multiplied by 256.
        /// So, 0 means no variance (perfect match); 256 means the total
        /// variance between counters and patterns equals the pattern length,
        /// higher values mean even more variance</returns>
        private static int PatternMatchVariance(int[] counters, int[] pattern,
                int maxIndividualVariance)
        {
            int numCounters = counters.Length;
            int total = 0;
            int patternLength = 0;
            for (int i = 0; i < numCounters; i++)
            {
                total += counters[i];
                patternLength += pattern[i];
            }
            if (total < patternLength)
            {
                // If we don't even have one pixel per unit of bar width, assume this
                // is too small to reliably match, so fail:
                return Int32.MaxValue;
            }
            // We're going to fake floating-point math in integers. We just need to use more bits.
            // Scale up patternLength so that intermediate values below like scaledCounter will have
            // more "significant digits".
            int unitBarWidth = (total << 8) / patternLength;
            maxIndividualVariance = (maxIndividualVariance * unitBarWidth) >> 8;

            int totalVariance = 0;
            for (int x = 0; x < numCounters; x++)
            {
                int counter = counters[x] << 8;
                int scaledPattern = pattern[x] * unitBarWidth;
                int variance = (counter > scaledPattern) ? counter - scaledPattern
                        : scaledPattern - counter;
                if (variance > maxIndividualVariance)
                {
                    return Int32.MaxValue;
                }
                totalVariance += variance;
            }
            return totalVariance / total;
        }

    }
}
