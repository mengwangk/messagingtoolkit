using MessagingToolkit.Barcode;
using MessagingToolkit.Barcode.Common;
using System;
using System.Collections;
using System.ComponentModel;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text;

namespace MessagingToolkit.Barcode.Pdf417.Decoder
{
    /// <summary>
    /// <p>This class contains the methods for decoding the PDF417 codewords.</p>
    /// </summary>
    internal sealed class DecodedBitStreamParser
    {

        private const int TextCompactionModeLatch = 900;
        private const int ByteCompactionModeLatch = 901;
        private const int NumericCompactionModeLatch = 902;
        private const int ByteCompactionModeLatch6 = 924;
        private const int BeginMacroPdf417ControlBlock = 928;
        private const int BeginMacroPdf417OptionalField = 923;
        private const int MacroPdf417Terminator = 922;
        private const int ModeShiftToByteCompactionMode = 913;
        private const int MaxNumericCodeWords = 15;

        private const int Alpha = 0;
        private const int Lower = 1;
        private const int Mixed = 2;
        private const int Punct = 3;
        private const int AlphaShift = 4;
        private const int PunctShift = 5;

        private const int PL = 25;
        private const int LL = 27;
        private const int AS = 27;
        private const int ML = 28;
        private const int AL = 28;
        private const int PS = 29;
        private const int PAL = 29;

        private static readonly char[] PunctChars = new char[] { ';', '<', '>', '@', '[', (char)(92), '}', '_', (char)(96), '~', '!', (char)(13), (char)(9), ',', ':', (char)(10), '-', '.', '$', '/', (char)(34), '|', '*', '(', ')', '?', '{', '}', (char)(39) };

        private static readonly char[] MixedChars = new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '&', (char)(13), (char)(9), ',', ':', '#', '-', '.', '$', '/', '+', '%', '*', '=', '^' };

        // Table containing values for the exponent of 900.
        // This is used in the numeric compaction decode algorithm.
        private static readonly String[] EXP900 = {
				"000000000000000000000000000000000000000000001",
				"000000000000000000000000000000000000000000900",
				"000000000000000000000000000000000000000810000",
				"000000000000000000000000000000000000729000000",
				"000000000000000000000000000000000656100000000",
				"000000000000000000000000000000590490000000000",
				"000000000000000000000000000531441000000000000",
				"000000000000000000000000478296900000000000000",
				"000000000000000000000430467210000000000000000",
				"000000000000000000387420489000000000000000000",
				"000000000000000348678440100000000000000000000",
				"000000000000313810596090000000000000000000000",
				"000000000282429536481000000000000000000000000",
				"000000254186582832900000000000000000000000000",
				"000228767924549610000000000000000000000000000",
				"205891132094649000000000000000000000000000000" };

        private DecodedBitStreamParser()
        {
        }

        static internal DecoderResult Decode(int[] codewords)
        {
            StringBuilder result = new StringBuilder(100);
            // Get compaction mode
            int codeIndex = 1;
            int code = codewords[codeIndex++];
            while (codeIndex < codewords[0])
            {
                switch (code)
                {
                    case TextCompactionModeLatch:
                        codeIndex = TextCompaction(codewords, codeIndex, result);
                        break;
                    case ByteCompactionModeLatch:
                        codeIndex = ByteCompaction(code, codewords, codeIndex, result);
                        break;
                    case NumericCompactionModeLatch:
                        codeIndex = NumericCompaction(codewords, codeIndex, result);
                        break;
                    case ModeShiftToByteCompactionMode:
                        codeIndex = ByteCompaction(code, codewords, codeIndex, result);
                        break;
                    case ByteCompactionModeLatch6:
                        codeIndex = ByteCompaction(code, codewords, codeIndex, result);
                        break;
                    default:
                        // Default to text compaction. During testing numerous barcodes
                        // appeared to be missing the starting mode. In these cases defaulting
                        // to text compaction seems to work.
                        codeIndex--;
                        codeIndex = TextCompaction(codewords, codeIndex, result);
                        break;
                }
                if (codeIndex < codewords.Length)
                {
                    code = codewords[codeIndex++];
                }
                else
                {
                    throw FormatException.Instance;
                }
            }
            return new DecoderResult(null, result.ToString(), null, null);
        }

        /// <summary>
        /// Text Compaction mode (see 5.4.1.5) permits all printable ASCII characters to be
        /// encoded, i.e. values 32 - 126 inclusive in accordance with ISO/IEC 646 (IRV), as
        /// well as selected control characters.
        /// </summary>
        ///
        /// <param name="codewords">The array of codewords (data + error)</param>
        /// <param name="codeIndex">The current index into the codeword array.</param>
        /// <param name="result">The decoded data is appended to the result.</param>
        /// <returns>The next index into the codeword array.</returns>
        private static int TextCompaction(int[] codewords, int codeIndex,
                StringBuilder result)
        {
            // 2 character per codeword
            int[] textCompactionData = new int[codewords[0] << 1];
            // Used to hold the byte compaction value if there is a mode shift
            int[] byteCompactionData = new int[codewords[0] << 1];

            int index = 0;
            bool end = false;
            while ((codeIndex < codewords[0]) && !end)
            {
                int code = codewords[codeIndex++];
                if (code < TextCompactionModeLatch)
                {
                    textCompactionData[index] = code / 30;
                    textCompactionData[index + 1] = code % 30;
                    index += 2;
                }
                else
                {
                    switch (code)
                    {
                        case TextCompactionModeLatch:
                            codeIndex--;
                            end = true;
                            break;
                        case ByteCompactionModeLatch:
                            codeIndex--;
                            end = true;
                            break;
                        case NumericCompactionModeLatch:
                            codeIndex--;
                            end = true;
                            break;
                        case ModeShiftToByteCompactionMode:
                            // The Mode Shift codeword 913 shall cause a temporary
                            // switch from Text Compaction mode to Byte Compaction mode.
                            // This switch shall be in effect for only the next codeword,
                            // after which the mode shall revert to the prevailing sub-mode
                            // of the Text Compaction mode. Codeword 913 is only available
                            // in Text Compaction mode; its use is described in 5.4.2.4.
                            textCompactionData[index] = ModeShiftToByteCompactionMode;
                            code = codewords[codeIndex++];
                            byteCompactionData[index] = code; //Integer.toHexString(code);
                            index++;
                            break;
                        case ByteCompactionModeLatch6:
                            codeIndex--;
                            end = true;
                            break;
                    }
                }
            }
            DecodeTextCompaction(textCompactionData, byteCompactionData, index,
                    result);
            return codeIndex;
        }

        /// <summary>
        /// The Text Compaction mode includes all the printable ASCII characters
        /// (i.e. values from 32 to 126) and three ASCII control characters: HT or tab
        /// (ASCII value 9), LF or line feed (ASCII value 10), and CR or carriage
        /// return (ASCII value 13). The Text Compaction mode also includes various latch
        /// and shift characters which are used exclusively within the mode. The Text
        /// Compaction mode encodes up to 2 characters per codeword. The compaction rules
        /// for converting data into PDF417 codewords are defined in 5.4.2.2. The sub-mode
        /// switches are defined in 5.4.2.3.
        /// </summary>
        ///
        /// <param name="textCompactionData">The text compaction data.</param>
        /// <param name="byteCompactionData"></param>
        /// <param name="length">The size of the text compaction and byte compaction data.</param>
        /// <param name="result">The decoded data is appended to the result.</param>
        private static void DecodeTextCompaction(int[] textCompactionData,
                int[] byteCompactionData, int length, StringBuilder result)
        {
            // Beginning from an initial state of the Alpha sub-mode
            // The default compaction mode for PDF417 in effect at the start of each symbol shall always be Text
            // Compaction mode Alpha sub-mode (uppercase alphabetic). A latch codeword from another mode to the Text
            // Compaction mode shall always switch to the Text Compaction Alpha sub-mode.
            int subMode = Alpha;
            int priorToShiftMode = Alpha;
            int i = 0;
            while (i < length)
            {
                int subModeCh = textCompactionData[i];
                char ch = (char)(0);
                switch (subMode)
                {
                    case Alpha:
                        // Alpha (uppercase alphabetic)
                        if (subModeCh < 26)
                        {
                            // Upper case Alpha Character
                            ch = (char)('A' + subModeCh);
                        }
                        else
                        {
                            if (subModeCh == 26)
                            {
                                ch = ' ';
                            }
                            else if (subModeCh == LL)
                            {
                                subMode = Lower;
                            }
                            else if (subModeCh == ML)
                            {
                                subMode = Mixed;
                            }
                            else if (subModeCh == PS)
                            {
                                // Shift to punctuation
                                priorToShiftMode = subMode;
                                subMode = PunctShift;
                            }
                            else if (subModeCh == ModeShiftToByteCompactionMode)
                            {
                                result.Append((char)byteCompactionData[i]);
                            }
                        }
                        break;

                    case Lower:
                        // Lower (lowercase alphabetic)
                        if (subModeCh < 26)
                        {
                            ch = (char)('a' + subModeCh);
                        }
                        else
                        {
                            if (subModeCh == 26)
                            {
                                ch = ' ';
                            }
                            else if (subModeCh == AS)
                            {
                                // Shift to alpha
                                priorToShiftMode = subMode;
                                subMode = AlphaShift;
                            }
                            else if (subModeCh == ML)
                            {
                                subMode = Mixed;
                            }
                            else if (subModeCh == PS)
                            {
                                // Shift to punctuation
                                priorToShiftMode = subMode;
                                subMode = PunctShift;
                            }
                            else if (subModeCh == ModeShiftToByteCompactionMode)
                            {
                                result.Append((char)byteCompactionData[i]);
                            }
                        }
                        break;

                    case Mixed:
                        // Mixed (numeric and some punctuation)
                        if (subModeCh < PL)
                        {
                            ch = MixedChars[subModeCh];
                        }
                        else
                        {
                            if (subModeCh == PL)
                            {
                                subMode = Punct;
                            }
                            else if (subModeCh == 26)
                            {
                                ch = ' ';
                            }
                            else if (subModeCh == LL)
                            {
                                subMode = Lower;
                            }
                            else if (subModeCh == AL)
                            {
                                subMode = Alpha;
                            }
                            else if (subModeCh == PS)
                            {
                                // Shift to punctuation
                                priorToShiftMode = subMode;
                                subMode = PunctShift;
                            }
                            else if (subModeCh == ModeShiftToByteCompactionMode)
                            {
                                result.Append((char)byteCompactionData[i]);
                            }
                        }
                        break;

                    case Punct:
                        // Punctuation
                        if (subModeCh < PAL)
                        {
                            ch = PunctChars[subModeCh];
                        }
                        else
                        {
                            if (subModeCh == PAL)
                            {
                                subMode = Alpha;
                            }
                            else if (subModeCh == ModeShiftToByteCompactionMode)
                            {
                                result.Append((char)byteCompactionData[i]);
                            }
                        }
                        break;

                    case AlphaShift:
                        // Restore sub-mode
                        subMode = priorToShiftMode;
                        if (subModeCh < 26)
                        {
                            ch = (char)('A' + subModeCh);
                        }
                        else
                        {
                            if (subModeCh == 26)
                            {
                                ch = ' ';
                            }
                            else
                            {
                                // is this even possible?
                            }
                        }
                        break;

                    case PunctShift:
                        // Restore sub-mode
                        subMode = priorToShiftMode;
                        if (subModeCh < PAL)
                        {
                            ch = PunctChars[subModeCh];
                        }
                        else
                        {
                            if (subModeCh == PAL)
                            {
                                subMode = Alpha;
                            }
                        }
                        break;
                }
                if (ch != 0)
                {
                    // Append decoded character to result
                    result.Append(ch);
                }
                i++;
            }
        }

        /// <summary>
        /// Byte Compaction mode (see 5.4.3) permits all 256 possible 8-bit byte values to be encoded.
        /// This includes all ASCII characters value 0 to 127 inclusive and provides for international
        /// character set support.
        /// </summary>
        ///
        /// <param name="mode">The byte compaction mode i.e. 901 or 924</param>
        /// <param name="codewords">The array of codewords (data + error)</param>
        /// <param name="codeIndex">The current index into the codeword array.</param>
        /// <param name="result">The decoded data is appended to the result.</param>
        /// <returns>The next index into the codeword array.</returns>
        private static int ByteCompaction(int mode, int[] codewords, int codeIndex,
                StringBuilder result)
        {
            if (mode == ByteCompactionModeLatch)
            {
                // Total number of Byte Compaction characters to be encoded
                // is not a multiple of 6
                int count = 0;
                long value = 0;
                char[] decodedData = new char[6];
                int[] byteCompactedCodewords = new int[6];
                bool end = false;
                while ((codeIndex < codewords[0]) && !end)
                {
                    int code = codewords[codeIndex++];
                    if (code < TextCompactionModeLatch)
                    {
                        byteCompactedCodewords[count] = code;
                        count++;
                        // Base 900
                        value = 900 * value + code;
                    }
                    else
                    {
                        if (code == TextCompactionModeLatch
                                || code == ByteCompactionModeLatch
                                || code == NumericCompactionModeLatch
                                || code == ByteCompactionModeLatch6
                                || code == BeginMacroPdf417ControlBlock
                                || code == BeginMacroPdf417OptionalField
                                || code == MacroPdf417Terminator)
                        {
                            codeIndex--;
                            end = true;
                        }
                    }
                    if ((count % 5 == 0) && (count > 0))
                    {
                        // Decode every 5 codewords
                        // Convert to Base 256
                        for (int j = 0; j < 6; ++j)
                        {
                            decodedData[5 - j] = (char)(value % 256);
                            value >>= 8;
                        }
                        result.Append(decodedData);
                        count = 0;
                    }
                }
                // If Byte Compaction mode is invoked with codeword 901,
                // the final group of codewords is interpreted directly
                // as one byte per codeword, without compaction.
                for (int i = (count / 5) * 5; i < count; i++)
                {
                    result.Append((char)byteCompactedCodewords[i]);
                }

            }
            else if (mode == ByteCompactionModeLatch6)
            {
                // Total number of Byte Compaction characters to be encoded
                // is an integer multiple of 6
                int count_0 = 0;
                long val = 0;
                bool end_2 = false;
                while (codeIndex < codewords[0] && !end_2)
                {
                    int code_3 = codewords[codeIndex++];
                    if (code_3 < TextCompactionModeLatch)
                    {
                        count_0++;
                        // Base 900
                        val = 900 * val + code_3;
                    }
                    else
                    {
                        if (code_3 == TextCompactionModeLatch
                                || code_3 == ByteCompactionModeLatch
                                || code_3 == NumericCompactionModeLatch
                                || code_3 == ByteCompactionModeLatch6
                                || code_3 == BeginMacroPdf417ControlBlock
                                || code_3 == BeginMacroPdf417OptionalField
                                || code_3 == MacroPdf417Terminator)
                        {
                            codeIndex--;
                            end_2 = true;
                        }
                    }
                    if ((count_0 % 5 == 0) && (count_0 > 0))
                    {
                        // Decode every 5 codewords
                        // Convert to Base 256
                        char[] decodedData_4 = new char[6];
                        for (int j = 0; j < 6; ++j)
                        {
                            decodedData_4[5 - j] = (char)(val & 0xFF);
                            val >>= 8;
                        }
                        result.Append(decodedData_4);
                    }
                }
            }
            return codeIndex;
        }

        /// <summary>
        /// Numeric Compaction mode (see 5.4.4) permits efficient encoding of numeric data strings.
        /// </summary>
        ///
        /// <param name="codewords">The array of codewords (data + error)</param>
        /// <param name="codeIndex">The current index into the codeword array.</param>
        /// <param name="result">The decoded data is appended to the result.</param>
        /// <returns>The next index into the codeword array.</returns>
        private static int NumericCompaction(int[] codewords, int codeIndex,
                StringBuilder result)
        {
            int count = 0;
            bool end = false;

            int[] numericCodewords = new int[MaxNumericCodeWords];

            while (codeIndex < codewords[0] && !end)
            {
                int code = codewords[codeIndex++];
                if (codeIndex == codewords[0])
                {
                    end = true;
                }
                if (code < TextCompactionModeLatch)
                {
                    numericCodewords[count] = code;
                    count++;
                }
                else
                {
                    if (code == TextCompactionModeLatch
                            || code == ByteCompactionModeLatch
                            || code == ByteCompactionModeLatch6
                            || code == BeginMacroPdf417ControlBlock
                            || code == BeginMacroPdf417OptionalField
                            || code == MacroPdf417Terminator)
                    {
                        codeIndex--;
                        end = true;
                    }
                }
                if (count % MaxNumericCodeWords == 0
                        || code == NumericCompactionModeLatch || end)
                {
                    // Re-invoking Numeric Compaction mode (by using codeword 902
                    // while in Numeric Compaction mode) serves  to terminate the
                    // current Numeric Compaction mode grouping as described in 5.4.4.2,
                    // and then to start a new one grouping.
                    String s = DecodeBase900toBase10(numericCodewords, count);
                    result.Append(s);
                    count = 0;
                }
            }
            return codeIndex;
        }

        /// <summary>
        /// Convert a list of Numeric Compacted codewords from Base 900 to Base 10.
        /// </summary>
        ///
        /// <param name="codewords">The array of codewords</param>
        /// <param name="count">The number of codewords</param>
        /// <returns>The decoded string representing the Numeric data.</returns>
        /*
           EXAMPLE
           Encode the fifteen digit numeric string 000213298174000
           Prefix the numeric string with a 1 and set the initial value of
           t = 1 000 213 298 174 000
           Calculate codeword 0
           d0 = 1 000 213 298 174 000 mod 900 = 200
	
           t = 1 000 213 298 174 000 div 900 = 1 111 348 109 082
           Calculate codeword 1
           d1 = 1 111 348 109 082 mod 900 = 282
	
           t = 1 111 348 109 082 div 900 = 1 234 831 232
           Calculate codeword 2
           d2 = 1 234 831 232 mod 900 = 632
	
           t = 1 234 831 232 div 900 = 1 372 034
           Calculate codeword 3
           d3 = 1 372 034 mod 900 = 434
	
           t = 1 372 034 div 900 = 1 524
           Calculate codeword 4
           d4 = 1 524 mod 900 = 624
	
           t = 1 524 div 900 = 1
           Calculate codeword 5
           d5 = 1 mod 900 = 1
           t = 1 div 900 = 0
           Codeword sequence is: 1, 624, 434, 632, 282, 200
	
           Decode the above codewords involves
             1 x 900 power of 5 + 624 x 900 power of 4 + 434 x 900 power of 3 +
           632 x 900 power of 2 + 282 x 900 power of 1 + 200 x 900 power of 0 = 1000213298174000
	
           Remove leading 1 =>  Result is 000213298174000
	
           As there are huge numbers involved here we must use fake out the maths using string
           tokens for the numbers.
           BigDecimal is not supported by J2ME.
         */
        private static String DecodeBase900toBase10(int[] codewords, int count)
        {
            StringBuilder accum = null;
            for (int i = 0; i < count; i++)
            {
                StringBuilder value_ren = Multiply(EXP900[count - i - 1], codewords[i]);
                if (accum == null)
                {
                    // First time in accum=0
                    accum = value_ren;
                }
                else
                {
                    accum = Add(accum.ToString(), value_ren.ToString());
                }
            }
            String result = null;
            // Remove leading '1' which was inserted to preserve
            // leading zeros
            for (int i_0 = 0; i_0 < accum.Length; i_0++)
            {
                if (accum[i_0] == '1')
                {
                    //result = accum.substring(i + 1);
                    result = accum.ToString().Substring(i_0 + 1);
                    break;
                }
            }
            if (result == null)
            {
                // No leading 1 => just write the converted number.
                result = accum.ToString();
            }
            return result;
        }

        /// <summary>
        /// Multiplies two String numbers
        /// </summary>
        ///
        /// <param name="value1">Any number represented as a string.</param>
        /// <param name="value2">A number <= 999.</param>
        /// <returns>the result of value1 /// value2.</returns>
        private static StringBuilder Multiply(String value1, int value2)
        {
            StringBuilder result = new StringBuilder(value1.Length);
            for (int i = 0; i < value1.Length; i++)
            {
                // Put zeros into the result.
                result.Append('0');
            }
            int hundreds = value2 / 100;
            int tens = (value2 / 10) % 10;
            int ones = value2 % 10;
            // Multiply by ones
            for (int j = 0; j < ones; j++)
            {
                result = Add(result.ToString(), value1);
            }
            // Multiply by tens
            for (int j_0 = 0; j_0 < tens; j_0++)
            {
                result = Add(result.ToString(), (value1 + '0').Substring(1));
            }
            // Multiply by hundreds
            for (int j_1 = 0; j_1 < hundreds; j_1++)
            {
                result = Add(result.ToString(), (value1 + "00").Substring(2));
            }
            return result;
        }

        /// <summary>
        /// Add two numbers which are represented as strings.
        /// </summary>
        ///
        /// <param name="value1"></param>
        /// <param name="value2"></param>
        /// <returns>the result of value1 + value2</returns>
        private static StringBuilder Add(String value1, String value2)
        {
            StringBuilder temp1 = new StringBuilder(5);
            StringBuilder temp2 = new StringBuilder(5);
            StringBuilder result = new StringBuilder(value1.Length);
            for (int i = 0; i < value1.Length; i++)
            {
                // Put zeros into the result.
                result.Append('0');
            }
            int carry = 0;
            for (int i_0 = value1.Length - 3; i_0 > -1; i_0 -= 3)
            {

                temp1.Length = 0;
                temp1.Append(value1[i_0]);
                temp1.Append(value1[i_0 + 1]);
                temp1.Append(value1[i_0 + 2]);

                temp2.Length = 0;
                temp2.Append(value2[i_0]);
                temp2.Append(value2[i_0 + 1]);
                temp2.Append(value2[i_0 + 2]);

                int intValue1 = Int32.Parse(temp1.ToString());
                int intValue2 = Int32.Parse(temp2.ToString());

                int sumval = (intValue1 + intValue2 + carry) % 1000;
                carry = (intValue1 + intValue2 + carry) / 1000;

                result[i_0 + 2] = (char)((sumval % 10) + '0');
                result[i_0 + 1] = (char)(((sumval / 10) % 10) + '0');
                result[i_0] = (char)((sumval / 100) + '0');
            }
            return result;
        }


    }
}
