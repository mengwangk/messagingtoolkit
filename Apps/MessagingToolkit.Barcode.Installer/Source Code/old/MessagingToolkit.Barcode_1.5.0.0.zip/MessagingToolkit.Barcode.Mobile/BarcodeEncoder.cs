using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Media;
using System.Windows.Media.Imaging;

using MessagingToolkit.Barcode.OneD;
using MessagingToolkit.Barcode.Common;
using MessagingToolkit.Barcode.QRCode;
using MessagingToolkit.Barcode.QRCode.Decoder;
using MessagingToolkit.Barcode.DataMatrix;
using MessagingToolkit.Barcode.DataMatrix.Encoder;
using MessagingToolkit.Barcode.Helper;
using MessagingToolkit.Barcode.Pdf417;

namespace MessagingToolkit.Barcode
{
    /// <summary> 
    /// This is a factory class which finds the appropriate encoder subclass for the BarcodeFormat
    /// requested and encodes the barcode with the supplied contents.
    /// </summary>
    public sealed class BarcodeEncoder : IDisposable, IBarcodeEncoder
    {
        #region Variables

        private IEncoder iOneDEncoder = new DefaultEncoder();
        private IEncoder iQRCodeEncoder = new DefaultEncoder();
        private IEncoder iDataMatrixEncoder = new DefaultEncoder();
        private IEncoder iPdf417Encoder = new DefaultEncoder();

        private string content = string.Empty;
        private string encodedValue = "";
        private BarcodeFormat barcodeFormat = BarcodeFormat.Unknown;
        private WriteableBitmap encodedImage = null;
        private Color foreColor = Color.FromArgb(0, 0, 0, 0);
        private Color backColor = Color.FromArgb(255, 255, 255, 255);
        private int width = 300;
        private int height = 150;
        private bool includeLabel = false;
        private double encodingTime = 0;
        private DataMatrixScheme dataMatrixScheme = DataMatrixScheme.SchemeBase256;
        private DataMatrixSymbolSize dataMatrixSymbolSize = DataMatrixSymbolSize.SymbolSquareAuto;
        private ErrorCorrectionLevel errorCorrectionLevel = ErrorCorrectionLevel.L;
        private string characterSet = MessagingToolkit.Barcode.QRCode.Encoder.Encoder.DefaultByteModeEncoding;
        private int quietZone = 0;
        private int moduleSize = 5;
        private int marginSize = 10;

        #endregion


        #region Constructors

        /// <summary>
        /// Default constructor.  Does not populate the raw data.  MUST be done via the Content property before encoding.
        /// </summary>
        public BarcodeEncoder()
        {

        }

        /// <summary>
        /// Constructor. Populates the raw data. No whitespace will be added before or after the barcode.
        /// </summary>
        /// <param name="data">String to be encoded.</param>
        public BarcodeEncoder(string data)
        {
            this.content = data;
        }

        public BarcodeEncoder(string data, BarcodeFormat barcodeFormat)
        {
            this.content = data;
            this.barcodeFormat = barcodeFormat;
        }
        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the raw data to encode.
        /// </summary>
        public string Content
        {
            get
            {
                return content;
            }
            set
            {
                content = value;
            }
        }

        /// <summary>
        /// Gets the encoded value.
        /// </summary>
        private string EncodedValue
        {
            get
            {
                return encodedValue;
            }
        }

        /// <summary>
        /// Gets or sets the Encoded Type (ex. UPC-A, EAN-13 ... etc)
        /// </summary>
        public BarcodeFormat EncodedBarcodeFormat
        {
            set
            {
                barcodeFormat = value;
            }
            get
            {
                return barcodeFormat;
            }
        }

        /// <summary>
        /// Gets the Image of the generated barcode.
        /// </summary>
        public WriteableBitmap EncodedImage
        {
            get
            {
                return encodedImage;
            }
        }

        /// <summary>
        /// Gets or sets the color of the bars. (Default is black)
        /// </summary>
        public Color ForeColor
        {
            get
            {
                return this.foreColor;
            }
            set
            {
                this.foreColor = value;
            }
        }

        /// <summary>
        /// Gets or sets the background color. (Default is white)
        /// </summary>
        public Color BackColor
        {
            get
            {
                return this.backColor;
            }
            set
            {
                this.backColor = value;
            }
        }


        /// <summary>
        /// Gets or sets the width of the image to be drawn. (Default is 300 pixels)
        /// </summary>
        public int Width
        {
            get
            {
                return width;
            }
            set
            {
                width = value;
            }
        }

        /// <summary>
        /// Gets or sets the height of the image to be drawn. (Default is 150 pixels)
        /// </summary>
        public int Height
        {
            get
            {
                return height;
            }
            set
            {
                height = value;
            }
        }

        /// <summary>
        /// Gets or sets whether a label should be drawn below the image.
        /// </summary>
        public bool IncludeLabel
        {
            set
            {
                this.includeLabel = value;
            }
            get
            {
                return this.includeLabel;
            }
        }

        /// <summary>
        /// Gets or sets the amount of time in milliseconds that it took to encode and draw the barcode.
        /// </summary>
        public double EncodingTime
        {
            get
            {
                return encodingTime;
            }
            set
            {
                encodingTime = value;
            }
        }


        /// <summary>
        /// Gets or sets the error correction level.
        /// </summary>
        /// <value>
        /// The error correction level.
        /// </value>
        public ErrorCorrectionLevel ErrorCorrectionLevel
        {
            get
            {
                return this.errorCorrectionLevel;
            }
            set
            {
                this.errorCorrectionLevel = value;
            }
        }


        /// <summary>
        /// Gets or sets the margin.
        /// </summary>
        /// <value>
        /// The margin.
        /// </value>
        public int QuietZone
        {
            get
            {
                return this.quietZone;
            }
            set
            {
                this.quietZone = value;
            }
        }

        /// <summary>
        /// Gets or sets the character set.
        /// </summary>
        /// <value>
        /// The character set.
        /// </value>
        public string CharacterSet
        {
            get
            {
                return this.characterSet;
            }
            set
            {
                this.characterSet = value;
            }
        }

        /// <summary>
        /// Gets or sets the module size of a Data Matrix barcode
        /// </summary>
        /// <value>
        /// The module size
        /// </value>
        public int ModuleSize
        {
            get
            {
                return this.moduleSize;
            }
            set
            {
                this.moduleSize = value;
            }
        }

        /// <summary>
        /// Gets or sets the margin size of a Data Matrix barcode
        /// </summary>
        /// <value>
        /// The margin size
        /// </value>
        public int MarginSize
        {
            get
            {
                return this.marginSize;
            }
            set
            {
                this.marginSize = value;
            }
        }

        /// <summary>
        /// Gets or sets the data matrix scheme.
        /// </summary>
        /// <value>
        /// The data matrix scheme.
        /// </value>
        public DataMatrixScheme DataMatrixScheme
        {
            get
            {
                return this.dataMatrixScheme;
            }
            set
            {
                this.dataMatrixScheme = value;
            }
        }

        /// <summary>
        /// Gets or sets the size of the data matrix symbol.
        /// </summary>
        /// <value>
        /// The size of the data matrix symbol.
        /// </value>
        public DataMatrixSymbolSize DataMatrixSymbolSize
        {
            get
            {
                return this.dataMatrixSymbolSize;
            }
            set
            {
                this.dataMatrixSymbolSize = value;
            }
        }

        /// <summary>
        /// Gets the assembly version information.
        /// </summary>
        public static System.Version Version
        {
            get
            {
                return System.Reflection.Assembly.GetExecutingAssembly().GetName().Version;
            }
        }

        #endregion



        #region General Encode



        /// <summary>
        /// Encodes the raw data into binary form representing bars and spaces.  Also generates an Image of the barcode.
        /// </summary>
        /// <param name="format">Type of encoding to use.</param>
        /// <param name="content">Raw data to encode.</param>
        /// <returns>Image representing the barcode.</returns>
        public WriteableBitmap Encode(BarcodeFormat format, string content)
        {
            this.content = content;
            return Encode(format);
        }

        /// <summary>
        /// Encodes the raw data into binary form representing bars and spaces.  Also generates an Image of the barcode.
        /// </summary>
        /// <param name="barcodeFormat">Type of encoding to use.</param>
        internal WriteableBitmap Encode(BarcodeFormat barcodeFormat)
        {
            this.barcodeFormat = barcodeFormat;
            return Encode();
        }

        /// <summary>
        /// Encodes the raw data into binary form representing bars and spaces.
        /// </summary>
        internal WriteableBitmap Encode()
        {
            iOneDEncoder = new DefaultEncoder();
            iQRCodeEncoder = new DefaultEncoder();
            iDataMatrixEncoder = new DefaultEncoder();

            DateTime dtStartTime = DateTime.Now;

            // make sure there is something to encode
            if (content.Trim() == string.Empty)
                throw new Exception("Input data not allowed to be blank.");

            if (this.EncodedBarcodeFormat == BarcodeFormat.Unknown)
                throw new Exception("Symbology type not allowed to be unspecified.");

            this.encodedValue = string.Empty;

            switch (this.barcodeFormat)
            {
                case BarcodeFormat.QRCode:
                    iQRCodeEncoder = new QRCodeEncoder();
                    break;
                case BarcodeFormat.DataMatrix:
                    iDataMatrixEncoder = new DataMatrixEncoder();
                    break;
                case BarcodeFormat.PDF417:
                    iPdf417Encoder = new Pdf417Encoder();
                    break;
                case BarcodeFormat.UCC12:
                case BarcodeFormat.UPCA:
                    iOneDEncoder = new UPCAEncoder();
                    break;
                case BarcodeFormat.UCC13:
                case BarcodeFormat.EAN13:
                    iOneDEncoder = new EAN13Encoder();
                    break;
                case BarcodeFormat.Interleaved2of5:
                    //iOneDEncoder = new Interleaved2of5(content);
                    break;
                case BarcodeFormat.Industrial2of5:
                case BarcodeFormat.Standard2of5:
                    //iOneDEncoder = new Standard2of5(content);
                    break;
                case BarcodeFormat.LOGMARS:
                case BarcodeFormat.Code39:
                    iOneDEncoder = new Code39Encoder();
                    break;
                case BarcodeFormat.Code39Extended:
                    iOneDEncoder = new Code39Encoder();
                    break;
                case BarcodeFormat.Codabar:
                    //iOneDEncoder = new Codabar(content);
                    break;
                case BarcodeFormat.PostNet:
                    //iOneDEncoder = new Postnet(content);
                    break;
                case BarcodeFormat.ISBN:
                case BarcodeFormat.Bookland:
                    //iOneDEncoder = new ISBN(content);
                    break;
                case BarcodeFormat.JAN13:
                    //iOneDEncoder = new JAN13(content);
                    break;
                case BarcodeFormat.UPCSupplemental2Digit:
                    //iOneDEncoder = new UPCSupplement2(content);
                    break;
                case BarcodeFormat.MSIMod10:
                case BarcodeFormat.MSI2Mod10:
                case BarcodeFormat.MSIMod11:
                case BarcodeFormat.MSIMod11Mod10:
                case BarcodeFormat.ModifiedPlessey:
                    //iOneDEncoder = new MSI(content, barcodeFormat);
                    break;
                case BarcodeFormat.UPCSupplemental5Digit:
                    //iOneDEncoder = new UPCSupplement5(content);
                    break;
                case BarcodeFormat.UPCE:
                    //iOneDEncoder = new UPCE(content);
                    break;
                case BarcodeFormat.EAN8:
                    iOneDEncoder = new EAN8Encoder();
                    break;
                case BarcodeFormat.USD8:
                case BarcodeFormat.Code11:
                    //iOneDEncoder = new Code11(content);
                    break;
                case BarcodeFormat.Code128:
                    iOneDEncoder = new Code128Encoder();
                    break;
                case BarcodeFormat.Code128A:
                    iOneDEncoder = new Code128Encoder();
                    break;
                case BarcodeFormat.Code128B:
                    iOneDEncoder = new Code128Encoder();
                    break;
                case BarcodeFormat.Code128C:
                    iOneDEncoder = new Code128Encoder();
                    break;
                case BarcodeFormat.ITF14:
                    iOneDEncoder = new ITFEncoder();
                    break;
                case BarcodeFormat.Code93:
                    //iOneDEncoder = new Code93(content);
                    break;
                case BarcodeFormat.Telepen:
                    //iOneDEncoder = new Telepen(content);
                    break;
                case BarcodeFormat.FIM:
                    //iOneDEncoder = new FIM(content);
                    break;
                default: throw new Exception("Unsupported encoding type specified.");
            }


            if (iOneDEncoder.GetType() != typeof(DefaultEncoder))
            {
                BitMatrix bitMatrix = iOneDEncoder.Encode(this.content, this.barcodeFormat, this.Width, this.Height);
                encodedImage = MatrixToImageHelper.ToBitmap(bitMatrix, this.ForeColor, this.BackColor);
                this.encodedValue = bitMatrix.ToString();
            }
            else if (iQRCodeEncoder.GetType() != typeof(DefaultEncoder))
            {
                Dictionary<EncodeOptions, object> encodeOptions = new Dictionary<EncodeOptions, object>(2);
                encodeOptions.Add(EncodeOptions.CharacterSet, this.CharacterSet);
                encodeOptions.Add(EncodeOptions.ErrorCorrection, this.ErrorCorrectionLevel);

                if (this.QuietZone > 0)
                {
                    encodeOptions.Add(EncodeOptions.QuietZone, this.QuietZone);
                }

                BitMatrix bitMatrix = iQRCodeEncoder.Encode(this.content, this.barcodeFormat, this.Width, this.Height, encodeOptions);
                encodedImage = MatrixToImageHelper.ToBitmap(bitMatrix, this.ForeColor, this.BackColor);
                this.encodedValue = bitMatrix.ToString();
            }
            else if (iDataMatrixEncoder.GetType() != typeof(DefaultEncoder))
            {
                DataMatrixEncoder dataMatrixEncoder = iDataMatrixEncoder as DataMatrixEncoder;
                DataMatrixImageEncoderOptions options = new DataMatrixImageEncoderOptions();
                options.BackColor = this.BackColor;
                options.ForeColor = this.ForeColor;
                options.MarginSize = this.MarginSize;
                options.ModuleSize = this.ModuleSize;
                options.Scheme = this.DataMatrixScheme;
                options.SizeIdx = this.DataMatrixSymbolSize;
                options.CharacterSet = this.CharacterSet;
                this.encodedImage = dataMatrixEncoder.EncodeImage(this.content, options);
            }
            else if (iPdf417Encoder.GetType() != typeof(DefaultEncoder))
            {
                Pdf417Encoder pdf417Encoder = iPdf417Encoder as Pdf417Encoder;
                BitMatrix bitMatrix = pdf417Encoder.Encode(this.content, this.barcodeFormat, this.Width, this.Height);
                encodedImage = MatrixToImageHelper.ToBitmap(bitMatrix, this.ForeColor, this.BackColor);
                this.encodedValue = bitMatrix.ToString();
            }
            this.encodingTime = ((TimeSpan)(DateTime.Now - dtStartTime)).TotalMilliseconds;
            return EncodedImage;
        }



        #endregion



        #region Misc

        internal static bool CheckNumericOnly(string data)
        {
            //This function takes a string of data and breaks it into parts and trys to do Int64.TryParse
            //This will verify that only numeric data is contained in the string passed in.  The complexity below
            //was done to ensure that the minimum number of interations and checks could be performed.

            //9223372036854775808 is the largest number a 64bit number(signed) can hold so ... make sure its less than that by one place
            int StringLengths = 18;

            string temp = data;
            string[] strings = new string[(data.Length / StringLengths) + ((data.Length % StringLengths == 0) ? 0 : 1)];

            int i = 0;
            while (i < strings.Length)
                if (temp.Length >= StringLengths)
                {
                    strings[i++] = temp.Substring(0, StringLengths);
                    temp = temp.Substring(StringLengths);
                }//if
                else
                    strings[i++] = temp.Substring(0);

            foreach (string s in strings)
            {
                long value = 0;
                if (!Int64.TryParse(s, out value))
                    return false;
            }

            return true;
        }


        #endregion

        #region Static Methods
        /// <summary>
        /// Encodes the raw data into binary form representing bars and spaces.  Also generates an Image of the barcode.
        /// </summary>
        /// <param name="format">Type of encoding to use.</param>
        /// <param name="data">Raw data to encode.</param>
        /// <returns>Image representing the barcode.</returns>
        public static WriteableBitmap DoEncode(BarcodeFormat format, string data)
        {
            using (BarcodeEncoder b = new BarcodeEncoder())
            {
                return b.Encode(format, data);
            }
        }
        /// <summary>
        /// Encodes the raw data into binary form representing bars and spaces.  Also generates an Image of the barcode.
        /// </summary>
        /// <param name="format">Type of encoding to use.</param>
        /// <param name="data">Raw data to encode.</param>
        /// <param name="xml">XML representation of the data and the image of the barcode.</param>
        /// <returns>Image representing the barcode.</returns>
        public static WriteableBitmap DoEncode(BarcodeFormat format, string data, ref string xml)
        {
            using (BarcodeEncoder b = new BarcodeEncoder())
            {
                WriteableBitmap i = b.Encode(format, data);
                //XML = b.XML;
                return i;
            }
        }
        /// <summary>
        /// Encodes the raw data into binary form representing bars and spaces.  Also generates an Image of the barcode.
        /// </summary>
        /// <param name="format">Type of encoding to use.</param>
        /// <param name="data">Raw data to encode.</param>
        /// <param name="includeLabel">Include the label at the bottom of the image with data encoded.</param>
        /// <returns>Image representing the barcode.</returns>
        public static WriteableBitmap DoEncode(BarcodeFormat format, string data, bool includeLabel)
        {
            using (BarcodeEncoder b = new BarcodeEncoder())
            {
                b.IncludeLabel = includeLabel;
                return b.Encode(format, data);
            }
        }
        /// <summary>
        /// Encodes the raw data into binary form representing bars and spaces.  Also generates an Image of the barcode.
        /// </summary>
        /// <param name="format">Type of encoding to use.</param>
        /// <param name="data">Raw data to encode.</param>
        /// <param name="includeLabel">Include the label at the bottom of the image with data encoded.</param>
        /// <param name="width">Width of the resulting barcode.(pixels)</param>
        /// <param name="height">Height of the resulting barcode.(pixels)</param>
        /// <returns>Image representing the barcode.</returns>
        public static WriteableBitmap DoEncode(BarcodeFormat format, string data, bool includeLabel, int width, int height)
        {
            using (BarcodeEncoder b = new BarcodeEncoder())
            {
                b.IncludeLabel = includeLabel;
                b.Width = width;
                b.Height = height;
                return b.Encode(format, data);
            }
        }
        /// <summary>
        /// Encodes the raw data into binary form representing bars and spaces.  Also generates an Image of the barcode.
        /// </summary>
        /// <param name="format">Type of encoding to use.</param>
        /// <param name="data">Raw data to encode.</param>
        /// <param name="includeLabel">Include the label at the bottom of the image with data encoded.</param>
        /// <param name="DrawColor">Foreground color</param>
        /// <param name="BackColor">Background color</param>
        /// <returns>Image representing the barcode.</returns>
        public static WriteableBitmap DoEncode(BarcodeFormat format, string data, bool includeLabel, Color foreColor, Color backColor)
        {
            using (BarcodeEncoder b = new BarcodeEncoder())
            {
                b.IncludeLabel = includeLabel;
                b.ForeColor = foreColor;
                b.BackColor = backColor;
                return b.Encode(format, data);
            }
        }
        /// <summary>
        /// Encodes the raw data into binary form representing bars and spaces.  Also generates an Image of the barcode.
        /// </summary>
        /// <param name="format">Type of encoding to use.</param>
        /// <param name="data">Raw data to encode.</param>
        /// <param name="includeLabel">Include the label at the bottom of the image with data encoded.</param>
        /// <param name="drawColor">Foreground color</param>
        /// <param name="backColor">Background color</param>
        /// <param name="width">Width of the resulting barcode.(pixels)</param>
        /// <param name="height">Height of the resulting barcode.(pixels)</param>
        /// <returns>Image representing the barcode.</returns>
        public static WriteableBitmap DoEncode(BarcodeFormat format, string data, bool includeLabel, Color foreColor, Color backColor, int width, int height)
        {
            using (BarcodeEncoder b = new BarcodeEncoder())
            {
                b.IncludeLabel = includeLabel;
                b.Width = width;
                b.Height = height;
                b.ForeColor = foreColor;
                b.BackColor = backColor;
                return b.Encode(format, data);
            }
        }
        /// <summary>
        /// Encodes the raw data into binary form representing bars and spaces.  Also generates an Image of the barcode.
        /// </summary>
        /// <param name="format">Type of encoding to use.</param>
        /// <param name="data">Raw data to encode.</param>
        /// <param name="includeLabel">Include the label at the bottom of the image with data encoded.</param>
        /// <param name="foreColor">Color of the fore.</param>
        /// <param name="backColor">Color of the back.</param>
        /// <param name="width">The width.</param>
        /// <param name="height">The height.</param>
        /// <param name="xml">The XML.</param>
        /// <returns>
        /// Image representing the barcode.
        /// </returns>
        public static WriteableBitmap DoEncode(BarcodeFormat format, string data, bool includeLabel, Color foreColor, Color backColor, int width, int height, ref string xml)
        {
            using (BarcodeEncoder b = new BarcodeEncoder())
            {
                b.IncludeLabel = includeLabel;
                b.Width = width;
                b.Height = height;
                b.ForeColor = foreColor;
                b.BackColor = backColor;
                WriteableBitmap i = b.Encode(format, data);
                return i;
            }
        }

        #endregion

        #region IDisposable Members

        public void Dispose()
        {
            try
            {
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        #endregion
    }
}
