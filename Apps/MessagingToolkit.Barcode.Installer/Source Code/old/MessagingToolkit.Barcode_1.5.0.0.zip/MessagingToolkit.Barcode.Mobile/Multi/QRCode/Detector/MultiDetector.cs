//===============================================================================
// Copyright � TWIT88.COM.  All rights reserved.
//
// This file is part of Open Source Messaging Library.
//
// Open Source Messaging Library is free software: you can redistribute it 
// and/or modify it under the terms of the GNU General Public License version 3.
//
// Open Source Messaging Library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this software.  If not, see <http://www.gnu.org/licenses/>.
//===============================================================================

using System.Collections.Generic;
using DetectorResult = MessagingToolkit.Barcode.Common.DetectorResult;
using BitMatrix = MessagingToolkit.Barcode.Common.BitMatrix;
using FinderPatternInfo = MessagingToolkit.Barcode.QRCode.Detector.FinderPatternInfo;

namespace MessagingToolkit.Barcode.Multi.QRCode.Detector
{

    /// <summary>
    /// Encapsulates logic that can detect one or more QR Codes in an image, even if the QR Code
    /// is rotated or skewed, or partially obscured.
    /// </summary>
    public sealed class MultiDetector : MessagingToolkit.Barcode.QRCode.Detector.Detector
	{
        private static readonly DetectorResult[] EmptyDetectorResults = new DetectorResult[0];

        /// <summary>
        /// Initializes a new instance of the <see cref="MultiDetector"/> class.
        /// </summary>
        /// <param name="image">The image.</param>
		public MultiDetector(BitMatrix image):base(image)
		{
		}

        public DetectorResult[] DetectMulti(Dictionary<DecodeOptions, object> decodingOptions)
		{
			BitMatrix image = Image;
			MultiFinderPatternFinder finder = new MultiFinderPatternFinder(image);
			FinderPatternInfo[] info = finder.FindMulti(decodingOptions);
			
			if (info == null || info.Length == 0)
			{
                throw NotFoundException.Instance;
			}
			
			List<DetectorResult> result = new List<DetectorResult>(10);
			for (int i = 0; i < info.Length; i++)
			{
				try
				{
					result.Add(ProcessFinderPatternInfo(info[i]));
				}
				catch (BarcodeDecoderException e)
				{
					// ignore
				}
			}
			if ((result.Count == 0))
			{
				return EmptyDetectorResults;
			}
			else
			{
				DetectorResult[] resultArray = new DetectorResult[result.Count];
				for (int i = 0; i < result.Count; i++)
				{
					resultArray[i] = (DetectorResult) result[i];
				}
				return resultArray;
			}
		}
	}
}