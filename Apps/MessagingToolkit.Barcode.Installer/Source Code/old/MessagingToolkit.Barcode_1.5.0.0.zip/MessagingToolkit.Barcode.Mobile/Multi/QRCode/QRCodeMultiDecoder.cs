//===============================================================================
// Copyright � TWIT88.COM.  All rights reserved.
//
// This file is part of Open Source Messaging Library.
//
// Open Source Messaging Library is free software: you can redistribute it 
// and/or modify it under the terms of the GNU General Public License version 3.
//
// Open Source Messaging Library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this software.  If not, see <http://www.gnu.org/licenses/>.
//===============================================================================

using System.Collections;
using System.Collections.Generic;
using DecoderResult = MessagingToolkit.Barcode.Common.DecoderResult;
using DetectorResult = MessagingToolkit.Barcode.Common.DetectorResult;
using MultiDetector = MessagingToolkit.Barcode.Multi.QRCode.Detector.MultiDetector;
using MessagingToolkit.Barcode.Multi.QRCode.Detector;
using MessagingToolkit.Barcode.QRCode;

namespace MessagingToolkit.Barcode.Multi.QRCode
{

    /// <summary>
    /// This implementation can detect and decode multiple QR Codes in an image.
    /// </summary>
    public sealed class QRCodeMultiDecoder : QRCodeDecoder, MultipleBarcodeDecoder
    {
        private static readonly Result[] EmptyResultArray = new Result[0];

        public Result[] DecodeMultiple(BinaryBitmap image)
        {
            return DecodeMultiple(image, null);
        }

        public Result[] DecodeMultiple(BinaryBitmap image, Dictionary<DecodeOptions, object> decodingOptions)
        {
            List<Result> results = new List<Result>(10);
            DetectorResult[] detectorResult = new MultiDetector(image.BlackMatrix).DetectMulti(decodingOptions);
            for (int i = 0; i < detectorResult.Length; i++)
            {
                try
                {
                    DecoderResult decoderResult = GetDecoder().Decode(detectorResult[i].Bits);
                    ResultPoint[] points = detectorResult[i].Points;
                    Result result = new Result(decoderResult.Text, decoderResult.RawBytes, points, BarcodeFormat.QRCode);
                    if (decoderResult.ByteSegments != null)
                    {
                        result.PutMetadata(ResultMetadataType.ByteSegments, decoderResult.ByteSegments);
                    }
                    if (decoderResult.ECLevel != null)
                    {
                        result.PutMetadata(ResultMetadataType.ErrorCorrectionLevel, decoderResult.ECLevel.ToString());
                    }
                    results.Add(result);
                }
                catch (BarcodeDecoderException re)
                {
                    // ignore and continue 
                }
            }
            if ((results.Count == 0))
            {
                return EmptyResultArray;
            }
            else
            {
                Result[] resultArray = new Result[results.Count];
                for (int i = 0; i < results.Count; i++)
                {
                    resultArray[i] = (Result)results[i];
                }
                return resultArray;
            }
        }
    }
}