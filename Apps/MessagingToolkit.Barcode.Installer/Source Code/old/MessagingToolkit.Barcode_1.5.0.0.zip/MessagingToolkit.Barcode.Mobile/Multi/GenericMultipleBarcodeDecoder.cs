//===============================================================================
// Copyright � TWIT88.COM.  All rights reserved.
//
// This file is part of Open Source Messaging Library.
//
// Open Source Messaging Library is free software: you can redistribute it 
// and/or modify it under the terms of the GNU General Public License version 3.
//
// Open Source Messaging Library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this software.  If not, see <http://www.gnu.org/licenses/>.
//===============================================================================

using System;
using System.Collections.Generic;
using IBarcodeDecoder = MessagingToolkit.Barcode.IDecoder;
using Result = MessagingToolkit.Barcode.Result;
using BinaryBitmap = MessagingToolkit.Barcode.BinaryBitmap;
using BarcodeDecoderException = MessagingToolkit.Barcode.BarcodeDecoderException;
using ResultPoint = MessagingToolkit.Barcode.ResultPoint;

namespace MessagingToolkit.Barcode.Multi
{

    /// <summary>
    /// 	<p>Attempts to locate multiple barcodes in an image by repeatedly decoding portion of the image.
    /// After one barcode is found, the areas left, above, right and below the barcode's
    /// {@link MessagingToolkit.Barcode.ResultPoint}s are scanned, recursively.</p>
    /// 	<p>A caller may want to also employ {@link ByQuadrantReader} when attempting to find multiple
    /// 2D barcodes, like QR Codes, in an image, where the presence of multiple barcodes might prevent
    /// detecting any one of them.</p>
    /// 	<p>That is, instead of passing a {@link Reader} a caller might pass
    /// <code>new ByQuadrantReader(reader)</code>.</p>
    /// </summary>
    public sealed class GenericMultipleBarcodeDecoder : MultipleBarcodeDecoder
    {

        private const int MinDimensionToRecur = 100;

        private IDecoder delegateReader;

        public GenericMultipleBarcodeDecoder(IDecoder delegateReader)
        {
            this.delegateReader = delegateReader;
        }

        public Result[] DecodeMultiple(BinaryBitmap image)
        {
            return DecodeMultiple(image, null);
        }

        public Result[] DecodeMultiple(BinaryBitmap image, Dictionary<DecodeOptions, object> decodingOptions)
        {
            List<Result> results = new List<Result>(10);
            DoDecodeMultiple(image, decodingOptions, results, 0, 0);
            if ((results.Count == 0))
            {
                throw NotFoundException.Instance;
            }
            int numResults = results.Count;
            Result[] resultArray = new Result[numResults];
            for (int i = 0; i < numResults; i++)
            {
                resultArray[i] = (Result)results[i];
            }
            return resultArray;
        }

        /// <summary>
        /// Does the decode multiple.
        /// </summary>
        /// <param name="image">The image.</param>
        /// <param name="decodingOptions">The hints.</param>
        /// <param name="results">The results.</param>
        /// <param name="xOffset">The x offset.</param>
        /// <param name="yOffset">The y offset.</param>
        private void DoDecodeMultiple(BinaryBitmap image, Dictionary<DecodeOptions, object> decodingOptions, List<Result> results, int xOffset, int yOffset)
        {
            Result result;
            try
            {
                result = delegateReader.Decode(image, decodingOptions);
            }
            catch (BarcodeDecoderException re)
            {
                return;
            }
            bool alreadyFound = false;
            for (int i = 0; i < results.Count; i++)
            {
                Result existingResult = (Result)results[i];
                if (existingResult.Text.Equals(result.Text))
                {
                    alreadyFound = true;
                    break;
                }
            }
            if (alreadyFound)
            {
                return;
            }
            results.Add(TranslateResultPoints(result, xOffset, yOffset));
            ResultPoint[] resultPoints = result.ResultPoints;
            if (resultPoints == null || resultPoints.Length == 0)
            {
                return;
            }
            int width = image.Width;
            int height = image.Height;
            float minX = width;
            float minY = height;
            float maxX = 0.0f;
            float maxY = 0.0f;
            for (int i = 0; i < resultPoints.Length; i++)
            {
                ResultPoint point = resultPoints[i];
                float x = point.X;
                float y = point.Y;
                if (x < minX)
                {
                    minX = x;
                }
                if (y < minY)
                {
                    minY = y;
                }
                if (x > maxX)
                {
                    maxX = x;
                }
                if (y > maxY)
                {
                    maxY = y;
                }
            }

            // Decode left of barcode
            if (minX > MinDimensionToRecur)
            {
                DoDecodeMultiple(image.Crop(0, 0, (int)minX, height), decodingOptions, results, xOffset, yOffset);
            }
            // Decode above barcode
            if (minY > MinDimensionToRecur)
            {
                DoDecodeMultiple(image.Crop(0, 0, width, (int)minY), decodingOptions, results, xOffset, yOffset);
            }
            // Decode right of barcode
            if (maxX < width - MinDimensionToRecur)
            {
                DoDecodeMultiple(image.Crop((int)maxX, 0, width - (int)maxX, height), decodingOptions, results, xOffset + (int)maxX, yOffset);
            }
            // Decode below barcode
            if (maxY < height - MinDimensionToRecur)
            {
                DoDecodeMultiple(image.Crop(0, (int)maxY, width, height - (int)maxY), decodingOptions, results, xOffset, yOffset + (int)maxY);
            }
        }

        /// <summary>
        /// Translates the result points.
        /// </summary>
        /// <param name="result">The result.</param>
        /// <param name="xOffset">The x offset.</param>
        /// <param name="yOffset">The y offset.</param>
        /// <returns></returns>
        private static Result TranslateResultPoints(Result result, int xOffset, int yOffset)
        {
            ResultPoint[] oldResultPoints = result.ResultPoints;
            ResultPoint[] newResultPoints = new ResultPoint[oldResultPoints.Length];
            for (int i = 0; i < oldResultPoints.Length; i++)
            {
                ResultPoint oldPoint = oldResultPoints[i];
                newResultPoints[i] = new ResultPoint(oldPoint.X + xOffset, oldPoint.Y + yOffset);
            }
            return new Result(result.Text, result.RawBytes, newResultPoints, result.BarcodeFormat);
        }
    }
}