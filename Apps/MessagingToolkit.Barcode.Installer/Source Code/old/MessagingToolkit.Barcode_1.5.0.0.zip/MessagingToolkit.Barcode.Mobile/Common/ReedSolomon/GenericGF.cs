using System;
using System.Collections;
using System.ComponentModel;
using System.IO;
using System.Runtime.CompilerServices;

namespace MessagingToolkit.Barcode.Common.ReedSolomon
{
    /// <summary>
    ///   <p>This class contains utility methods for performing mathematical operations over
    /// the Galois Fields. Operations use a given primitive polynomial in calculations.</p>
    ///   <p>Throughout this package, elements of the GF are represented as an <c>int</c>
    /// for convenience and speed (but at the cost of memory).
    ///   </p>
    /// </summary>
    public sealed class GenericGF
    {
        public static readonly GenericGF AztecData12 = new GenericGF(0x1069, 4096); // x^12 + x^6 + x^5 + x^3 + 1
        public static readonly GenericGF AztecData10 = new GenericGF(0x409, 1024); // x^10 + x^3 + 1
        public static readonly GenericGF AztechData6 = new GenericGF(0x43, 64); // x^6 + x + 1
        public static readonly GenericGF AztecParam = new GenericGF(0x13, 16); // x^4 + x + 1
        public static readonly GenericGF QRCodeField256 = new GenericGF(0x011D, 256); // x^8 + x^4 + x^3 + x^2 + 1
        public static readonly GenericGF DataMatrixField256 = new GenericGF(0x012D,
                256); // x^8 + x^5 + x^3 + x^2 + 1
        public static readonly GenericGF AztecData8 = DataMatrixField256;
        public static readonly GenericGF MaxiCodeField64 = AztechData6;

        private const int InitializationThreshold = 0;

        private int[] expTable;
        private int[] logTable;
        private GenericGFPoly zero;
        private GenericGFPoly one;
        private readonly int size;
        private readonly int primitive;
        private bool initialized;

        /// <summary>
        /// Create a representation of GF(size) using the given primitive polynomial.
        /// </summary>
        ///
        /// <param name="primitive_0">coefficient</param>
        public GenericGF(int primitive_0, int size_1)
        {
            this.initialized = false;
            this.primitive = primitive_0;
            this.size = size_1;

            if (size_1 <= InitializationThreshold)
            {
                Initialize();
            }
        }

        private void Initialize()
        {
            expTable = new int[size];
            logTable = new int[size];
            int x = 1;
            for (int i = 0; i < size; i++)
            {
                expTable[i] = x;
                x <<= 1; // x = x * 2; we're assuming the generator alpha is 2
                if (x >= size)
                {
                    x ^= primitive;
                    x &= size - 1;
                }
            }
            for (int i_0 = 0; i_0 < size - 1; i_0++)
            {
                logTable[expTable[i_0]] = i_0;
            }
            // logTable[0] == 0 but this should never be used
            zero = new GenericGFPoly(this, new int[] { 0 });
            one = new GenericGFPoly(this, new int[] { 1 });
            initialized = true;
        }

        private void CheckInit()
        {
            if (!initialized)
            {
                Initialize();
            }
        }

        internal GenericGFPoly GetZero()
        {
            CheckInit();

            return zero;
        }

        internal GenericGFPoly GetOne()
        {
            CheckInit();

            return one;
        }


        /// <returns>the monomial representing coefficient /// x^degree</returns>
        internal GenericGFPoly BuildMonomial(int degree, int coefficient)
        {
            CheckInit();

            if (degree < 0)
            {
                throw new ArgumentException();
            }
            if (coefficient == 0)
            {
                return zero;
            }
            int[] coefficients = new int[degree + 1];
            coefficients[0] = coefficient;
            return new GenericGFPoly(this, coefficients);
        }

        /// <summary>
        /// Implements both addition and subtraction -- they are the same in GF(size).
        /// </summary>
        ///
        /// <returns>sum/difference of a and b</returns>
        static internal int AddOrSubtract(int a, int b)
        {
            return a ^ b;
        }


        /// <returns>2 to the power of a in GF(size)</returns>
        internal int Exp(int a)
        {
            CheckInit();

            return expTable[a];
        }


        /// <returns>base 2 log of a in GF(size)</returns>
        internal int Log(int a)
        {
            CheckInit();

            if (a == 0)
            {
                throw new ArgumentException();
            }
            return logTable[a];
        }


        /// <returns>multiplicative inverse of a</returns>
        internal int Inverse(int a)
        {
            CheckInit();

            if (a == 0)
            {
                throw new ArithmeticException();
            }
            return expTable[size - logTable[a] - 1];
        }


        /// <param name="a"></param>
        /// <param name="b"></param>
        /// <returns>product of a and b in GF(size)</returns>
        internal int Multiply(int a, int b)
        {
            CheckInit();

            if (a == 0 || b == 0)
            {
                return 0;
            }

            if (a < 0 || b < 0 || a >= size || b >= size)
            {
                a++;
            }

            int logSum = logTable[a] + logTable[b];
            return expTable[(logSum % size) + logSum / size];
        }

        public int GetSize()
        {
            return size;
        }

    }
}
