using System.Collections.Generic;
using DetectorResult = MessagingToolkit.Barcode.Common.DetectorResult;
using BitMatrix = MessagingToolkit.Barcode.Common.BitMatrix;
using FinderPatternInfo = MessagingToolkit.Barcode.QRCode.Detector.FinderPatternInfo;

namespace MessagingToolkit.Barcode.Multi.QRCode.Detector
{
    
    /// <summary>
    /// Encapsulates logic that can detect one or more QR Codes in an image, even if the QR Code
    /// is rotated or skewed, or partially obscured.
    /// </summary>
    public sealed class MultiDetector : MessagingToolkit.Barcode.QRCode.Detector.Detector
    {
        private static readonly DetectorResult[] EmptyDetectorResults = new DetectorResult[0];

        /// <summary>
        /// Initializes a new instance of the <see cref="MultiDetector"/> class.
        /// </summary>
        /// <param name="image">The image.</param>
        public MultiDetector(BitMatrix image)
            : base(image)
        {
        }

        public DetectorResult[] DetectMulti(Dictionary<DecodeOptions, object> decodingOptions)
        {
            BitMatrix image = Image;
            MultiFinderPatternFinder finder = new MultiFinderPatternFinder(image);
            FinderPatternInfo[] info = finder.FindMulti(decodingOptions);

            if (info == null || info.Length == 0)
            {
                throw NotFoundException.Instance;
            }

            List<DetectorResult> result = new List<DetectorResult>(10);
            for (int i = 0; i < info.Length; i++)
            {
                try
                {
                    result.Add(ProcessFinderPatternInfo(info[i]));
                }
                catch (BarcodeDecoderException e)
                {
                    // ignore
                }
            }
            if ((result.Count == 0))
            {
                return EmptyDetectorResults;
            }
            else
            {
                DetectorResult[] resultArray = new DetectorResult[result.Count];
                for (int i = 0; i < result.Count; i++)
                {
                    resultArray[i] = (DetectorResult)result[i];
                }
                return resultArray;
            }
        }
    }
}
