//===============================================================================
// OSML - Open Source Messaging Library
//
//===============================================================================
// Copyright � TWIT88.COM.  All rights reserved.
//
// This file is part of Open Source Messaging Library.
//
// Open Source Messaging Library is free software: you can redistribute it 
// and/or modify it under the terms of the GNU General Public License version 3.
//
// Open Source Messaging Library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this software.  If not, see <http://www.gnu.org/licenses/>.
//===============================================================================

using System;

namespace MessagingToolkit.Barcode.Client.Results
{
	
	/// <summary> 
    /// Represents the type of data encoded by a barcode -- from plain text, to a
	/// URI, to an e-mail address, etc.
	/// </summary>
	public sealed class ParsedResultType
	{
        public static readonly ParsedResultType AddessBook = new ParsedResultType("ADDRESSBOOK");
		public static readonly ParsedResultType EmailAddress = new ParsedResultType("EMAIL_ADDRESS");
	    public static readonly ParsedResultType Product = new ParsedResultType("PRODUCT");
		public static readonly ParsedResultType Uri = new ParsedResultType("URI");
		public static readonly ParsedResultType Text = new ParsedResultType("Text");
		public static readonly ParsedResultType AndroidIntent = new ParsedResultType("ANDROID_INTENT");
		public static readonly ParsedResultType Geo = new ParsedResultType("GEO");
		public static readonly ParsedResultType Tel = new ParsedResultType("TEL");
		public static readonly ParsedResultType Sms = new ParsedResultType("SMS");
		public static readonly ParsedResultType Calendar = new ParsedResultType("CALENDAR");
        public static readonly ParsedResultType Wifi = new ParsedResultType("Wifi");
		
        // "optional" types
		public static readonly ParsedResultType NDefSmartPoster = new ParsedResultType("NDEF_SMART_POSTER");
		public static readonly ParsedResultType MobileTagRichWeb = new ParsedResultType("MOBILETAG_RICH_WEB");
		public static readonly ParsedResultType Isbn = new ParsedResultType("ISBN");
		
        private string name;
		
		private ParsedResultType(string name)
		{
			this.name = name;
		}
		
		public override string ToString()
		{
			return name;
		}
	}
}