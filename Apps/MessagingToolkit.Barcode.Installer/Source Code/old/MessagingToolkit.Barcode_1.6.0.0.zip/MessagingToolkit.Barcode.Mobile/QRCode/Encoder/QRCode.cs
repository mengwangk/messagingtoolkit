using System;
using System.Text;
using ErrorCorrectionLevel = MessagingToolkit.Barcode.QRCode.Decoder.ErrorCorrectionLevel;
using Mode = MessagingToolkit.Barcode.QRCode.Decoder.Mode;

namespace MessagingToolkit.Barcode.QRCode.Encoder
{
    public sealed class QRCode
    {

        public const int NUM_MASK_PATTERNS = 8;

        private Mode mode;
        private ErrorCorrectionLevel ecLevel;
        private int version;
        private int matrixWidth;
        private int maskPattern;
        private int numTotalBytes;
        private int numDataBytes;
        private int numECBytes;
        private int numRSBlocks;
        private ByteMatrix matrix;

        public QRCode()
        {
            mode = null;
            ecLevel = null;
            version = -1;
            matrixWidth = -1;
            maskPattern = -1;
            numTotalBytes = -1;
            numDataBytes = -1;
            numECBytes = -1;
            numRSBlocks = -1;
            matrix = null;
        }

        public Mode Mode
        {
            // Mode of the QR Code.

            get
            {
                return mode;
            }

            set
            {
                mode = value;
            }
        }

        public ErrorCorrectionLevel ECLevel
        {
            // Error correction level of the QR Code.

            get
            {
                return ecLevel;
            }

            set
            {
                ecLevel = value;
            }

        }

        public int Version
        {
            // Version of the QR Code.  The bigger size, the bigger version.

            get
            {
                return version;
            }

            set
            {
                version = value;
            }

        }
        public int MatrixWidth
        {
            // ByteMatrix width of the QR Code.

            get
            {
                return matrixWidth;
            }

            set
            {
                matrixWidth = value;
            }

        }
        public int MaskPattern
        {
            // Mask pattern of the QR Code.

            get
            {
                return maskPattern;
            }

            set
            {
                maskPattern = value;
            }

        }

        public int NumTotalBytes
        {
            // Number of total bytes in the QR Code.

            get
            {
                return numTotalBytes;
            }

            set
            {
                numTotalBytes = value;
            }

        }
        public int NumDataBytes
        {
            // Number of data bytes in the QR Code.

            get
            {
                return numDataBytes;
            }

            set
            {
                numDataBytes = value;
            }

        }
        public int NumECBytes
        {
            // Number of error correction bytes in the QR Code.

            get
            {
                return numECBytes;
            }

            set
            {
                numECBytes = value;
            }

        }
        public int NumRSBlocks
        {
            // Number of Reedsolomon blocks in the QR Code.

            get
            {
                return numRSBlocks;
            }

            set
            {
                numRSBlocks = value;
            }

        }
        public ByteMatrix Matrix
        {
            // ByteMatrix data of the QR Code.

            get
            {
                return matrix;
            }

            // This takes ownership of the 2D array.

            set
            {
                matrix = value;
            }

        }

        // Return the value of the module (cell) pointed by "x" and "y" in the matrix of the QR Code. They
        // call cells in the matrix "modules". 1 represents a black cell, and 0 represents a white cell.
        public int At(int x, int y)
        {
            // The value must be zero or one.
            int // The value must be zero or one.
                    val = matrix.Get(x, y);
            if (!(val == 0 || val == 1))
            {
                throw new InvalidOperationException("Bad value");
            }
            return val;
        }

        // Checks all the member variables are set properly. Returns true on success. Otherwise, returns
        // false.
        public bool IsValid()
        {
            return
                // First check if all version are not uninitialized.
            mode != null && ecLevel != null && version != -1 && matrixWidth != -1 && maskPattern != -1 && numTotalBytes != -1 && numDataBytes != -1 && numECBytes != -1 && numRSBlocks != -1 &&
                // Then check them in other ways..
                    IsValidMaskPattern(maskPattern) && numTotalBytes == numDataBytes + numECBytes &&
                // ByteMatrix stuff.
                    matrix != null && matrixWidth == matrix.Width &&
                // See 7.3.1 of JISX0510:2004 (p.5).
                    matrix.Width == matrix.Height; // Must be square.
        }

        // Return debug String.
        public override String ToString()
        {
            StringBuilder result = new StringBuilder(200);
            result.Append("<<\n");
            result.Append(" mode: ");
            result.Append(mode);
            result.Append("\n ecLevel: ");
            result.Append(ecLevel);
            result.Append("\n version: ");
            result.Append(version);
            result.Append("\n matrixWidth: ");
            result.Append(matrixWidth);
            result.Append("\n maskPattern: ");
            result.Append(maskPattern);
            result.Append("\n numTotalBytes: ");
            result.Append(numTotalBytes);
            result.Append("\n numDataBytes: ");
            result.Append(numDataBytes);
            result.Append("\n numECBytes: ");
            result.Append(numECBytes);
            result.Append("\n numRSBlocks: ");
            result.Append(numRSBlocks);
            if (matrix == null)
            {
                result.Append("\n matrix: null\n");
            }
            else
            {
                result.Append("\n matrix:\n");
                result.Append(matrix.ToString());
            }
            result.Append(">>\n");
            return result.ToString();
        }

        // Check if "mask_pattern" is valid.
        public static bool IsValidMaskPattern(int maskPattern)
        {
            return maskPattern >= 0 && maskPattern < NUM_MASK_PATTERNS;
        }

    }
}
