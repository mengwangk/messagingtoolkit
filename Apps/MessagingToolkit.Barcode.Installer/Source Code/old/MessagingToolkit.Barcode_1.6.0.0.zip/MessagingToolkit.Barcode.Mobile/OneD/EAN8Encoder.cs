//===============================================================================
// Copyright � TWIT88.COM.  All rights reserved.
//
// This file is part of Open Source Messaging Library.
//
// Open Source Messaging Library is free software: you can redistribute it 
// and/or modify it under the terms of the GNU General Public License version 3.
//
// Open Source Messaging Library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this software.  If not, see <http://www.gnu.org/licenses/>.
//===============================================================================

using System;
using System.Collections.Generic;
using BarcodeFormat = MessagingToolkit.Barcode.BarcodeFormat;
using WriterException = MessagingToolkit.Barcode.BarcodeEncoderException;
using BitMatrix = MessagingToolkit.Barcode.Common.BitMatrix;

namespace MessagingToolkit.Barcode.OneD
{

    /// <summary>
    /// This object renders an EAN8 code as a BitMatrix 2D array of greyscale
    /// values.
    /// 
    /// Modified: April 30 2012
    /// </summary>
    public sealed class EAN8Encoder : UPCEANEncoder
    {
       private const int CODE_WIDTH = 3 + // start guard
				(7 * 4) + // left bars
				5 + // middle guard
				(7 * 4) + // right bars
				3; // end guard
	
		public override BitMatrix Encode(String contents, BarcodeFormat format, int width, int height, Dictionary<EncodeOptions, object> encodingOptions) {
			if (format != BarcodeFormat.EAN8) {
				throw new ArgumentException("Can only encode EAN_8, but got " + format);
			}
	
			return base.Encode(contents,format,width,height,encodingOptions);
		}
	
		
		/// <returns>a byte array of horizontal pixels (0 = white, 1 = black)</returns>
		public override byte[] Encode(String contents) {
			if (contents.Length != 8) {
				throw new ArgumentException("Requested contents should be 8 digits long, but got " + contents.Length);
			}
	
			byte[] result = new byte[CODE_WIDTH];
			int pos = 0;
	
			pos += OneDEncoder.AppendPattern(result, pos, UPCEANDecoder.StartEndPattern, 1);
	
			for (int i = 0; i <= 3; i++) {
				int digit = Int32.Parse(contents.Substring(i,(i + 1)-(i)));
                pos += OneDEncoder.AppendPattern(result, pos, UPCEANDecoder.LPatterns[digit], 0);
			}

            pos += OneDEncoder.AppendPattern(result, pos, UPCEANDecoder.MiddlePattern, 0);
	
			for (int i_0 = 4; i_0 <= 7; i_0++) {
				int digit_1 = Int32.Parse(contents.Substring(i_0,(i_0 + 1)-(i_0)));
                pos += OneDEncoder.AppendPattern(result, pos, UPCEANDecoder.LPatterns[digit_1], 1);
			}
            pos += OneDEncoder.AppendPattern(result, pos, UPCEANDecoder.StartEndPattern, 1);
	
			return result;
		}
	
    }
}