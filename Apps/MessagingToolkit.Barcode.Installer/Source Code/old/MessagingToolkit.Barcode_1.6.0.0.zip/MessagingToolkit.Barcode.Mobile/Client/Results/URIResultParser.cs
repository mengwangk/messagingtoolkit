using System;
using System.Text.RegularExpressions;

using Result = MessagingToolkit.Barcode.Result;

namespace MessagingToolkit.Barcode.Client.Results
{

    /// <summary>
    /// Tries to parse results that are a URI of some kind.
    /// 
    /// Modified: May 18 2012
    /// </summary>
    sealed class URIResultParser : ResultParser
    {

        private const String PATTERN_END = "(:\\d{1,5})?" + // maybe port
                "(/|\\?|$)"; // query, path or nothing


        private static readonly Regex URL_WITH_PROTOCOL_PATTERN = new Regex(
            "[a-zA-Z0-9]{2,}:(/)*" + // protocol
            "[a-zA-Z0-9\\-]+(\\.[a-zA-Z0-9\\-]+)*" + // host name elements
            PATTERN_END);

        private static readonly Regex URL_WITHOUT_PROTOCOL_PATTERN = new Regex(
            "([a-zA-Z0-9\\-]+\\.)+[a-zA-Z0-9\\-]{2,}" + // host name elements
            PATTERN_END);


        public override ParsedResult Parse(Result result)
        {
            String rawText = GetMassagedText(result);
            // We specifically handle the odd "URL" scheme here for simplicity
            if (rawText.StartsWith("URL:"))
            {
                rawText = rawText.Substring(4);
            }
            rawText = rawText.Trim();
            return (IsBasicallyValidURI(rawText)) ? new URIParsedResult(rawText, null) : null;
        }

        static internal bool IsBasicallyValidURI(String uri)
        {
            var m = URL_WITH_PROTOCOL_PATTERN.Match(uri);
            if (m.Success && m.Index == 0)
            { // match at start only
                return true;
            }
            m = URL_WITHOUT_PROTOCOL_PATTERN.Match(uri);
            return m.Success && m.Index == 0;
        }
    }
}