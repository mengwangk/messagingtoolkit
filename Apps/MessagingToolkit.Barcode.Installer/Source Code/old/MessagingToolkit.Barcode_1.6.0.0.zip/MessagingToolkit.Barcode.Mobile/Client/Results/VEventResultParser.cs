using System;
using System.Collections.Generic;
using System.Globalization;

using Result = MessagingToolkit.Barcode.Result;

namespace MessagingToolkit.Barcode.Client.Results
{

    /// <summary>
    /// Partially implements the iCalendar format's "VEVENT" format for specifying a
    /// calendar event. See RFC 2445. This supports SUMMARY, LOCATION, GEO, DTSTART and DTEND fields.
    /// 
    /// Modified: May 18 2012
    /// </summary>
    internal sealed class VEventResultParser : ResultParser
    {

        public override ParsedResult Parse(Result result)
        {
            String rawText = GetMassagedText(result);
            int vEventStart = rawText.IndexOf("BEGIN:VEVENT");
            if (vEventStart < 0)
            {
                return null;
            }

            String summary = MatchSingleVCardPrefixedField("SUMMARY", rawText, true);
            String start = MatchSingleVCardPrefixedField("DTSTART", rawText, true);
            if (start == null)
            {
                return null;
            }
            String end = MatchSingleVCardPrefixedField("DTEND", rawText, true);
            String location = MatchSingleVCardPrefixedField("LOCATION", rawText, true);
            String description = MatchSingleVCardPrefixedField("DESCRIPTION", rawText, true);

            String geoString = MatchSingleVCardPrefixedField("GEO", rawText, true);
            double latitude;
            double longitude;
            if (geoString == null)
            {
                latitude = System.Double.NaN;
                longitude = System.Double.NaN;
            }
            else
            {
                int semicolon = geoString.IndexOf(';');
                try
                {

                    latitude = Double.Parse(geoString.Substring(0, (semicolon) - (0)), NumberStyles.Float, CultureInfo.InvariantCulture);
                    longitude = Double.Parse(geoString.Substring(semicolon + 1), NumberStyles.Float, CultureInfo.InvariantCulture);
                }
                catch (Exception nfe)
                {
                    return null;
                }
            }

            try
            {
                return new CalendarParsedResult(summary, start, end, location, null, description, latitude, longitude);
            }
            catch (ArgumentException iae)
            {
                return null;
            }
        }

        private static String MatchSingleVCardPrefixedField(String prefix, String rawText, bool trim)
        {
            List<String> values = VCardResultParser.MatchSingleVCardPrefixedField(prefix, rawText, trim, false);
            return (values == null || (values.Count == 0)) ? null : values[0];
        }

    }
}