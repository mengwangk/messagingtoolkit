﻿
namespace MessagingToolkit.Barcode.DataMatrix.Encoder
{
    internal struct C40TextState
    {
        #region Properties

        internal int Shift { get; set; }

        internal bool UpperShift { get; set; }

        #endregion

    }
}