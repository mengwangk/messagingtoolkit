﻿
namespace MessagingToolkit.Barcode.Pdf417.Encoder
{
    
    public enum Compaction
    {
        Auto, Text, Byte, Numeric
    }
}
