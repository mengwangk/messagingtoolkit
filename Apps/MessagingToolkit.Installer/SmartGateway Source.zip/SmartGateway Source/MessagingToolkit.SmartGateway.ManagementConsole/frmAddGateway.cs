﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MessagingToolkit.SmartGateway.ManagementConsole
{
    public partial class frmAddGateway : Form
    {
        public frmAddGateway()
        {
            InitializeComponent();
        }

        private void AddGateway_Load(object sender, EventArgs e)
        {

        }
    }
}
