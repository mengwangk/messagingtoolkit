﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MessagingToolkit.SmartGateway.Core
{
    public partial class Messages : UserControl
    {
        public Messages()
        {
            InitializeComponent();
        }
    }
}
