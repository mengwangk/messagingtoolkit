﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Resources;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("MessagingToolkit UI Components")]
[assembly: AssemblyDescription("MessagingToolkit Windows Forms UI Components")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("TWIT88.COM")]
[assembly: AssemblyProduct("MessagingToolkit Windows Forms UI Components")]
[assembly: AssemblyCopyright("Copyright © 2011 TWIT88.COM")]
[assembly: AssemblyTrademark("MessagingToolkit UI Components")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("9a79f80d-9cf5-4408-9e84-c6ed02261edb")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
[assembly: AssemblyVersion("1.3.3.3")]
[assembly: AssemblyFileVersion("1.3.3.3")]
