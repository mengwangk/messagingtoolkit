﻿using System.Drawing;

using MessagingToolkit.DataMatrix.Common;

namespace MessagingToolkit.DataMatrix.Helper
{

    public sealed class MatrixToImageHelper
    {

        private const int Black = -16777216;
        private const int White = -1;

        private MatrixToImageHelper()
        {
        }

        /// <summary>
        /// Renders a <see cref="null"/> as an image, where "false" bits are rendered
        /// as white, and "true" bits are rendered as black.
        /// </summary>
        public static Image ToBitmap(BitMatrix matrix)
        {
            int width = matrix.Width;
            int height = matrix.Height;
            Bitmap image = new Bitmap(width, height);
            for (int x = 0; x < width; x++)
            {
                for (int y = 0; y < height; y++)
                {
                    image.SetPixel(x, y, (matrix.Get(x, y)) ? Color.FromArgb(Black) : Color.FromArgb(White));
                }
            }
            return image;
        }

        /// <summary>
        /// Renders a <see cref="null"/> as an image, where "false" bits are rendered
        /// as white, and "true" bits are rendered as black.
        /// </summary>
        /// <param name="matrix">The matrix.</param>
        /// <param name="foreColor">Color of the fore.</param>
        /// <param name="backColor">Color of the back.</param>
        /// <returns></returns>
        public static Image ToBitmap(BitMatrix matrix, Color foreColor, Color backColor)
        {
            int width = matrix.Width;
            int height = matrix.Height;
            Bitmap image = new Bitmap(width, height);
            for (int x = 0; x < width; x++)
            {
                for (int y = 0; y < height; y++)
                {
                    image.SetPixel(x, y, (matrix.Get(x, y)) ? foreColor : backColor);
                }
            }

            return image;
        }

    }
}
