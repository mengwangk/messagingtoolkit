using System.Collections.Generic;

namespace MessagingToolkit.DataMatrix.Helper
{
    /// <summary>
    /// Contains conversion support elements such as classes, interfaces and static methods.
    /// </summary>
    internal sealed class BarcodeHelper
    {
       
        /// <summary>
        /// Performs an unsigned bitwise right shift with the specified number
        /// </summary>
        /// <param name="number">Number to operate on</param>
        /// <param name="bits">Ammount of bits to shift</param>
        /// <returns>The resulting number from the shift operation</returns>
        public static int URShift(int number, int bits)
        {
            if (number >= 0)
                return number >> bits;
            else
                return (number >> bits) + (2 << ~bits);
        }

        public static object GetDecodeOptionType(Dictionary<DecodeOptions, object> dict, DecodeOptions key)
        {
            object ret = null;
            if (dict.TryGetValue(key, out ret))
               return ret;
            return null;
        }

        public static object GetEncodeOptionType(Dictionary<EncodeOptions, object> dict, EncodeOptions key)
        {
            object ret = null;
            if (dict.TryGetValue(key, out ret))
                return ret;
            return null;
        }

    }
}
