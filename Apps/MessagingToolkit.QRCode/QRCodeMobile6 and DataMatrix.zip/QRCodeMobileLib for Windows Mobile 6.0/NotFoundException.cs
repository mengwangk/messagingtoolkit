﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MessagingToolkit.DataMatrix
{
    /// <summary>
    /// Thrown when a barcode was not found in the image. It might have been
    /// partially detected but could not be confirmed.
    /// </summary>
    [Serializable]
    public sealed class NotFoundException : DataMatrixDecoderException
    {
        public static readonly NotFoundException Instance = new NotFoundException();

        private NotFoundException()
        {
            // do nothing
        }

       
    }
}
