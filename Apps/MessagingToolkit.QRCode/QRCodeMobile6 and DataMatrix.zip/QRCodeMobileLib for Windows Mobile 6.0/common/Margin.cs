﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MessagingToolkit.DataMatrix.Common
{
    public sealed class Margin
    {
        public int Left { get; set; }
        public int Right { get; set; }
        public int Top { get; set; }
        public int Bottom { get; set; }
    }
}
