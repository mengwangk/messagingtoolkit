//===============================================================================
// Copyright � TWIT88.COM.  All rights reserved.
//
// This file is part of Open Source Messaging Library.
//
// Open Source Messaging Library is free software: you can redistribute it 
// and/or modify it under the terms of the GNU General Public License version 3.
//
// Open Source Messaging Library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this software.  If not, see <http://www.gnu.org/licenses/>.
//===============================================================================

using System;
using System.Collections.Generic;

namespace MessagingToolkit.DataMatrix.Common
{

    /// <summary>
    /// Encapsulates a Character Set ECI, according to "Extended Channel Interpretations" 5.3.1.1
    /// of ISO 18004.
    /// </summary>
    public sealed class CharacterSetECI : ECI
    {
        private static Dictionary<int, CharacterSetECI> ValuetoEci;
        private static Dictionary<string, CharacterSetECI> NameToEci;

        private string encodingName;

        public string EncodingName
        {
            get
            {
                return encodingName;
            }
        }


        private static void Initialize()
        {
            ValuetoEci = new Dictionary<int, CharacterSetECI>(29);
            NameToEci = new Dictionary<string, CharacterSetECI>(29);
            // TODO figure out if these values are even right!
            AddCharacterSet(0, "Cp437");
            AddCharacterSet(1, new string[] { "ISO8859_1", "ISO-8859-1" });
            AddCharacterSet(2, "Cp437");
            AddCharacterSet(3, new string[] { "ISO8859_1", "ISO-8859-1" });
            AddCharacterSet(4, new string[] { "ISO8859_2", "ISO-8859-2" });
            AddCharacterSet(5, new string[] { "ISO8859_3", "ISO-8859-3" });
            AddCharacterSet(6, new string[] { "ISO8859_4", "ISO-8859-4" });
            AddCharacterSet(7, new string[] { "ISO8859_5", "ISO-8859-5" });
            AddCharacterSet(8, new string[] { "ISO8859_6", "ISO-8859-6" });
            AddCharacterSet(9, new string[] { "ISO8859_7", "ISO-8859-7" });
            AddCharacterSet(10, new string[] { "ISO8859_8", "ISO-8859-8" });
            AddCharacterSet(11, new string[] { "ISO8859_9", "ISO-8859-9" });
            AddCharacterSet(12, new string[] { "ISO8859_10", "ISO-8859-10" });
            AddCharacterSet(13, new string[] { "ISO8859_11", "ISO-8859-11" });
            AddCharacterSet(15, new string[] { "ISO8859_13", "ISO-8859-13" });
            AddCharacterSet(16, new string[] { "ISO8859_14", "ISO-8859-14" });
            AddCharacterSet(17, new string[] { "ISO8859_15", "ISO-8859-15" });
            AddCharacterSet(18, new string[] { "ISO8859_16", "ISO-8859-16" });
            AddCharacterSet(20, new string[] { "SJIS", "Shift_JIS", "SHIFT-JIS" });
        }


        /// <summary>
        /// Initializes a new instance of the <see cref="CharacterSetECI"/> class.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="encodingName">Name of the encoding.</param>
        private CharacterSetECI(int value, string encodingName)
            : base(value)
        {
            this.encodingName = encodingName;
        }

        private static void AddCharacterSet(int value, string encodingName)
        {
            CharacterSetECI eci = new CharacterSetECI(value, encodingName);
            ValuetoEci[(System.Int32)value] = eci; // can't use valueOf
            NameToEci[encodingName] = eci;
        }

        private static void AddCharacterSet(int value, string[] encodingNames)
        {
            CharacterSetECI eci = new CharacterSetECI(value, encodingNames[0]);
            ValuetoEci[(System.Int32)value] = eci; // can't use valueOf
            for (int i = 0; i < encodingNames.Length; i++)
            {
                NameToEci[encodingNames[i]] = eci;
            }
        }

        /// <summary>
        /// Gets the character set ECI by value.
        /// </summary>
        /// <param name="value_Renamed">The value_ renamed.</param>
        /// <returns>
        /// {@link CharacterSetECI} representing ECI of given value, or null if it is legal but
        /// unsupported
        /// </returns>
        /// <throws>  IllegalArgumentException if ECI value is invalid </throws>
        public static CharacterSetECI GetCharacterSetECIByValue(int value)
        {
            if (ValuetoEci == null)
            {
                Initialize();
            }
            if (value < 0 || value >= 900)
            {
                throw new ArgumentException("Bad ECI value: " + value);
            }
            if (ValuetoEci.ContainsKey((System.Int32)value))
                return (CharacterSetECI)ValuetoEci[(System.Int32)value];
            return null;
        }

        /// <summary>
        /// Gets the name of the character set ECI by.
        /// </summary>
        /// <param name="name">character set ECI encoding name</param>
        /// <returns>
        /// {@link CharacterSetECI} representing ECI for character encoding, or null if it is legal
        /// but unsupported
        /// </returns>
        public static CharacterSetECI GetCharacterSetECIByName(string name)
        {
            if (NameToEci == null)
            {
                Initialize();
            }
            if (NameToEci.ContainsKey(name))
            {
                return (CharacterSetECI)NameToEci[name];
            }
            return null;
        }
    }
}