//===============================================================================
// Copyright � TWIT88.COM.  All rights reserved.
//
// This file is part of Open Source Messaging Library.
//
// Open Source Messaging Library is free software: you can redistribute it 
// and/or modify it under the terms of the GNU General Public License version 3.
//
// Open Source Messaging Library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this software.  If not, see <http://www.gnu.org/licenses/>.
//===============================================================================

using System;

namespace MessagingToolkit.DataMatrix.Common
{
    /// <summary>
    /// Default grid sampler
    /// </summary>
    public sealed class DefaultGridSampler : GridSampler
    {

        public override BitMatrix SampleGrid(BitMatrix image, int dimensionX,
                int dimensionY, float p1ToX, float p1ToY, float p2ToX, float p2ToY,
                float p3ToX, float p3ToY, float p4ToX, float p4ToY, float p1FromX,
                float p1FromY, float p2FromX, float p2FromY, float p3FromX,
                float p3FromY, float p4FromX, float p4FromY)
        {

            PerspectiveTransform transform = PerspectiveTransform.QuadrilateralToQuadrilateral(p1ToX, p1ToY, p2ToX, p2ToY,
                            p3ToX, p3ToY, p4ToX, p4ToY, p1FromX, p1FromY, p2FromX,
                            p2FromY, p3FromX, p3FromY, p4FromX, p4FromY);

            return SampleGrid(image, dimensionX, dimensionY, transform);
        }

        public override BitMatrix SampleGrid(BitMatrix image, int dimensionX,
                int dimensionY, PerspectiveTransform transform)
        {
            if (dimensionX <= 0 || dimensionY <= 0)
            {
                throw NotFoundException.Instance;
            }
            BitMatrix bits = new BitMatrix(dimensionX, dimensionY);
            float[] points = new float[dimensionX << 1];
            for (int y = 0; y < dimensionY; y++)
            {
                int max = points.Length;
                float iValue = (float)y + 0.5f;
                for (int x = 0; x < max; x += 2)
                {
                    points[x] = (float)(x >> 1) + 0.5f;
                    points[x + 1] = iValue;
                }
                transform.TransformPoints(points);
                // Quick check to see if points transformed to something inside the image;
                // sufficient to check the endpoints
                GridSampler.CheckAndNudgePoints(image, points);
                try
                {
                    for (int x_0 = 0; x_0 < max; x_0 += 2)
                    {
                        if (image.Get((int)points[x_0], (int)points[x_0 + 1]))
                        {
                            // Black(-ish) pixel
                            bits.Set(x_0 >> 1, y);
                        }
                    }
                }
                catch (IndexOutOfRangeException aioobe)
                {
                    // This feels wrong, but, sometimes if the finder patterns are misidentified, the resulting
                    // transform gets "twisted" such that it maps a straight line of points to a set of points
                    // whose endpoints are in bounds, but others are not. There is probably some mathematical
                    // way to detect this about the transformation that I don't know yet.
                    // This results in an ugly runtime exception despite our clever checks above -- can't have
                    // that. We could check each point's coordinates but that feels duplicative. We settle for
                    // catching and wrapping ArrayIndexOutOfBoundsException.
                    throw NotFoundException.Instance;
                }
            }
            return bits;
        }

    }
}