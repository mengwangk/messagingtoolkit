﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MessagingToolkit.DataMatrix
{
    /// <summary>
    /// Thrown when a barcode was successfully detected, but some aspect of
    /// the content did not conform to the barcode's format rules. This could have
    /// been due to a mis-detection.
    /// </summary>
    ///
    [Serializable]
    public sealed class FormatException : DataMatrixDecoderException
    {

        public static readonly FormatException Instance = new FormatException();

        private FormatException()
        {
            // do nothing
        }
    }
}
