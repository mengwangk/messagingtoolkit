using System;
namespace MessagingToolkit.QRCode.ExceptionHandler
{
	public class VersionInformationException:System.ArgumentException
	{
	}
}