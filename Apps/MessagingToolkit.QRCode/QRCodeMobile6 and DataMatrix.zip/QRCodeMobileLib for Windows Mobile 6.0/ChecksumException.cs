﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MessagingToolkit.DataMatrix
{
    /// <summary>
    /// Thrown when a barcode was successfully detected and decoded, but
    /// was not returned because its checksum feature failed.
    /// </summary>
    [Serializable]
    public sealed class ChecksumException : DataMatrixDecoderException
    {

        public static readonly ChecksumException Instance = new ChecksumException();

        private ChecksumException()
        {
            // do nothing
        }
    }
}
