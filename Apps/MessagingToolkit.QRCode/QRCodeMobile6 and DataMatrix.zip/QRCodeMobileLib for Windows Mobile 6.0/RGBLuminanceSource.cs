﻿//===============================================================================
// Copyright © TWIT88.COM.  All rights reserved.
//
// This file is part of Open Source Messaging Library.
//
// Open Source Messaging Library is free software: you can redistribute it 
// and/or modify it under the terms of the GNU General Public License version 3.
//
// Open Source Messaging Library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this software.  If not, see <http://www.gnu.org/licenses/>.
//===============================================================================

using MessagingToolkit.DataMatrix;
using MessagingToolkit.DataMatrix.Common;
using System.Drawing.Imaging;
using System.Drawing;
using System;

namespace MessagingToolkit.DataMatrix
{

    public class RGBLuminanceSource : LuminanceSource
    {
        private byte[] luminances;
        private bool isRotated = false;
        private bool isRegionSelect = false;
        private System.Drawing.Rectangle region;

        override public int Height
        {
            get
            {
                if (!isRotated)
                    return height;
                else
                    return width;
            }

        }
        override public int Width
        {
            get
            {
                if (!isRotated)
                    return width;
                else
                    return height;
            }
        }

        public RGBLuminanceSource(byte[] d, int w, int h)
            : base(w, h)
        {
            this.width = w;
            this.height = h;
            int width = w;
            int height = h;
            // In order to measure pure decoding speed, we convert the entire image to a greyscale array
            // up front, which is the same as the Y channel of the YUVLuminanceSource in the real app.
            luminances = new byte[width * height];
            for (int y = 0; y < height; y++)
            {
                int offset = y * width;
                for (int x = 0; x < width; x++)
                {
                    int r = d[offset * 3 + x * 3];
                    int g = d[offset * 3 + x * 3 + 1];
                    int b = d[offset * 3 + x * 3 + 2];
                    if (r == g && g == b)
                    {
                        // Image is already greyscale, so pick any channel.
                        luminances[offset + x] = (byte)r;
                    }
                    else
                    {
                        // Calculate luminance cheaply, favoring green.
                        luminances[offset + x] = (byte)((r + g + g + b) >> 2);
                    }
                }
            }
        }
        public RGBLuminanceSource(byte[] d, int w, int H, bool is8Bit)
            : base(w, H)
        {
            width = w;
            height = H;
            luminances = new byte[w * H];
            Buffer.BlockCopy(d, 0, luminances, 0, w * H);
        }

        public RGBLuminanceSource(byte[] d, int W, int H, bool is8Bit, System.Drawing.Rectangle region)
            : base(W, H)
        {
            this.width = region.Width;
            this.height = region.Height;
            this.region = region;
            isRegionSelect = true;
            //luminances = Red.Imaging.Filters.CropArea(d, W, H, Region);
        }


        public RGBLuminanceSource(Bitmap d, int w, int h)
            : base(w, h)
        {
            int width = width = w;
            int height = height = h;
            // In order to measure pure decoding speed, we convert the entire image to a greyscale array
            // up front, which is the same as the Y channel of the YUVLuminanceSource in the real app.
            luminances = new byte[width * height];
            //if (format == PixelFormat.Format8bppIndexed)
            {
                Color c;
                for (int y = 0; y < height; y++)
                {
                    int offset = y * width;
                    for (int x = 0; x < width; x++)
                    {
                        c = d.GetPixel(x, y);
                        luminances[offset + x] = (byte)(((int)c.R) << 16 | ((int)c.G) << 8 | ((int)c.B));
                    }
                }
            }
        }
        override public byte[] GetRow(int y, byte[] row)
        {
            if (isRotated == false)
            {
                int width = Width;
                if (row == null || row.Length < width)
                {
                    row = new byte[width];
                }
                for (int i = 0; i < width; i++)
                    row[i] = luminances[y * width + i];
                //System.arraycopy(luminances, y * width, row, 0, width);
                return row;
            }
            else
            {
                int width = this.width;
                int height = this.height;
                if (row == null || row.Length < height)
                {
                    row = new byte[height];
                }
                for (int i = 0; i < height; i++)
                    row[i] = luminances[i * width + y];
                //System.arraycopy(luminances, y * width, row, 0, width);
                return row;
            }
        }
        public override byte[] Matrix
        {
            get { return luminances; }
        }

        public override LuminanceSource Crop(int left, int top, int width, int height)
        {
            return base.Crop(left, top, width, height);
        }
        public override LuminanceSource RotateCounterClockwise()
        {
            isRotated = true;
            return this;
        }
        public override bool RotateSupported
        {
            get
            {
                return true;
            }

        }
    }
}
