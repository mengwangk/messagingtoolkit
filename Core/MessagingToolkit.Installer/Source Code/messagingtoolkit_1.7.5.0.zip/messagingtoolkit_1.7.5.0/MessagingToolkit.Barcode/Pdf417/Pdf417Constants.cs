﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MessagingToolkit.Barcode.Pdf417
{
    public sealed class PDF417Constants
    {
        public static readonly int MODULES_IN_SYMBOL = 17;
    }
}
