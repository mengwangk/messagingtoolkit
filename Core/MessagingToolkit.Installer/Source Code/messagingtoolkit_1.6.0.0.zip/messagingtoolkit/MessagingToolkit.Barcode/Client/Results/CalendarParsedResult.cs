using System;
using System.Text;

namespace MessagingToolkit.Barcode.Client.Results
{

    /// <summary>
    /// Modified: May 10 2012
    /// </summary>
    public sealed class CalendarParsedResult : ParsedResult
    {

        private readonly String summary;
        private readonly String start;
        private readonly String end;
        private readonly String location;
        private readonly String attendee;
        private readonly String description;
        private readonly double latitude;
        private readonly double longitude;

        public CalendarParsedResult(String summary, String start, String end, String location, String attendee, String description)
            : this(summary, start, end, location, attendee, description, System.Double.NaN, System.Double.NaN)
        {
        }

        public CalendarParsedResult(String summary, String start, String end, String location, String attendee, String description, double latitude, double longitude)
            : base(ParsedResultType.Calendar)
        {
            ValidateDate(start);
            this.summary = summary;
            this.start = start;
            if (end != null)
            {
                ValidateDate(end);
                this.end = end;
            }
            else
            {
                this.end = null;
            }
            this.location = location;
            this.attendee = attendee;
            this.description = description;
            this.latitude = latitude;
            this.longitude = longitude;
        }

        public String GetSummary()
        {
            return summary;
        }

        /// <summary>
        /// <p>We would return the start and end date as a <see cref="T:System.DateTime"/> except that this code
        /// needs to work under JavaME / MIDP and there is no date parsing library available there, such
        /// as }.</p> See validateDate() for the return format.
        /// </summary>
        ///
        /// <returns>start time formatted as a RFC 2445 DATE or DATE-TIME.</p></returns>
        public String GetStart()
        {
            return start;
        }


        /// <seealso cref="M:CalendarParsedResult.GetStart"/>
        public String GetEnd()
        {
            return end;
        }

        public String GetLocation()
        {
            return location;
        }

        public String GetAttendee()
        {
            return attendee;
        }

        public String GetDescription()
        {
            return description;
        }

        public double GetLatitude()
        {
            return latitude;
        }

        public double GetLongitude()
        {
            return longitude;
        }

        public override String DisplayResult
        {
            get
            {
                StringBuilder result = new StringBuilder(100);
                ParsedResult.MaybeAppend(summary, result);
                ParsedResult.MaybeAppend(start, result);
                ParsedResult.MaybeAppend(end, result);
                ParsedResult.MaybeAppend(location, result);
                ParsedResult.MaybeAppend(attendee, result);
                ParsedResult.MaybeAppend(description, result);
                return result.ToString();
            }
        }

        /// <summary>
        /// RFC 2445 allows the start and end fields to be of type DATE (e.g. 20081021) or DATE-TIME
        /// (e.g. 20081021T123000 for local time, or 20081021T123000Z for UTC).
        /// </summary>
        ///
        /// <param name="date">The string to validate</param>
        private static void ValidateDate(String date)
        {
            if (date != null)
            {
                int length = date.Length;
                if (length != 8 && length != 15 && length != 16)
                {
                    throw new ArgumentException();
                }
                for (int i = 0; i < 8; i++)
                {
                    if (!Char.IsDigit(date[i]))
                    {
                        throw new ArgumentException();
                    }
                }
                if (length > 8)
                {
                    if (date[8] != 'T')
                    {
                        throw new ArgumentException();
                    }
                    for (int i_0 = 9; i_0 < 15; i_0++)
                    {
                        if (!Char.IsDigit(date[i_0]))
                        {
                            throw new ArgumentException();
                        }
                    }
                    if (length == 16 && date[15] != 'Z')
                    {
                        throw new ArgumentException();
                    }
                }
            }
        }

    }
}