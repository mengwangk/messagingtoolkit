﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MessagingToolkit.Barcode.Client.Results
{
    /// <summary>
    /// Parses a WIFI configuration string.  Strings will be of the form:
    /// WIFI:T:WPA;S:mynetwork;P:mypass;;
    /// The fields can come in any order, and there should be tests to see
    /// if we can parse them all correctly.
    /// 
    /// Modified: May 18 2012
    /// </summary>
    internal sealed class WifiResultParser : ResultParser
    {

        public override ParsedResult Parse(Result result)
        {
            String rawText = GetMassagedText(result);
            if (!rawText.StartsWith("WIFI:"))
            {
                return null;
            }
            // Don't remove leading or trailing whitespace
            bool trim = false;
            String ssid = MatchSinglePrefixedField("S:", rawText, ';', trim);
            if (ssid == null || ssid.Length == 0)
            {
                return null;
            }
            String pass = MatchSinglePrefixedField("P:", rawText, ';', trim);
            String type = MatchSinglePrefixedField("T:", rawText, ';', trim);
            if (type == null)
            {
                type = "nopass";
            }

            return new WifiParsedResult(type, ssid, pass);
        }
    }
}
