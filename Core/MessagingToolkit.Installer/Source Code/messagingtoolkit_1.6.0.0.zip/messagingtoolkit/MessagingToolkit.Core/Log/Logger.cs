﻿//===============================================================================
// OSML - Open Source Messaging Library
//
//===============================================================================
// Copyright © TWIT88.COM.  All rights reserved.
//
// This file is part of Open Source Messaging Library.
//
// Open Source Messaging Library is free software: you can redistribute it 
// and/or modify it under the terms of the GNU General Public License version 3.
//
// Open Source Messaging Library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this software.  If not, see <http://www.gnu.org/licenses/>.
//===============================================================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Collections;
using System.Collections.Specialized;
using System.Diagnostics;
using System.Globalization;
using System.Reflection;

namespace MessagingToolkit.Core.Log
{
    /// <summary>
    /// The LogProfile enum is the only part of this
    /// class that will require modification for your
    /// particular applications use.  
    /// The LogThis logger class supports log profiles
    /// allowing multiple logging strategies when desired.
    /// One example:
    ///		A primary log file for customer consumption and
    ///		then a second log file for when you need to do
    ///		debugging.  Some developers prefer to have debugging
    ///		information go to a second file for any number of
    ///		reasons.  In that case you would add some other enum
    ///		value to the LogProfile enum.  You would have any
    ///		normal logging use the primary log profile and any debugging
    ///		logging use the other profile.  
    ///		This is just a simple example.  You can have any number of
    ///		logging profiles based on your requirements just by adding
    ///		them.  See the tutorial on using multiple profiles for more
    ///		information.
    /// </summary>
    public enum LogProfile
    {
        Primary = 1,
        System
    }

    /// <summary>
    /// Log level
    /// </summary>
    public enum LogLevel
    {
        /// <summary>
        /// Error
        /// </summary>
        Error = 1,
        /// <summary>
        /// Warning
        /// </summary>
        Warn,
        /// <summary>
        /// Information
        /// </summary>
        Info,
        /// <summary>
        /// Verbose for debugging
        /// </summary>
        Verbose
    }

    /// <summary>
    /// Log destination
    /// </summary>
    public enum LogDestination
    {
        /// <summary>
        /// Log to event log
        /// </summary>
        EventLog,
        /// <summary>
        /// Log to file
        /// </summary>
        File,
        /// <summary>
        /// Log to event log and file
        /// </summary>
        EventLogAndFile
    }

    /// <summary>
    /// Logging prefix
    /// </summary>
    public enum LogPrefix
    {
        /// <summary>
        /// No prefix
        /// </summary>
        None,
        /// <summary>
        /// Date 
        /// </summary>
        Dt,
        /// <summary>
        /// Log level
        /// </summary>
        LogLevel,
        /// <summary>
        /// Date and log level
        /// </summary>
        DtLogLevel
    }

    /// <summary>
    /// Log header level
    /// </summary>
    public enum LogHeaderLevel
    {
        /// <summary>
        /// First level
        /// </summary>
        FirstLevel,
        /// <summary>
        /// Second level
        /// </summary>
        SecondLevel,
        /// <summary>
        /// Third level
        /// </summary>
        ThirdLevel
    }

    /// <summary>
    /// Log period
    /// </summary>
    public enum LogPeriod
    {
        /// <summary>
        /// None
        /// </summary>
        None,
        /// <summary>
        /// Day
        /// </summary>
        Day,
        /// <summary>
        /// Week
        /// </summary>
        Week,
        /// <summary>
        /// Month
        /// </summary>
        Month
    }

    /// <summary>
    /// Log name format
    /// </summary>
    public enum LogNameFormat
    {
        /// <summary>
        /// By name
        /// </summary>
        NameDate,
        /// <summary>
        /// By date
        /// </summary>
        DateName,
        /// <summary>
        /// By name only
        /// </summary>
        Name
    }

    /// <summary>
    /// Log quota format
    /// </summary>
    public enum LogQuotaFormat
    {
        /// <summary>
        /// No restriction
        /// </summary>
        NoRestriction,
        /// <summary>
        /// By kilobytes
        /// </summary>
        KbBytes,
        /// <summary>
        /// By number of rows
        /// </summary>
        Rows
    }

    /// <summary>
    /// Logger class
    /// </summary>
    public class Logger
    {
        /*
		 * Some methods are overloaded, allowing the caller to specify the log profile.
		 * None of the properties support the caller specifying the log profile.  
		 * In the case of properties, it is necessary to set Log.Profile to a valid
		 * log profile and then address the properties.  
		 * Properties:
		 *				LogLevel:
		 *				LogWhere:
		 *				LogName:
		 *				Profile: This property contains the currently chosen log profile.
		 * 
		 * DefaultToPrimaryProfile:
		 *			True:	When true and when the log profile isn't explicitly specified
		 *					then the primary log profile will be implied.
		 *					Note: The value of True is only supported when just a single
		 *					log profile exists.  Creating additional log profiles will 
		 *					automatically set this to false.  A value of True makes it
		 *					simplier to work with when using a single log profile because
		 *					all methods and properties default to the primary profile.
		 *			False:	The profile to be used will be the most recently
		 *					chosen one that was set using Log.Profile = LogProfile.YourProfile
		 * 
		 */
        private static ListDictionary logList;
        private static LogMethods logMethods;
        private static LogProfile logProfile;
        private static bool defaultToPrimaryProfile = true;


        /// <summary>
        /// Logs the text
        /// </summary>
        /// <param name="logtext">The log text.</param>
        /// <param name="loglevel">The log level.</param>
        public static void LogThis(string logtext, LogLevel loglevel)
        {
            if (defaultToPrimaryProfile)
            {
                LogThis(LogProfile.Primary, logtext, loglevel);
            }
            else //log to current profile
            {
                logMethods.LogThis(logtext, loglevel);
            }
        }

        /// <summary>
        /// Logs the text
        /// </summary>
        /// <param name="logtext">The log text.</param>
        /// <param name="loglevel">The log level.</param>
        /// <param name="prefix">The prefix.</param>
        public static void LogThis(string logtext, LogLevel loglevel, string prefix)
        {
            if (!string.IsNullOrEmpty(prefix))
            {
                logtext = "[" + prefix + "] " + logtext;
            }
            LogThis(logtext, loglevel);
        }

        
        /// <summary>
        /// Uses the sensible defaults.
        /// </summary>
        public static void UseSensibleDefaults()
        {
            /* 
             * LogLevel.Info allows LogHeaders, warnings and errors to show up in log.
             */
            UseSensibleDefaults(LogLevel.Info);
        }

        /// <summary>
        /// Uses the sensible defaults.
        /// </summary>
        /// <param name="logLevel">The log level.</param>
        public static void UseSensibleDefaults(LogLevel logLevel)
        {
            /*
             * Uses default values for the log filename and path.
             * 
             */
            string[] logFile = DefaultLogFileAndLocation();
            UseSensibleDefaults(logFile[1], logFile[0], logLevel);
        }

        /// <summary>
        /// Uses the sensible defaults.
        /// </summary>
        /// <param name="logFileName">Name of the log file.</param>
        /// <param name="logLocation">The log location.</param>
        /// <param name="logLevel">The log level.</param>
        public static void UseSensibleDefaults(string logFileName, string logLocation, LogLevel logLevel)
        {
            // create an instance of Log()
            Logger logger = new Logger();

            //init the profiles you intend to use. 

            /*
                The profile concept is the only complicated thing about LogThis and unless
                you have some need to log in multiple different ways *in the same project*
                then just default to the primary profile.  All the settings you see below are 
                configuring the primary profile.  To have multiple profiles you would 
                call Mylog.Init(LogProfile.your_made_up_profile) and then set these same
                settings for that profile also. 
	 
                One possible scenerio for using multiple profiles might be having different 
                parts of the code log to different files with different quota settings 
                or one part to a file and the other part to the event log.
                It's a lame example but you get the gist hopefully.
            */
            logger.Init();  // This is the same as Mylog.Init(LogProfile.primary) .

            /*	You only need the Mylog instance just long enough to run Init.  Now
                you can just use the static methods to perform all logging actions,
                which is the most of the reason I wrote LogThis.
            */
            logger = null;

            /*
                Set the properties for the primary log profile.
                Log.Profile sets the *active* profile, and it remains the active profile
                unless you set it explicitly.  Any calls to Log.LogThis or any other Log
                methods will use the active profile.
            */
            Logger.Profile = LogProfile.Primary;
            
            // I prefer a simple text file log but you can change this 
            // to use the event log also.
            Logger.LogWhere = LogDestination.File;

            if (Convert.ToInt32(Logger.LogLevel) < 1)
            {
                Logger.LogLevel = LogLevel.Error; //errors show at the minimum.
            }
            else
            {
                Logger.LogLevel = logLevel;
            }
            string[] fileDefaults = DefaultLogFileAndLocation();
            if (logFileName == string.Empty)
                Logger.LogName = fileDefaults[1];
            else
                Logger.LogName = logFileName;

            if (logLocation == string.Empty)
                Logger.LogBasePath = fileDefaults[0];
            else
                Logger.LogBasePath = logLocation;

            //evaluate the quota size as meaning kbytes.
            //Logger.LogQuotaFormat = LogQuotaFormat.KbBytes;
            //So, max logfile size = (Log.LogQuotaFormat * Log.LogSizeMax)
            //Logger.LogSizeMax = 100;
                        
            Logger.LogQuotaFormat = LogQuotaFormat.NoRestriction;

            //Every Log.LogPeriod the log file will roll over to a new file.
            Logger.LogPeriod = LogPeriod.Month;
            //The log filename will be formatted this way.
            Logger.LogNameFormat = LogNameFormat.NameDate;
            Logger.SetLogPath();
            /*
                ok, all things required as init configuration have now
                been set.  Simply call Log.LogThis or Log.LogHeader 
                anywhere in your code.

                            Example: 
				
                Log.LogHeader(Log.LogName + ": Starting up",LogHeaderLevel.FirstLevel);
                ...
                Log.LogThis("Main: " + e.Message,LogLevel.error);
                ...
                Log.LogHeader(Log.LogName + ": Exiting",LogHeaderLevel.FirstLevel);
            */


        }
        private static string[] DefaultLogFileAndLocation()
        {
            return GetBasename((string)System.Reflection.Assembly.GetExecutingAssembly().Location);
        }

        public static string[] GetBasename(string filePath)
        {
            /*
             * Example:  filePath = "c:\temp\file1.exe"
             * string[0] is "c:\temp"
             * string[1] is "file1.exe"
             * string[2] is "exe"
            */
            string[] a = filePath.Split('\\');
            string[] baseInfo = new string[3];
            baseInfo[1] = a[a.Length - 1];
            a = baseInfo[1].Split('.');
            if (a.Length > 1)
            {
                try
                {
                    baseInfo[2] = a[a.Length - 1];
                    baseInfo[1] = baseInfo[1].Remove(baseInfo[1].Length - baseInfo[2].Length - 1, baseInfo[2].Length + 1);
                }
                catch (Exception ex)
                {
                    Debug.Write(ex.Message);
                }
            }
            //locate base path without the last (slash + filename + extension)
            for (int i = 0; i < filePath.Length - ((baseInfo[1].Length) + (baseInfo[2].Length + 1)) - 1; i++)
            {
                baseInfo[0] += filePath[i];
            }

            return baseInfo;

        }

        public static void LogThis(LogProfile logprofile, string logtext, LogLevel loglevel)
        {
            ((LogMethods)logList[Convert.ToString(logprofile)]).LogThis(logtext, loglevel);
        }

        public static void LogThis(LogProfile logprofile, string logtext, LogLevel loglevel, LogPrefix logprefix)
        {
            ((LogMethods)logList[Convert.ToString(logprofile)]).LogThis(logtext, loglevel, logprefix);
        }

        public static void LogThis(string logtext, LogLevel loglevel, LogPrefix logprefix)
        {
            if (defaultToPrimaryProfile)
            {
                LogThis(LogProfile.Primary, logtext, loglevel, logprefix);
            }
            else //log to current profile
            {
                logMethods.LogThis(logtext, loglevel, logprefix);
            }
        }

        /// <summary>
        /// Gets or sets the profile.
        /// </summary>
        /// <value>The profile.</value>
        public static LogProfile Profile
        {
            get
            {
                return logProfile;
            }
            set
            {
                logProfile = (LogProfile)value;
                logMethods = (LogMethods)logList[Convert.ToString(logProfile)];
            }
        }

        /// <summary>
        /// Gets a value indicating whether [default to primary profile].
        /// </summary>
        /// <value>
        /// 	<c>true</c> if [default to primary profile]; otherwise, <c>false</c>.
        /// </value>
        public static bool DefaultToPrimaryProfile
        {
            get
            {
                return defaultToPrimaryProfile;
            }
        }

        /// <summary>
        /// Gets or sets the log level.
        /// </summary>
        /// <value>The log level.</value>
        public static LogLevel LogLevel
        {
            get
            {
                if (defaultToPrimaryProfile)
                {
                    return ((LogMethods)logList[Convert.ToString(LogProfile.Primary)]).LogLevel;
                }
                else //default to current
                {
                    return logMethods.LogLevel;
                }
            }
            set
            {
                if (defaultToPrimaryProfile)
                {
                    ((LogMethods)logList[Convert.ToString(LogProfile.Primary)]).LogLevel = (LogLevel)value;
                }
                else //default to current
                {
                    logMethods.LogLevel = (LogLevel)value;
                }
            }
        }

        /// <summary>
        /// Gets or sets the log destination.
        /// </summary>
        /// <value>The log destination.</value>
        public static LogDestination LogWhere
        {
            get
            {
                if (defaultToPrimaryProfile)
                {
                    return ((LogMethods)logList[Convert.ToString(LogProfile.Primary)]).LogDestination;
                }
                else //default to current
                {
                    return logMethods.LogDestination;
                }
            }
            set
            {
                if (defaultToPrimaryProfile)
                {
                    ((LogMethods)logList[Convert.ToString(LogProfile.Primary)]).LogDestination = (LogDestination)value;
                }
                else //default to current
                {
                    logMethods.LogDestination = value;
                }
            }
        }
        public static string LogName
        {
            get
            {
                if (defaultToPrimaryProfile)
                {
                    return ((LogMethods)logList[Convert.ToString(LogProfile.Primary)]).LogName;
                }
                else //default to current
                {
                    return logMethods.LogName;
                }
            }
            set
            {
                if (defaultToPrimaryProfile)
                {
                    ((LogMethods)logList[Convert.ToString(LogProfile.Primary)]).LogName = value;
                }
                else //default to current
                {
                    logMethods.LogName = value;
                }
            }
        }
        public static string LogBasePath
        {
            // example:  LogBasePath("c:\temp")
            // Default value: LogThis will place log in folder where exe is running.
            get
            {
                if (defaultToPrimaryProfile)
                {
                    return ((LogMethods)logList[Convert.ToString(LogProfile.Primary)]).LogBasePath;
                }
                else //default to current
                {
                    return logMethods.LogBasePath;
                }
            }
            set
            {
                if (defaultToPrimaryProfile)
                {
                    ((LogMethods)logList[Convert.ToString(LogProfile.Primary)]).LogBasePath = value;
                }
                else //default to current
                {
                    logMethods.LogBasePath = value;
                }
            }
        }
        public static string LogPath
        {
            // This value is set in SetLogPath().  It will be LogBasePath + LogName + the chosen datestamp 
            get
            {
                if (defaultToPrimaryProfile)
                {
                    return ((LogMethods)logList[Convert.ToString(LogProfile.Primary)]).LogPath;
                }
                else //default to current
                {
                    return logMethods.LogPath;
                }
            }
            set
            {
                // This is not intended to be set by user code.  SetLogPath() will override.
                if (defaultToPrimaryProfile)
                {
                    ((LogMethods)logList[Convert.ToString(LogProfile.Primary)]).LogPath = value;
                }
                else //default to current.
                {
                    logMethods.LogPath = value;
                }
            }
        }
        public static string ProcessName
        {
            get
            {
                if (defaultToPrimaryProfile)
                {
                    return ((LogMethods)logList[Convert.ToString(LogProfile.Primary)]).ProcessName;
                }
                else //default to current
                {
                    return logMethods.ProcessName;
                }
            }
            set
            {
                if (defaultToPrimaryProfile)
                {
                    ((LogMethods)logList[Convert.ToString(LogProfile.Primary)]).ProcessName = value;
                }
                else //default to current
                {
                    logMethods.ProcessName = value;
                }
            }
        }
        public static LogPeriod LogPeriod
        {
            get
            {
                if (defaultToPrimaryProfile)
                {
                    return ((LogMethods)logList[Convert.ToString(LogProfile.Primary)]).LogPeriod;
                }
                else //default to current
                {
                    return logMethods.LogPeriod;
                }
            }
            set
            {
                if (defaultToPrimaryProfile)
                {
                    ((LogMethods)logList[Convert.ToString(LogProfile.Primary)]).LogPeriod = (LogPeriod)value;
                }
                else //default to current
                {
                    logMethods.LogPeriod = value;
                }
            }
        }
        public static LogNameFormat LogNameFormat
        {
            get
            {
                if (defaultToPrimaryProfile)
                {
                    return ((LogMethods)logList[Convert.ToString(LogProfile.Primary)]).LogNameFormat;
                }
                else //default to current
                {
                    return logMethods.LogNameFormat;
                }
            }
            set
            {
                if (defaultToPrimaryProfile)
                {
                    ((LogMethods)logList[Convert.ToString(LogProfile.Primary)]).LogNameFormat = (LogNameFormat)value;
                }
                else //default to current
                {
                    logMethods.LogNameFormat = (LogNameFormat)value;
                }
            }
        }
        public static LogQuotaFormat LogQuotaFormat
        {
            get
            {
                if (defaultToPrimaryProfile)
                {
                    return ((LogMethods)logList[Convert.ToString(LogProfile.Primary)]).LogQuotaFormat;
                }
                else //default to current
                {
                    return logMethods.LogQuotaFormat;
                }
            }
            set
            {
                if (defaultToPrimaryProfile)
                {
                    ((LogMethods)logList[Convert.ToString(LogProfile.Primary)]).LogQuotaFormat = (LogQuotaFormat)value;
                }
                else //default to current
                {
                    logMethods.LogQuotaFormat = (LogQuotaFormat)value;
                }
            }
        }
        public static LogPrefix LogPrefix
        {
            get
            {
                if (defaultToPrimaryProfile)
                {
                    return ((LogMethods)logList[Convert.ToString(LogProfile.Primary)]).LogPrefix;
                }
                else //default to current
                {
                    return logMethods.LogPrefix;
                }
            }
            set
            {
                if (defaultToPrimaryProfile)
                {
                    ((LogMethods)logList[Convert.ToString(LogProfile.Primary)]).LogPrefix = (LogPrefix)value;
                }
                else //default to current
                {
                    logMethods.LogPrefix = (LogPrefix)value;
                }
            }
        }
        /// <summary>
        /// Gets or sets the maximum log size
        /// </summary>
        /// <value>Log maximum size</value>
        public static int LogSizeMax
        {
            get
            {
                if (defaultToPrimaryProfile)
                {
                    return ((LogMethods)logList[Convert.ToString(LogProfile.Primary)]).LogSizeMax;
                }
                else //default to current
                {
                    return logMethods.LogSizeMax;
                }
            }
            set
            {
                if (defaultToPrimaryProfile)
                {
                    ((LogMethods)logList[Convert.ToString(LogProfile.Primary)]).LogSizeMax = value;
                }
                else //default to current
                {
                    logMethods.LogSizeMax = value;
                }
            }
        }
        /// <summary>
        /// Sets the log path.
        /// </summary>
        public static void SetLogPath()
        {
            if (defaultToPrimaryProfile)
            {
                SetLogPath(LogProfile.Primary);
            }
            else //default to current
            {
                logMethods.SetLogPath();
            }
        }
        public static void SetLogPath(LogProfile logprofile)
        {
            ((LogMethods)logList[Convert.ToString(logprofile)]).SetLogPath();
        }
        public static void LogReset()
        {
            if (defaultToPrimaryProfile)
            {
                LogReset(LogProfile.Primary);
            }
            else //default to current
            {
                logMethods.LogReset();
            }
        }
        public static void LogReset(LogProfile logprofile)
        {
            ((LogMethods)logList[Convert.ToString(logprofile)]).LogReset();
        }
        public static void LogHeader(string sText, LogHeaderLevel logheaderlevel)
        {
            if (defaultToPrimaryProfile)
            {
                LogHeader(LogProfile.Primary, sText, logheaderlevel);
            }
            else
            {
                LogHeader(logProfile, sText, logheaderlevel);
            }
        }

        /// <summary>
        /// Clears the log.
        /// </summary>
        public static void ClearLog()
        {
            try
            {
                using (FileStream stream = new FileStream(LogPath, FileMode.Create))
                using (TextWriter writer = new StreamWriter(stream))
                {
                    writer.WriteLine(string.Empty);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(string.Format("Error in clearing log file: {0}", ex.Message));
            }
        }

        public static void LogHeader(LogProfile logprofile, string sText, LogHeaderLevel logheaderlevel)
        {
            string sHeader = "";
            DateTime dt = DateTime.Now;
            switch (logheaderlevel)
            {
                case LogHeaderLevel.FirstLevel:
                    sHeader = "======(" + System.AppDomain.CurrentDomain.FriendlyName + ") ====  " + sText + "============ Date:" + dt.ToString("yyyyMMdd") + " Time:" + dt.ToString("hh:mm:ss");
                    break;
                case LogHeaderLevel.SecondLevel:
                    sHeader = "------" + sText + " ============ Time:" + dt.ToString("hh:mm:ss");
                    break;
                case LogHeaderLevel.ThirdLevel:
                    sHeader = "---" + sText + " --- Time:" + dt.ToString("hh:mm:ss");
                    break;
            }
            LogThis(sHeader, LogLevel.Info, LogPrefix.None);
        }
        public static LogMethods GetProfile(LogProfile logprofile)
        {
            return (LogMethods)logList[Convert.ToString(logprofile)];
        }
        public void Init()
        {
            Init(LogProfile.Primary);

        }
        public void Init(LogProfile logprofile)
        {

            if (logList == null)
            {
                logList = new ListDictionary();
            }
            if (logList.Contains(Convert.ToString(logprofile))) { return; }
            logMethods = new LogMethods();
            logList.Add(Convert.ToString(logprofile), logMethods);
            Profile = logprofile;
            if (logList.Count > 1 | logprofile != LogProfile.Primary)
            {
                //Once there are more than just the primary log profile then the properties 
                //can no longer default to just the primary profile.
                defaultToPrimaryProfile = false;
            }
        }
    }

    public class LogMethods //: System.IDisposable
    {
        private LogLevel logLevel = LogLevel.Error;
        private LogDestination logDestination = LogDestination.EventLog;
        private LogPeriod logPeriod = LogPeriod.None;
        private LogNameFormat logNameFormat = LogNameFormat.NameDate;
        private string processName = System.AppDomain.CurrentDomain.FriendlyName;
        private string logFileName = System.AppDomain.CurrentDomain.FriendlyName;
        private LogQuotaFormat logQuotaFormat = LogQuotaFormat.NoRestriction;
        private int logSizeMax = 0;
        private LogPrefix logPrefix = LogPrefix.DtLogLevel;
        private string logFilePath = "";
        private string logBasePath = string.Empty;
        private string logFileType = ".log";
        private static object writerLock = new object();

        public LogLevel LogLevel
        {
            get
            {
                return logLevel;
            }
            set
            {
                logLevel = (LogLevel)value;
            }
        }

        public LogDestination LogDestination
        {
            get
            {
                return logDestination;
            }
            set
            {
                logDestination = value;
            }
        }
        public LogNameFormat LogNameFormat
        {
            get
            {
                return logNameFormat;
            }
            set
            {
                logNameFormat = value;
            }
        }
        public LogPrefix LogPrefix
        {
            get
            {
                return logPrefix;
            }
            set
            {
                logPrefix = value;
            }
        }
        public string LogName
        {
            get
            {
                return logFileName;
            }
            set
            {
                logFileName = value;
            }
        }
        public string LogBasePath
        {
            get
            {
                return logBasePath;
            }
            set
            {
                logBasePath = value;
            }
        }
        /// <summary>
        /// Gets or sets the log path.
        /// </summary>
        /// <value>The log path.</value>
        public string LogPath
        {
            get
            {
                return logFilePath;
            }
            set
            {
                logFilePath = value;
            }
        }
        public string ProcessName
        {
            get
            {
                return processName;
            }
            set
            {
                processName = value;
            }
        }
        public LogPeriod LogPeriod
        {
            get
            {
                return logPeriod;
            }
            set
            {
                logPeriod = (LogPeriod)value;
            }
        }
        public LogQuotaFormat LogQuotaFormat
        {
            get
            {
                return logQuotaFormat;
            }
            set
            {
                logQuotaFormat = (LogQuotaFormat)value;
            }
        }
        public int LogSizeMax
        {
            get
            {
                return logSizeMax;
            }
            set
            {
                logSizeMax = value;
            }
        }

        public void LogReset()
        {
            if (!(LogName == null))
            {
                File.Delete(LogName);
            }
        }

        private void AppendToFile(string sPath, string sText)
        {
            StreamWriter sw;
            sw = File.AppendText(sPath);
            sw.WriteLine(sText);
            sw.Close();
        }
        private void LogEvent(string sText, LogLevel loglevel)
        {
            EventLogEntryType EventType;
            switch (loglevel)
            {
                case LogLevel.Error:
                    EventType = EventLogEntryType.Error;
                    break;
                case LogLevel.Warn:
                    EventType = EventLogEntryType.Warning;
                    break;
                case LogLevel.Info:
                    EventType = EventLogEntryType.Information;
                    break;
                default:
                    EventType = EventLogEntryType.Information;
                    break;
            }
            //open and write to event log.
            System.Diagnostics.EventLog oEV = new System.Diagnostics.EventLog();
            oEV.Source = processName;
            oEV.WriteEntry(sText, EventType);
            oEV.Close();
        }

        public void TruncateLogFile()
        {
            TruncateLogFile(LogPath);
        }

        public void TruncateLogFile(string sLogPath)
        {
            if (logQuotaFormat == LogQuotaFormat.NoRestriction) { return; }

            long nfileSize = 0;
            long i = 0;
            long j = 0;
            if (!File.Exists(sLogPath)) { return; }
            switch (logQuotaFormat)
            {
                case LogQuotaFormat.KbBytes:
                    try
                    {
                        FileInfo info = new FileInfo(sLogPath);
                        nfileSize = info.Length;
                    }
                    catch (Exception x)
                    {
                        System.Console.WriteLine("Error:" + x.Message);
                        nfileSize = 0;
                    }
                    if (nfileSize < (logSizeMax * 1024))
                    { return; }
                    break;
                case LogQuotaFormat.Rows:
                    using (StreamReader sr = new StreamReader(sLogPath))
                    {
                        String line;
                        while ((line = sr.ReadLine()) != null)
                        {
                            i++;
                        }
                        if (i < logSizeMax) { return; }
                    }
                    break;
            }

            File.Delete(sLogPath + ".new");
            StreamWriter sw;

            sw = File.AppendText(sLogPath + ".new");
            using (StreamReader sr = new StreamReader(sLogPath))
            {
                switch (logQuotaFormat)
                {
                    case LogQuotaFormat.KbBytes:
                        char[] c = null;
                        long bufsize = 1024; //should match streams natural buffer size.
                        long kb = 1024;
                        j = (long)((logSizeMax * kb) * .9);
                        while (sr.Peek() >= 0)
                        {
                            c = new char[bufsize];
                            sr.Read(c, 0, c.Length);
                            i++;
                            if ((i * bufsize) > j)
                            {
                                for (i = 0; i < c.Length; i++)
                                {
                                    if (c[i] == '\r' && c[i + 1] == '\n')
                                    {
                                        //write out the remaining part of the last line.
                                        char[] c2 = new char[i + 2];
                                        Array.Copy(c, 0, c2, 0, i + 2);
                                        sw.Write(c2);
                                        break;
                                    }

                                }

                                break;
                            }
                            else
                            {
                                sw.Write(c);
                            }
                        }
                        break;
                    case LogQuotaFormat.Rows:
                        String line;
                        j = (long)(logSizeMax * .9); //reduce by 10% below max.
                        while ((line = sr.ReadLine()) != null)
                        {
                            sw.WriteLine(line);
                            i++;
                            if (i > j) { break; }
                        }
                        break;
                }
            }
            sw.Close();

            File.Delete(sLogPath);
            File.Move(sLogPath + ".new", sLogPath);
        }
        private string GetWeek()
        {
            //I got this code right out of MSDN and only decided to change the 
            //week to start on Monday instead of Sunday for logging.
            //The first and last week of the year will likely be less than 7 days.

            // Gets the Calendar instance associated with a CultureInfo.
            CultureInfo myCI = new CultureInfo("en-US");
            Calendar myCal = myCI.Calendar;

            // Gets the DTFI properties required by GetWeekOfYear.
            CalendarWeekRule myCWR = myCI.DateTimeFormat.CalendarWeekRule;
            //DayOfWeek myFirstDOW = myCI.DateTimeFormat.FirstDayOfWeek;
            DayOfWeek myFirstDOW = DayOfWeek.Monday;
            // Displays the total number of weeks in the current year.
            DateTime LastDay = new System.DateTime(DateTime.Now.Year, 12, 31);
            //Console.WriteLine( "There are {0} weeks in the current year ({1}).", myCal.GetWeekOfYear( LastDay, myCWR, myFirstDOW ), LastDay.Year );
            return myCal.GetWeekOfYear(DateTime.Now, myCWR, myFirstDOW).ToString();

        }
        public void SetLogPath()
        {
            string sPeriod = "";
            string sLogName = logFileName;
            if (!(LogPeriod == LogPeriod.None))
            {
                DateTime dt = DateTime.Now;

                switch (logPeriod)
                {
                    case LogPeriod.Day:
                        sPeriod = dt.ToString("yyyyMMdd");
                        break;
                    case LogPeriod.Week:
                        string week = GetWeek();
                        sPeriod = dt.ToString("yyyyweek" + week);
                        break;
                    case LogPeriod.Month:
                        sPeriod = dt.ToString("yyyyMM");
                        break;
                }

                switch (logNameFormat)
                {
                    case LogNameFormat.DateName:
                        sLogName = sPeriod + "_" + logFileName;
                        break;
                    case LogNameFormat.NameDate:
                        sLogName = logFileName + "_" + sPeriod;
                        break;
                    case LogNameFormat.Name:
                        sLogName = logFileName;
                        break;
                }
            }
            string sFilePath;
            if (logBasePath == string.Empty)
                sFilePath = System.Environment.CurrentDirectory.TrimEnd('\\') + "\\" + sLogName + logFileType;
            else
                sFilePath = logBasePath.TrimEnd('\\') + @"\" + sLogName + logFileType;

            logFilePath = sFilePath;
            //return sFilePath;
            return;
        }
        
        /// <summary>
        /// Logs the text
        /// </summary>
        /// <param name="logtext">The log text</param>
        /// <param name="loglevel">The log level</param>
        public void LogThis(string logtext, LogLevel loglevel)
        {
            LogThis(logtext, loglevel, logPrefix);
        }

       
        /// <summary>
        /// Log to the destination
        /// </summary>
        /// <param name="logtext"></param>
        /// <param name="loglevel"></param>
        /// <param name="logprefix"></param>
        public void LogThis(string logtext, LogLevel loglevel, LogPrefix logprefix)
        {
            lock (writerLock)
            {
                if (logLevel >= loglevel)
                {
                    string sFilePath = LogPath;
                    if (sFilePath == "")
                    {
                        SetLogPath();
                        sFilePath = LogPath;
                    }
                    TruncateLogFile(sFilePath);
                    DateTime dt = DateTime.Now;
                    switch (logprefix)
                    {
                        case LogPrefix.Dt:
                            logtext = dt.ToString("yyyy.MM.dd") + "-" + dt.ToString("hh.mm.ss") + ": " + logtext;
                            break;
                        case LogPrefix.LogLevel:
                            logtext = loglevel.ToString() + ": " + logtext;
                            break;
                        case LogPrefix.DtLogLevel:
                            logtext = dt.ToString("yyyy.MM.dd") + "-" + dt.ToString("hh.mm.ss") + ":" + loglevel + ": " + logtext;
                            break;
                    }

                    //log it
                    switch (logDestination)
                    {
                        case LogDestination.File:
                            AppendToFile(sFilePath, logtext);
                            break;
                        case LogDestination.EventLog:
                            LogEvent(logtext, loglevel);
                            break;
                        case LogDestination.EventLogAndFile:
                            AppendToFile(sFilePath, logtext);
                            LogEvent(logtext, loglevel);
                            break;
                    }
                }
            }
        }
    }
}

