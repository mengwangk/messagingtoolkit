﻿//===============================================================================
// OSML - Open Source Messaging Library
//
//===============================================================================
// Copyright © TWIT88.COM.  All rights reserved.
//
// This file is part of Open Source Messaging Library.
//
// Open Source Messaging Library is free software: you can redistribute it 
// and/or modify it under the terms of the GNU General Public License version 3.
//
// Open Source Messaging Library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this software.  If not, see <http://www.gnu.org/licenses/>.
//===============================================================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MessagingToolkit.Core.Mobile
{
    /// <summary>
    /// Memory status
    /// </summary>
    public class MemoryStatus
    {
        private int total;
        private int used;


        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="used"></param>
        /// <param name="total"></param>
        public MemoryStatus(int used, int total)
        {
            this.used = used;
            this.total = total;
        }


        /// <summary>
        /// </summary>
        /// <value></value>
        public int Total
        {
            get
            {
                return this.total;
            }
        }

        /// <summary>
        /// </summary>
        /// <value></value>
        public int Used
        {
            get
            {
                return this.used;
            }
        }
    }
}
