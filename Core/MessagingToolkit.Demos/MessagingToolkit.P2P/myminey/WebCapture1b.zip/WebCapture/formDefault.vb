Imports Microsoft.Win32
Imports System.Text.RegularExpressions
Imports System
Imports System.Drawing
Imports System.Drawing.Graphics
Imports System.Drawing.Imaging
Imports System.IO

Public Class formDefault
  Public CommandLine As Boolean = False
  Public isCaptureEvent As Boolean = False
  Public ImageCaptured As Boolean = False
  Public ServerReturn As Boolean = False
  Public arrayFormats As New ArrayList()
  Public arrayGuidlines As New ArrayList()
  'Public arrayThumbnails As New ArrayList()
  Public SaveFormats As String = ""
  Public SaveGuidlines As String = ""
  'Public SaveThumbnails As String = ""

  Public SavePath As String = System.Windows.Forms.Application.StartupPath & "\Captured"

  Private Sub buttonBrowse_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles buttonBrowse.Click
    dialogBrowse.SelectedPath = SavePath
    dialogBrowse.ShowDialog()
    If (dialogBrowse.SelectedPath.ToString.Length > 0) Then
      textSavePath.Text = dialogBrowse.SelectedPath.ToString
      setLastRun("SavePath", textSavePath.Text)
      SavePath = textSavePath.Text
    End If
  End Sub

  Private Sub checkIEI_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles checkIEI.CheckedChanged
    If (checkIEI.Checked) Then
      checkIEInt(False, True)
    Else
      checkIEInt(True, False)
    End If
  End Sub

  Private Sub textDocumentURL_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles textDocumentURL.TextChanged
    enableCapture()
    textBaseName.Text = textDocumentURL.Text
  End Sub

  Private Sub WebBrowser_DocumentCompleted(ByVal sender As System.Object, ByVal e As System.Windows.Forms.WebBrowserDocumentCompletedEventArgs) Handles WebBrowser1.DocumentCompleted
    If (isCaptureEvent) Then
      DrawWebImage()
    End If
  End Sub
  Private Sub textBaseName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles textBaseName.TextChanged
    textBaseName.Text = Regex.Replace(textBaseName.Text, "(\\|\/|\:|\*|\?|\""|\<|\>|\.|\|)?", "")
    enableCapture()
  End Sub

  Private Sub checkAutoOverwrite_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles checkAutoOverwrite.CheckedChanged
    setLastRun("AutoOverwrite", checkAutoOverwrite.Checked.ToString)
  End Sub

  Private Sub textTextOverlay_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles textTextOverlay.TextChanged
    setLastRun("TextOverlay", textTextOverlay.Text)
  End Sub

  Private Sub textSavePath_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles textSavePath.TextChanged
    SavePath = textSavePath.Text
  End Sub

  Private Sub formDefault_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    'Me.Text = Environment.CommandLine
    'LastRun.SavePath
    SavePath = getLastRun("SavePath")
    'LastRun.DocumentURL
    textDocumentURL.Text = getLastRun("DocumentURL")
    'LastRun.SaveFormats
    If (getLastRun("SaveFormats").Length > 0) Then
      Dim formatArray As String()
      Dim RegexObj As New Regex(",")
      Dim i As Integer
      formatArray = RegexObj.Split(getLastRun("SaveFormats"))
      For i = 0 To formatArray.Length - 1
        Select Case formatArray(i).ToString
          Case "png"
            checkSavePNG.Checked = True
          Case "jpeg"
            checkSaveJPEG.Checked = True
          Case "gif"
            checkSaveGIF.Checked = True
          Case "tiff"
            checkSaveTIFF.Checked = True
          Case "bmp"
            checkSaveBMP.Checked = True
          Case "emf"
            checkSaveEMF.Checked = True
          Case "wmf"
            checkSaveWMF.Checked = True
        End Select
      Next
    End If
    'LastRun.Guidelines
    If (getLastRun("Guidelines").length > 0) Then
      textResolutionSyntax.Text = getLastRun("SaveGuidelines_")
      If getLastRun("Guidelines") = "Syntax" Then
        tabResolution.SelectTab(1)
      End If
    End If
    If (getLastRun("SaveGuidelines").Length > 0) Then
      Dim formatArray As String()
      Dim RegexObj As New Regex(",")
      Dim i As Integer
      formatArray = RegexObj.Split(getLastRun("SaveGuidelines"))
      For i = 0 To formatArray.Length - 1
        Select Case formatArray(i).ToString
          Case "640x480"
            checkResolution640x480.Checked = True
          Case "800x600"
            checkResolution800x600.Checked = True
          Case "1024x768"
            checkResolution1024x768.Checked = True
          Case "1280x720"
            checkResolution1280x720.Checked = True
          Case "1280x1024"
            checkResolution1280x1024.Checked = True
          Case "1440x900"
            checkResolution1440x900.Checked = True
          Case "1680x1050"
            checkResolution1680x1050.Checked = True
          Case "1600x1200"
            checkResolution1600x1200.Checked = True
          Case "1920x1200"
            checkResolution1920x1200.Checked = True
        End Select
      Next
    End If
    'LastRun.AutoOverwrite
    checkAutoOverwrite.Checked = getLastRun("AutoOverwrite")
    'LastRun.TextOverlay
    textTextOverlay.Text = getLastRun("TextOverlay")
    checkIEInt(False, False)
    textSavePath.Text = SavePath
  End Sub
  'Capture Web Page
  Private Sub buttonCapture_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles buttonCapture.Click
    isCaptureEvent = True
    If (CommandLine = False) Then
      setLastRun("DocumentURL", textDocumentURL.Text)
      setLastRun("SaveFormats", SaveFormats)
      setLastRun("BaseName", textBaseName.Text)
      setLastRun("AutoOverwrite", checkAutoOverwrite.Checked.ToString)
      setLastRun("TextOverlay", textTextOverlay.Text)
      setLastRun("SavePath", textSavePath.Text)
      WebBrowser1.Navigate(textDocumentURL.Text)
      buttonCapture.Enabled = False
      tabCollection.Enabled = False
    Else
      'parse command line
    End If
  End Sub
  'Save Foramts
  Private Sub checkSavePNG_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles checkSavePNG.CheckedChanged
    ListFormat("png", checkSavePNG.Checked)
  End Sub
  Private Sub checkSaveJPEG_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles checkSaveJPEG.CheckedChanged
    ListFormat("jpeg", checkSaveJPEG.Checked)
  End Sub
  Private Sub checkSaveGIF_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles checkSaveGIF.CheckedChanged
    ListFormat("gif", checkSaveGIF.Checked)
  End Sub
  Private Sub checkSaveTIFF_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles checkSaveTIFF.CheckedChanged
    ListFormat("tiff", checkSaveTIFF.Checked)
  End Sub
  Private Sub checkSaveBMP_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles checkSaveBMP.CheckedChanged
    ListFormat("bmp", checkSaveBMP.Checked)
  End Sub
  Private Sub checkSaveEMF_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles checkSaveEMF.CheckedChanged
    ListFormat("emf", checkSaveEMF.Checked)
  End Sub
  Private Sub checkSaveWMF_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles checkSaveWMF.CheckedChanged
    ListFormat("wmf", checkSaveWMF.Checked)
  End Sub
  Private Sub checkSaveAll_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles checkSaveAll.CheckedChanged
    If (checkSaveAll.Checked) Then
      checkSavePNG.Checked = True
      checkSaveJPEG.Checked = True
      checkSaveGIF.Checked = True
      checkSaveTIFF.Checked = True
      checkSaveBMP.Checked = True
      checkSaveEMF.Checked = True
      checkSaveWMF.Checked = True
    End If
  End Sub
  'Resolution Guidlines
  Private Sub checkResolution640x480_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles checkResolution640x480.CheckedChanged
    ListGuideLine("640x480", checkResolution640x480.Checked)
  End Sub
  Private Sub checkResolution800x600_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles checkResolution800x600.CheckedChanged
    ListGuideLine("800x600", checkResolution800x600.Checked)
  End Sub
  Private Sub checkResolution1024x768_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles checkResolution1024x768.CheckedChanged
    ListGuideLine("1024x768", checkResolution1024x768.Checked)
  End Sub
  Private Sub checkResolution1280x720_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles checkResolution1280x720.CheckedChanged
    ListGuideLine("1280x720", checkResolution1280x720.Checked)
  End Sub
  Private Sub checkResolution1280x1024_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles checkResolution1280x1024.CheckedChanged
    ListGuideLine("1280x1024", checkResolution1280x1024.Checked)
  End Sub
  Private Sub checkResolution1440x900_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles checkResolution1440x900.CheckedChanged
    ListGuideLine("1440x900", checkResolution1440x900.Checked)
  End Sub
  Private Sub checkResolution1680x1050_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles checkResolution1680x1050.CheckedChanged
    ListGuideLine("1680x1050", checkResolution1680x1050.Checked)
  End Sub
  Private Sub checkResolution1600x1200_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles checkResolution1600x1200.CheckedChanged
    ListGuideLine("1600x1200", checkResolution1600x1200.Checked)
  End Sub
  Private Sub checkResolution1920x1200_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles checkResolution1920x1200.CheckedChanged
    ListGuideLine("1920x1200", checkResolution1920x1200.Checked)
  End Sub
  Private Sub textResolutionSyntax_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles textResolutionSyntax.TextChanged
    '[SS]doesn't check for NUMBERxNUMBER yet, only STRINGxSTRING
    Dim formatArray As String()
    Dim formatGuidelines As String = ""
    Dim RegexObj As New Regex(",")
    Dim i As Integer
    formatArray = RegexObj.Split(textResolutionSyntax.Text)
    For i = 0 To formatArray.Length - 1
      Dim RegexObjX As New Regex("x")
      Dim formatArrayX As String() = RegexObjX.Split(formatArray(i))
      If (formatArrayX.Length = 2) Then
        If (formatArrayX(0).ToString.Trim.Length > 0 And formatArrayX(1).ToString.Trim.Length > 0) Then
          If (formatGuidelines <> "") Then
            formatGuidelines += "," & formatArray(i).ToString
          Else
            formatGuidelines = formatArray(i).ToString
          End If
        End If
      End If
    Next
    setLastRun("SaveGuidelines_", formatGuidelines)
  End Sub

  Private Sub tabResolution_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tabResolution.SelectedIndexChanged
    setLastRun("Guidelines", tabResolution.SelectedTab.Text)
    arrayGuidlines.Clear()
    If (tabResolution.SelectedTab.Text = "Common") Then
      If (getLastRun("SaveGuidelines").Length > 0) Then
        Dim formatArray As String()
        Dim RegexObj As New Regex(",")
        Dim i As Integer
        formatArray = RegexObj.Split(getLastRun("SaveGuidelines"))
        For i = 0 To formatArray.Length - 1
          arrayGuidlines.Add(formatArray(i).ToString)
        Next
      End If
    Else
      If (getLastRun("SaveGuidelines_").Length > 0) Then
        Dim formatArray As String()
        Dim RegexObj As New Regex(",")
        Dim i As Integer
        formatArray = RegexObj.Split(getLastRun("SaveGuidelines_"))
        For i = 0 To formatArray.Length - 1
          arrayGuidlines.Add(formatArray(i).ToString)
        Next
      End If
    End If
  End Sub
End Class