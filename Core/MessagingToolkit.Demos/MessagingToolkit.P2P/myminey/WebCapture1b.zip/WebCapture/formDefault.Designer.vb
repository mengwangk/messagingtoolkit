<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class formDefault
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
    Dim labelVarResolutions As System.Windows.Forms.Label
    Me.pictureBanner = New System.Windows.Forms.PictureBox
    Me.labelVarPreview = New System.Windows.Forms.Label
    Me.textVarBaseName = New System.Windows.Forms.TextBox
    Me.tabServer = New System.Windows.Forms.TabPage
    Me.groupVariables = New System.Windows.Forms.GroupBox
    Me.checkVarResolutions = New System.Windows.Forms.CheckBox
    Me.checkVarThumbnails = New System.Windows.Forms.CheckBox
    Me.checkVarDocumentURL = New System.Windows.Forms.CheckBox
    Me.checkVarBaseName = New System.Windows.Forms.CheckBox
    Me.textVarDocumentURL = New System.Windows.Forms.TextBox
    Me.textVarResolutions = New System.Windows.Forms.TextBox
    Me.labelVarSuccessful = New System.Windows.Forms.Label
    Me.textVarThumbnails = New System.Windows.Forms.TextBox
    Me.labelVarThumnails = New System.Windows.Forms.Label
    Me.labelVarBaseName = New System.Windows.Forms.Label
    Me.checkVarSavedPath = New System.Windows.Forms.CheckBox
    Me.checkVarSavedFormats = New System.Windows.Forms.CheckBox
    Me.textVarSavedPath = New System.Windows.Forms.TextBox
    Me.labelVarSavedPath = New System.Windows.Forms.Label
    Me.textVarSavedFormats = New System.Windows.Forms.TextBox
    Me.labelVarSavedFormats = New System.Windows.Forms.Label
    Me.checkVarSuccessful = New System.Windows.Forms.CheckBox
    Me.checkVarProcessId = New System.Windows.Forms.CheckBox
    Me.labelVarProcessId = New System.Windows.Forms.Label
    Me.textVarSuccessful = New System.Windows.Forms.TextBox
    Me.labelVarDocumentURL = New System.Windows.Forms.Label
    Me.textVarProcessId = New System.Windows.Forms.TextBox
    Me.textProcessURL = New System.Windows.Forms.TextBox
    Me.textProcessId = New System.Windows.Forms.TextBox
    Me.labelProcessId = New System.Windows.Forms.Label
    Me.labelProcessURL = New System.Windows.Forms.Label
    Me.buttonCapture = New System.Windows.Forms.Button
    Me.checkIEI = New System.Windows.Forms.CheckBox
    Me.checkThumb125GIF = New System.Windows.Forms.CheckBox
    Me.checkThumb250GIF = New System.Windows.Forms.CheckBox
    Me.checkThumb125PNG = New System.Windows.Forms.CheckBox
    Me.checkThumb125JPEG = New System.Windows.Forms.CheckBox
    Me.checkThumb500JPEG = New System.Windows.Forms.CheckBox
    Me.tabSyntaxThumbnail = New System.Windows.Forms.TabPage
    Me.textThumbnailSyntax = New System.Windows.Forms.TextBox
    Me.checkThumb250JPEG = New System.Windows.Forms.CheckBox
    Me.checkThumb500PNG = New System.Windows.Forms.CheckBox
    Me.checkThumb250PNG = New System.Windows.Forms.CheckBox
    Me.CheckBox13 = New System.Windows.Forms.CheckBox
    Me.CheckBox14 = New System.Windows.Forms.CheckBox
    Me.CheckBox15 = New System.Windows.Forms.CheckBox
    Me.CheckBox16 = New System.Windows.Forms.CheckBox
    Me.CheckBox17 = New System.Windows.Forms.CheckBox
    Me.dialogBrowse = New System.Windows.Forms.FolderBrowserDialog
    Me.WebBrowser1 = New System.Windows.Forms.WebBrowser
    Me.TextBox2 = New System.Windows.Forms.TextBox
    Me.CheckBox18 = New System.Windows.Forms.CheckBox
    Me.CheckBox7 = New System.Windows.Forms.CheckBox
    Me.CheckBox11 = New System.Windows.Forms.CheckBox
    Me.CheckBox12 = New System.Windows.Forms.CheckBox
    Me.textBaseName = New System.Windows.Forms.TextBox
    Me.labelBaseName = New System.Windows.Forms.Label
    Me.labelSavePath = New System.Windows.Forms.Label
    Me.checkSaveWMF = New System.Windows.Forms.CheckBox
    Me.labelSaveFormats = New System.Windows.Forms.Label
    Me.checkSaveEMF = New System.Windows.Forms.CheckBox
    Me.labelDocumentURL = New System.Windows.Forms.Label
    Me.checkSaveBMP = New System.Windows.Forms.CheckBox
    Me.checkSaveJPEG = New System.Windows.Forms.CheckBox
    Me.checkSaveTIFF = New System.Windows.Forms.CheckBox
    Me.textSavePath = New System.Windows.Forms.TextBox
    Me.checkAutoOverwrite = New System.Windows.Forms.CheckBox
    Me.buttonBrowse = New System.Windows.Forms.Button
    Me.textTextOverlay = New System.Windows.Forms.TextBox
    Me.labelTextOverlay = New System.Windows.Forms.Label
    Me.textDocumentURL = New System.Windows.Forms.TextBox
    Me.tabGeneral = New System.Windows.Forms.TabPage
    Me.checkSaveAll = New System.Windows.Forms.CheckBox
    Me.checkSavePNG = New System.Windows.Forms.CheckBox
    Me.checkSaveGIF = New System.Windows.Forms.CheckBox
    Me.tabCollection = New System.Windows.Forms.TabControl
    Me.tabAdvanced = New System.Windows.Forms.TabPage
    Me.tabResolution = New System.Windows.Forms.TabControl
    Me.tabCommonResolution = New System.Windows.Forms.TabPage
    Me.checkResolution1680x1050 = New System.Windows.Forms.CheckBox
    Me.checkResolution1920x1200 = New System.Windows.Forms.CheckBox
    Me.checkResolution1600x1200 = New System.Windows.Forms.CheckBox
    Me.checkResolution1024x768 = New System.Windows.Forms.CheckBox
    Me.checkResolution1440x900 = New System.Windows.Forms.CheckBox
    Me.checkResolution1280x720 = New System.Windows.Forms.CheckBox
    Me.checkResolution1280x1024 = New System.Windows.Forms.CheckBox
    Me.checkResolution640x480 = New System.Windows.Forms.CheckBox
    Me.checkResolution800x600 = New System.Windows.Forms.CheckBox
    Me.tabSyntaxResolution = New System.Windows.Forms.TabPage
    Me.textResolutionSyntax = New System.Windows.Forms.TextBox
    Me.labelResolutionGuidlines = New System.Windows.Forms.Label
    Me.labelThumnailGeneration = New System.Windows.Forms.Label
    Me.tabThumbnail = New System.Windows.Forms.TabControl
    Me.tabCommonThumbnail = New System.Windows.Forms.TabPage
    Me.checkThumb500GIF = New System.Windows.Forms.CheckBox
    labelVarResolutions = New System.Windows.Forms.Label
    CType(Me.pictureBanner, System.ComponentModel.ISupportInitialize).BeginInit()
    Me.tabServer.SuspendLayout()
    Me.groupVariables.SuspendLayout()
    Me.tabSyntaxThumbnail.SuspendLayout()
    Me.tabGeneral.SuspendLayout()
    Me.tabCollection.SuspendLayout()
    Me.tabAdvanced.SuspendLayout()
    Me.tabResolution.SuspendLayout()
    Me.tabCommonResolution.SuspendLayout()
    Me.tabSyntaxResolution.SuspendLayout()
    Me.tabThumbnail.SuspendLayout()
    Me.tabCommonThumbnail.SuspendLayout()
    Me.SuspendLayout()
    '
    'labelVarResolutions
    '
    labelVarResolutions.AutoSize = True
    labelVarResolutions.Location = New System.Drawing.Point(269, 101)
    labelVarResolutions.Name = "labelVarResolutions"
    labelVarResolutions.Size = New System.Drawing.Size(65, 13)
    labelVarResolutions.TabIndex = 34
    labelVarResolutions.Text = "Resolutions:"
    '
    'pictureBanner
    '
    Me.pictureBanner.Image = Global.WebCapture.My.Resources.Resources.webcapture
    Me.pictureBanner.Location = New System.Drawing.Point(0, 0)
    Me.pictureBanner.Margin = New System.Windows.Forms.Padding(0)
    Me.pictureBanner.Name = "pictureBanner"
    Me.pictureBanner.Size = New System.Drawing.Size(550, 79)
    Me.pictureBanner.TabIndex = 0
    Me.pictureBanner.TabStop = False
    '
    'labelVarPreview
    '
    Me.labelVarPreview.AutoSize = True
    Me.labelVarPreview.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.labelVarPreview.Location = New System.Drawing.Point(7, 129)
    Me.labelVarPreview.Name = "labelVarPreview"
    Me.labelVarPreview.Size = New System.Drawing.Size(127, 12)
    Me.labelVarPreview.TabIndex = 51
    Me.labelVarPreview.Text = "[preivew  of query string here]"
    Me.labelVarPreview.UseMnemonic = False
    '
    'textVarBaseName
    '
    Me.textVarBaseName.Location = New System.Drawing.Point(340, 46)
    Me.textVarBaseName.Name = "textVarBaseName"
    Me.textVarBaseName.Size = New System.Drawing.Size(99, 20)
    Me.textVarBaseName.TabIndex = 45
    Me.textVarBaseName.Text = "bas"
    '
    'tabServer
    '
    Me.tabServer.Controls.Add(Me.groupVariables)
    Me.tabServer.Controls.Add(Me.textProcessURL)
    Me.tabServer.Controls.Add(Me.textProcessId)
    Me.tabServer.Controls.Add(Me.labelProcessId)
    Me.tabServer.Controls.Add(Me.labelProcessURL)
    Me.tabServer.Location = New System.Drawing.Point(4, 22)
    Me.tabServer.Name = "tabServer"
    Me.tabServer.Size = New System.Drawing.Size(518, 296)
    Me.tabServer.TabIndex = 2
    Me.tabServer.Text = "Server"
    Me.tabServer.UseVisualStyleBackColor = True
    '
    'groupVariables
    '
    Me.groupVariables.Controls.Add(Me.labelVarPreview)
    Me.groupVariables.Controls.Add(Me.textVarBaseName)
    Me.groupVariables.Controls.Add(Me.checkVarResolutions)
    Me.groupVariables.Controls.Add(Me.checkVarThumbnails)
    Me.groupVariables.Controls.Add(Me.checkVarDocumentURL)
    Me.groupVariables.Controls.Add(Me.checkVarBaseName)
    Me.groupVariables.Controls.Add(Me.textVarDocumentURL)
    Me.groupVariables.Controls.Add(Me.textVarResolutions)
    Me.groupVariables.Controls.Add(Me.labelVarSuccessful)
    Me.groupVariables.Controls.Add(labelVarResolutions)
    Me.groupVariables.Controls.Add(Me.textVarThumbnails)
    Me.groupVariables.Controls.Add(Me.labelVarThumnails)
    Me.groupVariables.Controls.Add(Me.labelVarBaseName)
    Me.groupVariables.Controls.Add(Me.checkVarSavedPath)
    Me.groupVariables.Controls.Add(Me.checkVarSavedFormats)
    Me.groupVariables.Controls.Add(Me.textVarSavedPath)
    Me.groupVariables.Controls.Add(Me.labelVarSavedPath)
    Me.groupVariables.Controls.Add(Me.textVarSavedFormats)
    Me.groupVariables.Controls.Add(Me.labelVarSavedFormats)
    Me.groupVariables.Controls.Add(Me.checkVarSuccessful)
    Me.groupVariables.Controls.Add(Me.checkVarProcessId)
    Me.groupVariables.Controls.Add(Me.labelVarProcessId)
    Me.groupVariables.Controls.Add(Me.textVarSuccessful)
    Me.groupVariables.Controls.Add(Me.labelVarDocumentURL)
    Me.groupVariables.Controls.Add(Me.textVarProcessId)
    Me.groupVariables.Location = New System.Drawing.Point(15, 127)
    Me.groupVariables.Name = "groupVariables"
    Me.groupVariables.Size = New System.Drawing.Size(484, 149)
    Me.groupVariables.TabIndex = 26
    Me.groupVariables.TabStop = False
    Me.groupVariables.Text = "Variables"
    '
    'checkVarResolutions
    '
    Me.checkVarResolutions.AutoSize = True
    Me.checkVarResolutions.Location = New System.Drawing.Point(445, 101)
    Me.checkVarResolutions.Name = "checkVarResolutions"
    Me.checkVarResolutions.Size = New System.Drawing.Size(15, 14)
    Me.checkVarResolutions.TabIndex = 50
    Me.checkVarResolutions.UseVisualStyleBackColor = True
    '
    'checkVarThumbnails
    '
    Me.checkVarThumbnails.AutoSize = True
    Me.checkVarThumbnails.Location = New System.Drawing.Point(445, 74)
    Me.checkVarThumbnails.Name = "checkVarThumbnails"
    Me.checkVarThumbnails.Size = New System.Drawing.Size(15, 14)
    Me.checkVarThumbnails.TabIndex = 48
    Me.checkVarThumbnails.UseVisualStyleBackColor = True
    '
    'checkVarDocumentURL
    '
    Me.checkVarDocumentURL.AutoSize = True
    Me.checkVarDocumentURL.Location = New System.Drawing.Point(207, 102)
    Me.checkVarDocumentURL.Name = "checkVarDocumentURL"
    Me.checkVarDocumentURL.Size = New System.Drawing.Size(15, 14)
    Me.checkVarDocumentURL.TabIndex = 42
    Me.checkVarDocumentURL.UseVisualStyleBackColor = True
    '
    'checkVarBaseName
    '
    Me.checkVarBaseName.AutoSize = True
    Me.checkVarBaseName.Location = New System.Drawing.Point(445, 49)
    Me.checkVarBaseName.Name = "checkVarBaseName"
    Me.checkVarBaseName.Size = New System.Drawing.Size(15, 14)
    Me.checkVarBaseName.TabIndex = 46
    Me.checkVarBaseName.UseVisualStyleBackColor = True
    '
    'textVarDocumentURL
    '
    Me.textVarDocumentURL.Location = New System.Drawing.Point(102, 99)
    Me.textVarDocumentURL.Name = "textVarDocumentURL"
    Me.textVarDocumentURL.Size = New System.Drawing.Size(99, 20)
    Me.textVarDocumentURL.TabIndex = 41
    Me.textVarDocumentURL.Text = "doc"
    '
    'textVarResolutions
    '
    Me.textVarResolutions.Location = New System.Drawing.Point(341, 98)
    Me.textVarResolutions.Name = "textVarResolutions"
    Me.textVarResolutions.Size = New System.Drawing.Size(98, 20)
    Me.textVarResolutions.TabIndex = 49
    Me.textVarResolutions.Text = "res"
    '
    'labelVarSuccessful
    '
    Me.labelVarSuccessful.AutoSize = True
    Me.labelVarSuccessful.Location = New System.Drawing.Point(34, 50)
    Me.labelVarSuccessful.Name = "labelVarSuccessful"
    Me.labelVarSuccessful.Size = New System.Drawing.Size(62, 13)
    Me.labelVarSuccessful.TabIndex = 28
    Me.labelVarSuccessful.Text = "Successful:"
    '
    'textVarThumbnails
    '
    Me.textVarThumbnails.Location = New System.Drawing.Point(340, 72)
    Me.textVarThumbnails.Name = "textVarThumbnails"
    Me.textVarThumbnails.Size = New System.Drawing.Size(99, 20)
    Me.textVarThumbnails.TabIndex = 47
    Me.textVarThumbnails.Text = "tmb"
    '
    'labelVarThumnails
    '
    Me.labelVarThumnails.AutoSize = True
    Me.labelVarThumnails.Location = New System.Drawing.Point(270, 75)
    Me.labelVarThumnails.Name = "labelVarThumnails"
    Me.labelVarThumnails.Size = New System.Drawing.Size(64, 13)
    Me.labelVarThumnails.TabIndex = 33
    Me.labelVarThumnails.Text = "Thumbnails:"
    '
    'labelVarBaseName
    '
    Me.labelVarBaseName.AutoSize = True
    Me.labelVarBaseName.Location = New System.Drawing.Point(269, 50)
    Me.labelVarBaseName.Name = "labelVarBaseName"
    Me.labelVarBaseName.Size = New System.Drawing.Size(65, 13)
    Me.labelVarBaseName.TabIndex = 32
    Me.labelVarBaseName.Text = "Base Name:"
    '
    'checkVarSavedPath
    '
    Me.checkVarSavedPath.AutoSize = True
    Me.checkVarSavedPath.Location = New System.Drawing.Point(445, 21)
    Me.checkVarSavedPath.Name = "checkVarSavedPath"
    Me.checkVarSavedPath.Size = New System.Drawing.Size(15, 14)
    Me.checkVarSavedPath.TabIndex = 44
    Me.checkVarSavedPath.UseVisualStyleBackColor = True
    '
    'checkVarSavedFormats
    '
    Me.checkVarSavedFormats.AutoSize = True
    Me.checkVarSavedFormats.Location = New System.Drawing.Point(207, 74)
    Me.checkVarSavedFormats.Name = "checkVarSavedFormats"
    Me.checkVarSavedFormats.Size = New System.Drawing.Size(15, 14)
    Me.checkVarSavedFormats.TabIndex = 40
    Me.checkVarSavedFormats.UseVisualStyleBackColor = True
    '
    'textVarSavedPath
    '
    Me.textVarSavedPath.Location = New System.Drawing.Point(340, 19)
    Me.textVarSavedPath.Name = "textVarSavedPath"
    Me.textVarSavedPath.Size = New System.Drawing.Size(99, 20)
    Me.textVarSavedPath.TabIndex = 43
    Me.textVarSavedPath.Text = "pth"
    '
    'labelVarSavedPath
    '
    Me.labelVarSavedPath.AutoSize = True
    Me.labelVarSavedPath.Location = New System.Drawing.Point(268, 22)
    Me.labelVarSavedPath.Name = "labelVarSavedPath"
    Me.labelVarSavedPath.Size = New System.Drawing.Size(66, 13)
    Me.labelVarSavedPath.TabIndex = 31
    Me.labelVarSavedPath.Text = "Saved Path:"
    '
    'textVarSavedFormats
    '
    Me.textVarSavedFormats.Location = New System.Drawing.Point(102, 72)
    Me.textVarSavedFormats.Name = "textVarSavedFormats"
    Me.textVarSavedFormats.Size = New System.Drawing.Size(99, 20)
    Me.textVarSavedFormats.TabIndex = 39
    Me.textVarSavedFormats.Text = "fmt"
    '
    'labelVarSavedFormats
    '
    Me.labelVarSavedFormats.AutoSize = True
    Me.labelVarSavedFormats.Location = New System.Drawing.Point(15, 75)
    Me.labelVarSavedFormats.Name = "labelVarSavedFormats"
    Me.labelVarSavedFormats.Size = New System.Drawing.Size(81, 13)
    Me.labelVarSavedFormats.TabIndex = 29
    Me.labelVarSavedFormats.Text = "Saved Formats:"
    '
    'checkVarSuccessful
    '
    Me.checkVarSuccessful.AutoSize = True
    Me.checkVarSuccessful.Checked = True
    Me.checkVarSuccessful.CheckState = System.Windows.Forms.CheckState.Checked
    Me.checkVarSuccessful.Enabled = False
    Me.checkVarSuccessful.Location = New System.Drawing.Point(207, 49)
    Me.checkVarSuccessful.Name = "checkVarSuccessful"
    Me.checkVarSuccessful.Size = New System.Drawing.Size(15, 14)
    Me.checkVarSuccessful.TabIndex = 38
    Me.checkVarSuccessful.UseVisualStyleBackColor = True
    '
    'checkVarProcessId
    '
    Me.checkVarProcessId.AutoSize = True
    Me.checkVarProcessId.Checked = True
    Me.checkVarProcessId.CheckState = System.Windows.Forms.CheckState.Checked
    Me.checkVarProcessId.Enabled = False
    Me.checkVarProcessId.Location = New System.Drawing.Point(207, 21)
    Me.checkVarProcessId.Name = "checkVarProcessId"
    Me.checkVarProcessId.Size = New System.Drawing.Size(15, 14)
    Me.checkVarProcessId.TabIndex = 36
    Me.checkVarProcessId.UseVisualStyleBackColor = True
    '
    'labelVarProcessId
    '
    Me.labelVarProcessId.AutoSize = True
    Me.labelVarProcessId.Location = New System.Drawing.Point(36, 23)
    Me.labelVarProcessId.Name = "labelVarProcessId"
    Me.labelVarProcessId.Size = New System.Drawing.Size(60, 13)
    Me.labelVarProcessId.TabIndex = 27
    Me.labelVarProcessId.Text = "Process Id:"
    '
    'textVarSuccessful
    '
    Me.textVarSuccessful.Location = New System.Drawing.Point(102, 46)
    Me.textVarSuccessful.Name = "textVarSuccessful"
    Me.textVarSuccessful.Size = New System.Drawing.Size(99, 20)
    Me.textVarSuccessful.TabIndex = 37
    Me.textVarSuccessful.Text = "bol"
    '
    'labelVarDocumentURL
    '
    Me.labelVarDocumentURL.AutoSize = True
    Me.labelVarDocumentURL.Location = New System.Drawing.Point(12, 102)
    Me.labelVarDocumentURL.Name = "labelVarDocumentURL"
    Me.labelVarDocumentURL.Size = New System.Drawing.Size(84, 13)
    Me.labelVarDocumentURL.TabIndex = 30
    Me.labelVarDocumentURL.Text = "Document URL:"
    '
    'textVarProcessId
    '
    Me.textVarProcessId.Location = New System.Drawing.Point(102, 19)
    Me.textVarProcessId.Name = "textVarProcessId"
    Me.textVarProcessId.Size = New System.Drawing.Size(99, 20)
    Me.textVarProcessId.TabIndex = 35
    Me.textVarProcessId.Text = "pid"
    '
    'textProcessURL
    '
    Me.textProcessURL.Location = New System.Drawing.Point(15, 84)
    Me.textProcessURL.Name = "textProcessURL"
    Me.textProcessURL.Size = New System.Drawing.Size(484, 20)
    Me.textProcessURL.TabIndex = 25
    '
    'textProcessId
    '
    Me.textProcessId.Location = New System.Drawing.Point(15, 28)
    Me.textProcessId.Name = "textProcessId"
    Me.textProcessId.Size = New System.Drawing.Size(484, 20)
    Me.textProcessId.TabIndex = 23
    '
    'labelProcessId
    '
    Me.labelProcessId.AutoSize = True
    Me.labelProcessId.Location = New System.Drawing.Point(12, 12)
    Me.labelProcessId.Name = "labelProcessId"
    Me.labelProcessId.Size = New System.Drawing.Size(60, 13)
    Me.labelProcessId.TabIndex = 22
    Me.labelProcessId.Text = "Process Id:"
    '
    'labelProcessURL
    '
    Me.labelProcessURL.AutoSize = True
    Me.labelProcessURL.Location = New System.Drawing.Point(12, 68)
    Me.labelProcessURL.Name = "labelProcessURL"
    Me.labelProcessURL.Size = New System.Drawing.Size(136, 13)
    Me.labelProcessURL.TabIndex = 24
    Me.labelProcessURL.Text = "WebCapture Process URL:"
    '
    'buttonCapture
    '
    Me.buttonCapture.Enabled = False
    Me.buttonCapture.Location = New System.Drawing.Point(463, 424)
    Me.buttonCapture.Name = "buttonCapture"
    Me.buttonCapture.Size = New System.Drawing.Size(75, 23)
    Me.buttonCapture.TabIndex = 56
    Me.buttonCapture.Text = "Capture"
    Me.buttonCapture.UseVisualStyleBackColor = True
    '
    'checkIEI
    '
    Me.checkIEI.AutoSize = True
    Me.checkIEI.Enabled = False
    Me.checkIEI.Location = New System.Drawing.Point(12, 428)
    Me.checkIEI.Name = "checkIEI"
    Me.checkIEI.Size = New System.Drawing.Size(156, 17)
    Me.checkIEI.TabIndex = 57
    Me.checkIEI.TabStop = False
    Me.checkIEI.Text = "Internet Explorer Integration"
    Me.checkIEI.UseVisualStyleBackColor = True
    '
    'checkThumb125GIF
    '
    Me.checkThumb125GIF.AutoSize = True
    Me.checkThumb125GIF.Location = New System.Drawing.Point(325, 58)
    Me.checkThumb125GIF.Name = "checkThumb125GIF"
    Me.checkThumb125GIF.Size = New System.Drawing.Size(124, 17)
    Me.checkThumb125GIF.TabIndex = 9
    Me.checkThumb125GIF.Text = "Small (125x125, GIF)"
    Me.checkThumb125GIF.UseVisualStyleBackColor = True
    '
    'checkThumb250GIF
    '
    Me.checkThumb250GIF.AutoSize = True
    Me.checkThumb250GIF.Location = New System.Drawing.Point(170, 58)
    Me.checkThumb250GIF.Name = "checkThumb250GIF"
    Me.checkThumb250GIF.Size = New System.Drawing.Size(136, 17)
    Me.checkThumb250GIF.TabIndex = 6
    Me.checkThumb250GIF.Text = "Medium (250x250, GIF)"
    Me.checkThumb250GIF.UseVisualStyleBackColor = True
    '
    'checkThumb125PNG
    '
    Me.checkThumb125PNG.AutoSize = True
    Me.checkThumb125PNG.Location = New System.Drawing.Point(325, 12)
    Me.checkThumb125PNG.Name = "checkThumb125PNG"
    Me.checkThumb125PNG.Size = New System.Drawing.Size(130, 17)
    Me.checkThumb125PNG.TabIndex = 7
    Me.checkThumb125PNG.Text = "Small (125x125, PNG)"
    Me.checkThumb125PNG.UseVisualStyleBackColor = True
    '
    'checkThumb125JPEG
    '
    Me.checkThumb125JPEG.AutoSize = True
    Me.checkThumb125JPEG.Location = New System.Drawing.Point(325, 35)
    Me.checkThumb125JPEG.Name = "checkThumb125JPEG"
    Me.checkThumb125JPEG.Size = New System.Drawing.Size(134, 17)
    Me.checkThumb125JPEG.TabIndex = 8
    Me.checkThumb125JPEG.Text = "Small (125x125, JPEG)"
    Me.checkThumb125JPEG.UseVisualStyleBackColor = True
    '
    'checkThumb500JPEG
    '
    Me.checkThumb500JPEG.AutoSize = True
    Me.checkThumb500JPEG.Location = New System.Drawing.Point(12, 35)
    Me.checkThumb500JPEG.Name = "checkThumb500JPEG"
    Me.checkThumb500JPEG.Size = New System.Drawing.Size(136, 17)
    Me.checkThumb500JPEG.TabIndex = 2
    Me.checkThumb500JPEG.Text = "Large (500x500, JPEG)"
    Me.checkThumb500JPEG.UseVisualStyleBackColor = True
    '
    'tabSyntaxThumbnail
    '
    Me.tabSyntaxThumbnail.Controls.Add(Me.textThumbnailSyntax)
    Me.tabSyntaxThumbnail.Location = New System.Drawing.Point(4, 22)
    Me.tabSyntaxThumbnail.Name = "tabSyntaxThumbnail"
    Me.tabSyntaxThumbnail.Padding = New System.Windows.Forms.Padding(3)
    Me.tabSyntaxThumbnail.Size = New System.Drawing.Size(476, 86)
    Me.tabSyntaxThumbnail.TabIndex = 1
    Me.tabSyntaxThumbnail.Text = "Syntax"
    Me.tabSyntaxThumbnail.UseVisualStyleBackColor = True
    '
    'textThumbnailSyntax
    '
    Me.textThumbnailSyntax.Enabled = False
    Me.textThumbnailSyntax.Location = New System.Drawing.Point(12, 12)
    Me.textThumbnailSyntax.Multiline = True
    Me.textThumbnailSyntax.Name = "textThumbnailSyntax"
    Me.textThumbnailSyntax.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
    Me.textThumbnailSyntax.Size = New System.Drawing.Size(448, 63)
    Me.textThumbnailSyntax.TabIndex = 10
    Me.textThumbnailSyntax.Text = "800x600;png|gif,500x500;png,600x600;png|jpg"
    '
    'checkThumb250JPEG
    '
    Me.checkThumb250JPEG.AutoSize = True
    Me.checkThumb250JPEG.Location = New System.Drawing.Point(170, 35)
    Me.checkThumb250JPEG.Name = "checkThumb250JPEG"
    Me.checkThumb250JPEG.Size = New System.Drawing.Size(146, 17)
    Me.checkThumb250JPEG.TabIndex = 5
    Me.checkThumb250JPEG.Text = "Medium (250x250, JPEG)"
    Me.checkThumb250JPEG.UseVisualStyleBackColor = True
    '
    'checkThumb500PNG
    '
    Me.checkThumb500PNG.AutoSize = True
    Me.checkThumb500PNG.Location = New System.Drawing.Point(12, 12)
    Me.checkThumb500PNG.Name = "checkThumb500PNG"
    Me.checkThumb500PNG.Size = New System.Drawing.Size(132, 17)
    Me.checkThumb500PNG.TabIndex = 1
    Me.checkThumb500PNG.Text = "Large (500x500, PNG)"
    Me.checkThumb500PNG.UseVisualStyleBackColor = True
    '
    'checkThumb250PNG
    '
    Me.checkThumb250PNG.AutoSize = True
    Me.checkThumb250PNG.Location = New System.Drawing.Point(170, 12)
    Me.checkThumb250PNG.Name = "checkThumb250PNG"
    Me.checkThumb250PNG.Size = New System.Drawing.Size(142, 17)
    Me.checkThumb250PNG.TabIndex = 4
    Me.checkThumb250PNG.Text = "Medium (250x250, PNG)"
    Me.checkThumb250PNG.UseVisualStyleBackColor = True
    '
    'CheckBox13
    '
    Me.CheckBox13.AutoSize = True
    Me.CheckBox13.Location = New System.Drawing.Point(12, 58)
    Me.CheckBox13.Name = "CheckBox13"
    Me.CheckBox13.Size = New System.Drawing.Size(118, 17)
    Me.CheckBox13.TabIndex = 2
    Me.CheckBox13.Text = "Small (90x90, PNG)"
    Me.CheckBox13.UseVisualStyleBackColor = True
    '
    'CheckBox14
    '
    Me.CheckBox14.AutoSize = True
    Me.CheckBox14.Location = New System.Drawing.Point(170, 58)
    Me.CheckBox14.Name = "CheckBox14"
    Me.CheckBox14.Size = New System.Drawing.Size(122, 17)
    Me.CheckBox14.TabIndex = 5
    Me.CheckBox14.Text = "Small (90x90, JPEG)"
    Me.CheckBox14.UseVisualStyleBackColor = True
    '
    'CheckBox15
    '
    Me.CheckBox15.AutoSize = True
    Me.CheckBox15.Location = New System.Drawing.Point(170, 12)
    Me.CheckBox15.Name = "CheckBox15"
    Me.CheckBox15.Size = New System.Drawing.Size(136, 17)
    Me.CheckBox15.TabIndex = 4
    Me.CheckBox15.Text = "Large (350x350, JPEG)"
    Me.CheckBox15.UseVisualStyleBackColor = True
    '
    'CheckBox16
    '
    Me.CheckBox16.AutoSize = True
    Me.CheckBox16.Location = New System.Drawing.Point(170, 35)
    Me.CheckBox16.Name = "CheckBox16"
    Me.CheckBox16.Size = New System.Drawing.Size(146, 17)
    Me.CheckBox16.TabIndex = 6
    Me.CheckBox16.Text = "Medium (175x175, JPEG)"
    Me.CheckBox16.UseVisualStyleBackColor = True
    '
    'CheckBox17
    '
    Me.CheckBox17.AutoSize = True
    Me.CheckBox17.Location = New System.Drawing.Point(12, 12)
    Me.CheckBox17.Name = "CheckBox17"
    Me.CheckBox17.Size = New System.Drawing.Size(132, 17)
    Me.CheckBox17.TabIndex = 1
    Me.CheckBox17.Text = "Large (350x350, PNG)"
    Me.CheckBox17.UseVisualStyleBackColor = True
    '
    'WebBrowser1
    '
    Me.WebBrowser1.AllowWebBrowserDrop = False
    Me.WebBrowser1.IsWebBrowserContextMenuEnabled = False
    Me.WebBrowser1.Location = New System.Drawing.Point(530, 82)
    Me.WebBrowser1.MinimumSize = New System.Drawing.Size(20, 20)
    Me.WebBrowser1.Name = "WebBrowser1"
    Me.WebBrowser1.ScriptErrorsSuppressed = True
    Me.WebBrowser1.ScrollBarsEnabled = False
    Me.WebBrowser1.Size = New System.Drawing.Size(20, 20)
    Me.WebBrowser1.TabIndex = 58
    Me.WebBrowser1.TabStop = False
    Me.WebBrowser1.Visible = False
    Me.WebBrowser1.WebBrowserShortcutsEnabled = False
    '
    'TextBox2
    '
    Me.TextBox2.Location = New System.Drawing.Point(12, 12)
    Me.TextBox2.Multiline = True
    Me.TextBox2.Name = "TextBox2"
    Me.TextBox2.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
    Me.TextBox2.Size = New System.Drawing.Size(448, 63)
    Me.TextBox2.TabIndex = 4
    Me.TextBox2.Text = "append:29x49.png;mpp:520x52.jpeg"
    '
    'CheckBox18
    '
    Me.CheckBox18.AutoSize = True
    Me.CheckBox18.Location = New System.Drawing.Point(12, 35)
    Me.CheckBox18.Name = "CheckBox18"
    Me.CheckBox18.Size = New System.Drawing.Size(142, 17)
    Me.CheckBox18.TabIndex = 3
    Me.CheckBox18.Text = "Medium (175x175, PNG)"
    Me.CheckBox18.UseVisualStyleBackColor = True
    '
    'CheckBox7
    '
    Me.CheckBox7.AutoSize = True
    Me.CheckBox7.Location = New System.Drawing.Point(325, 12)
    Me.CheckBox7.Name = "CheckBox7"
    Me.CheckBox7.Size = New System.Drawing.Size(126, 17)
    Me.CheckBox7.TabIndex = 7
    Me.CheckBox7.Text = "Large (350x350, GIF)"
    Me.CheckBox7.UseVisualStyleBackColor = True
    '
    'CheckBox11
    '
    Me.CheckBox11.AutoSize = True
    Me.CheckBox11.Location = New System.Drawing.Point(325, 58)
    Me.CheckBox11.Name = "CheckBox11"
    Me.CheckBox11.Size = New System.Drawing.Size(112, 17)
    Me.CheckBox11.TabIndex = 8
    Me.CheckBox11.Text = "Small (90x90, GIF)"
    Me.CheckBox11.UseVisualStyleBackColor = True
    '
    'CheckBox12
    '
    Me.CheckBox12.AutoSize = True
    Me.CheckBox12.Location = New System.Drawing.Point(325, 35)
    Me.CheckBox12.Name = "CheckBox12"
    Me.CheckBox12.Size = New System.Drawing.Size(136, 17)
    Me.CheckBox12.TabIndex = 9
    Me.CheckBox12.Text = "Medium (175x175, GIF)"
    Me.CheckBox12.UseVisualStyleBackColor = True
    '
    'textBaseName
    '
    Me.textBaseName.Location = New System.Drawing.Point(15, 198)
    Me.textBaseName.Name = "textBaseName"
    Me.textBaseName.Size = New System.Drawing.Size(390, 20)
    Me.textBaseName.TabIndex = 16
    '
    'labelBaseName
    '
    Me.labelBaseName.AutoSize = True
    Me.labelBaseName.Location = New System.Drawing.Point(12, 182)
    Me.labelBaseName.Name = "labelBaseName"
    Me.labelBaseName.Size = New System.Drawing.Size(65, 13)
    Me.labelBaseName.TabIndex = 15
    Me.labelBaseName.Text = "Base Name:"
    '
    'labelSavePath
    '
    Me.labelSavePath.AutoSize = True
    Me.labelSavePath.Location = New System.Drawing.Point(12, 126)
    Me.labelSavePath.Name = "labelSavePath"
    Me.labelSavePath.Size = New System.Drawing.Size(60, 13)
    Me.labelSavePath.TabIndex = 12
    Me.labelSavePath.Text = "Save Path:"
    '
    'checkSaveWMF
    '
    Me.checkSaveWMF.AutoSize = True
    Me.checkSaveWMF.Location = New System.Drawing.Point(338, 85)
    Me.checkSaveWMF.Name = "checkSaveWMF"
    Me.checkSaveWMF.Size = New System.Drawing.Size(52, 17)
    Me.checkSaveWMF.TabIndex = 10
    Me.checkSaveWMF.Text = "WMF"
    Me.checkSaveWMF.UseVisualStyleBackColor = True
    '
    'labelSaveFormats
    '
    Me.labelSaveFormats.AutoSize = True
    Me.labelSaveFormats.Location = New System.Drawing.Point(11, 68)
    Me.labelSaveFormats.Name = "labelSaveFormats"
    Me.labelSaveFormats.Size = New System.Drawing.Size(89, 13)
    Me.labelSaveFormats.TabIndex = 3
    Me.labelSaveFormats.Text = "Save as Formats:"
    '
    'checkSaveEMF
    '
    Me.checkSaveEMF.AutoSize = True
    Me.checkSaveEMF.Location = New System.Drawing.Point(284, 85)
    Me.checkSaveEMF.Name = "checkSaveEMF"
    Me.checkSaveEMF.Size = New System.Drawing.Size(48, 17)
    Me.checkSaveEMF.TabIndex = 9
    Me.checkSaveEMF.Text = "EMF"
    Me.checkSaveEMF.UseVisualStyleBackColor = True
    '
    'labelDocumentURL
    '
    Me.labelDocumentURL.AutoSize = True
    Me.labelDocumentURL.Location = New System.Drawing.Point(12, 12)
    Me.labelDocumentURL.Name = "labelDocumentURL"
    Me.labelDocumentURL.Size = New System.Drawing.Size(84, 13)
    Me.labelDocumentURL.TabIndex = 1
    Me.labelDocumentURL.Text = "Document URL:"
    '
    'checkSaveBMP
    '
    Me.checkSaveBMP.AutoSize = True
    Me.checkSaveBMP.Location = New System.Drawing.Point(228, 85)
    Me.checkSaveBMP.Name = "checkSaveBMP"
    Me.checkSaveBMP.Size = New System.Drawing.Size(49, 17)
    Me.checkSaveBMP.TabIndex = 8
    Me.checkSaveBMP.Text = "BMP"
    Me.checkSaveBMP.UseVisualStyleBackColor = True
    '
    'checkSaveJPEG
    '
    Me.checkSaveJPEG.AutoSize = True
    Me.checkSaveJPEG.Location = New System.Drawing.Point(69, 85)
    Me.checkSaveJPEG.Name = "checkSaveJPEG"
    Me.checkSaveJPEG.Size = New System.Drawing.Size(53, 17)
    Me.checkSaveJPEG.TabIndex = 5
    Me.checkSaveJPEG.Text = "JPEG"
    Me.checkSaveJPEG.UseVisualStyleBackColor = True
    '
    'checkSaveTIFF
    '
    Me.checkSaveTIFF.AutoSize = True
    Me.checkSaveTIFF.Location = New System.Drawing.Point(174, 85)
    Me.checkSaveTIFF.Name = "checkSaveTIFF"
    Me.checkSaveTIFF.Size = New System.Drawing.Size(48, 17)
    Me.checkSaveTIFF.TabIndex = 7
    Me.checkSaveTIFF.Text = "TIFF"
    Me.checkSaveTIFF.UseVisualStyleBackColor = True
    '
    'textSavePath
    '
    Me.textSavePath.Location = New System.Drawing.Point(14, 142)
    Me.textSavePath.Name = "textSavePath"
    Me.textSavePath.Size = New System.Drawing.Size(391, 20)
    Me.textSavePath.TabIndex = 13
    '
    'checkAutoOverwrite
    '
    Me.checkAutoOverwrite.AutoSize = True
    Me.checkAutoOverwrite.Location = New System.Drawing.Point(411, 200)
    Me.checkAutoOverwrite.Name = "checkAutoOverwrite"
    Me.checkAutoOverwrite.Size = New System.Drawing.Size(96, 17)
    Me.checkAutoOverwrite.TabIndex = 17
    Me.checkAutoOverwrite.Text = "Auto-Overwrite"
    Me.checkAutoOverwrite.UseVisualStyleBackColor = True
    '
    'buttonBrowse
    '
    Me.buttonBrowse.Location = New System.Drawing.Point(411, 140)
    Me.buttonBrowse.Name = "buttonBrowse"
    Me.buttonBrowse.Size = New System.Drawing.Size(75, 23)
    Me.buttonBrowse.TabIndex = 14
    Me.buttonBrowse.Text = "Browse..."
    Me.buttonBrowse.UseVisualStyleBackColor = True
    '
    'textTextOverlay
    '
    Me.textTextOverlay.Location = New System.Drawing.Point(14, 254)
    Me.textTextOverlay.Name = "textTextOverlay"
    Me.textTextOverlay.Size = New System.Drawing.Size(485, 20)
    Me.textTextOverlay.TabIndex = 19
    '
    'labelTextOverlay
    '
    Me.labelTextOverlay.AutoSize = True
    Me.labelTextOverlay.Location = New System.Drawing.Point(11, 238)
    Me.labelTextOverlay.Name = "labelTextOverlay"
    Me.labelTextOverlay.Size = New System.Drawing.Size(70, 13)
    Me.labelTextOverlay.TabIndex = 18
    Me.labelTextOverlay.Text = "Text Overlay:"
    '
    'textDocumentURL
    '
    Me.textDocumentURL.Location = New System.Drawing.Point(15, 28)
    Me.textDocumentURL.Name = "textDocumentURL"
    Me.textDocumentURL.Size = New System.Drawing.Size(484, 20)
    Me.textDocumentURL.TabIndex = 2
    '
    'tabGeneral
    '
    Me.tabGeneral.Controls.Add(Me.checkAutoOverwrite)
    Me.tabGeneral.Controls.Add(Me.buttonBrowse)
    Me.tabGeneral.Controls.Add(Me.textTextOverlay)
    Me.tabGeneral.Controls.Add(Me.labelTextOverlay)
    Me.tabGeneral.Controls.Add(Me.textDocumentURL)
    Me.tabGeneral.Controls.Add(Me.checkSaveAll)
    Me.tabGeneral.Controls.Add(Me.textSavePath)
    Me.tabGeneral.Controls.Add(Me.textBaseName)
    Me.tabGeneral.Controls.Add(Me.labelBaseName)
    Me.tabGeneral.Controls.Add(Me.labelSavePath)
    Me.tabGeneral.Controls.Add(Me.checkSaveWMF)
    Me.tabGeneral.Controls.Add(Me.labelSaveFormats)
    Me.tabGeneral.Controls.Add(Me.checkSaveEMF)
    Me.tabGeneral.Controls.Add(Me.labelDocumentURL)
    Me.tabGeneral.Controls.Add(Me.checkSaveBMP)
    Me.tabGeneral.Controls.Add(Me.checkSaveJPEG)
    Me.tabGeneral.Controls.Add(Me.checkSaveTIFF)
    Me.tabGeneral.Controls.Add(Me.checkSavePNG)
    Me.tabGeneral.Controls.Add(Me.checkSaveGIF)
    Me.tabGeneral.Location = New System.Drawing.Point(4, 22)
    Me.tabGeneral.Name = "tabGeneral"
    Me.tabGeneral.Padding = New System.Windows.Forms.Padding(3)
    Me.tabGeneral.Size = New System.Drawing.Size(518, 296)
    Me.tabGeneral.TabIndex = 0
    Me.tabGeneral.Text = "General"
    Me.tabGeneral.UseVisualStyleBackColor = True
    '
    'checkSaveAll
    '
    Me.checkSaveAll.AutoSize = True
    Me.checkSaveAll.Location = New System.Drawing.Point(396, 85)
    Me.checkSaveAll.Name = "checkSaveAll"
    Me.checkSaveAll.Size = New System.Drawing.Size(45, 17)
    Me.checkSaveAll.TabIndex = 11
    Me.checkSaveAll.Text = "ALL"
    Me.checkSaveAll.UseVisualStyleBackColor = True
    '
    'checkSavePNG
    '
    Me.checkSavePNG.AutoSize = True
    Me.checkSavePNG.Location = New System.Drawing.Point(15, 85)
    Me.checkSavePNG.Name = "checkSavePNG"
    Me.checkSavePNG.Size = New System.Drawing.Size(49, 17)
    Me.checkSavePNG.TabIndex = 4
    Me.checkSavePNG.Text = "PNG"
    Me.checkSavePNG.UseVisualStyleBackColor = True
    '
    'checkSaveGIF
    '
    Me.checkSaveGIF.AutoSize = True
    Me.checkSaveGIF.Location = New System.Drawing.Point(125, 85)
    Me.checkSaveGIF.Name = "checkSaveGIF"
    Me.checkSaveGIF.Size = New System.Drawing.Size(43, 17)
    Me.checkSaveGIF.TabIndex = 6
    Me.checkSaveGIF.Text = "GIF"
    Me.checkSaveGIF.UseVisualStyleBackColor = True
    '
    'tabCollection
    '
    Me.tabCollection.Controls.Add(Me.tabGeneral)
    Me.tabCollection.Controls.Add(Me.tabAdvanced)
    Me.tabCollection.Controls.Add(Me.tabServer)
    Me.tabCollection.Location = New System.Drawing.Point(12, 92)
    Me.tabCollection.Name = "tabCollection"
    Me.tabCollection.SelectedIndex = 0
    Me.tabCollection.Size = New System.Drawing.Size(526, 322)
    Me.tabCollection.TabIndex = 55
    '
    'tabAdvanced
    '
    Me.tabAdvanced.Controls.Add(Me.tabResolution)
    Me.tabAdvanced.Controls.Add(Me.labelResolutionGuidlines)
    Me.tabAdvanced.Controls.Add(Me.labelThumnailGeneration)
    Me.tabAdvanced.Controls.Add(Me.tabThumbnail)
    Me.tabAdvanced.Location = New System.Drawing.Point(4, 22)
    Me.tabAdvanced.Name = "tabAdvanced"
    Me.tabAdvanced.Padding = New System.Windows.Forms.Padding(3)
    Me.tabAdvanced.Size = New System.Drawing.Size(518, 296)
    Me.tabAdvanced.TabIndex = 1
    Me.tabAdvanced.Text = "Advanced"
    Me.tabAdvanced.UseVisualStyleBackColor = True
    '
    'tabResolution
    '
    Me.tabResolution.Controls.Add(Me.tabCommonResolution)
    Me.tabResolution.Controls.Add(Me.tabSyntaxResolution)
    Me.tabResolution.Location = New System.Drawing.Point(15, 168)
    Me.tabResolution.Name = "tabResolution"
    Me.tabResolution.SelectedIndex = 0
    Me.tabResolution.Size = New System.Drawing.Size(484, 108)
    Me.tabResolution.TabIndex = 21
    '
    'tabCommonResolution
    '
    Me.tabCommonResolution.Controls.Add(Me.checkResolution1680x1050)
    Me.tabCommonResolution.Controls.Add(Me.checkResolution1920x1200)
    Me.tabCommonResolution.Controls.Add(Me.checkResolution1600x1200)
    Me.tabCommonResolution.Controls.Add(Me.checkResolution1024x768)
    Me.tabCommonResolution.Controls.Add(Me.checkResolution1440x900)
    Me.tabCommonResolution.Controls.Add(Me.checkResolution1280x720)
    Me.tabCommonResolution.Controls.Add(Me.checkResolution1280x1024)
    Me.tabCommonResolution.Controls.Add(Me.checkResolution640x480)
    Me.tabCommonResolution.Controls.Add(Me.checkResolution800x600)
    Me.tabCommonResolution.Location = New System.Drawing.Point(4, 22)
    Me.tabCommonResolution.Name = "tabCommonResolution"
    Me.tabCommonResolution.Padding = New System.Windows.Forms.Padding(3)
    Me.tabCommonResolution.Size = New System.Drawing.Size(476, 82)
    Me.tabCommonResolution.TabIndex = 0
    Me.tabCommonResolution.Text = "Common"
    Me.tabCommonResolution.UseVisualStyleBackColor = True
    '
    'checkResolution1680x1050
    '
    Me.checkResolution1680x1050.AutoSize = True
    Me.checkResolution1680x1050.Location = New System.Drawing.Point(325, 12)
    Me.checkResolution1680x1050.Name = "checkResolution1680x1050"
    Me.checkResolution1680x1050.Size = New System.Drawing.Size(79, 17)
    Me.checkResolution1680x1050.TabIndex = 7
    Me.checkResolution1680x1050.Text = "1680x1050"
    Me.checkResolution1680x1050.UseVisualStyleBackColor = True
    '
    'checkResolution1920x1200
    '
    Me.checkResolution1920x1200.AutoSize = True
    Me.checkResolution1920x1200.Location = New System.Drawing.Point(325, 58)
    Me.checkResolution1920x1200.Name = "checkResolution1920x1200"
    Me.checkResolution1920x1200.Size = New System.Drawing.Size(79, 17)
    Me.checkResolution1920x1200.TabIndex = 9
    Me.checkResolution1920x1200.Text = "1920x1200"
    Me.checkResolution1920x1200.UseVisualStyleBackColor = True
    '
    'checkResolution1600x1200
    '
    Me.checkResolution1600x1200.AutoSize = True
    Me.checkResolution1600x1200.Location = New System.Drawing.Point(325, 35)
    Me.checkResolution1600x1200.Name = "checkResolution1600x1200"
    Me.checkResolution1600x1200.Size = New System.Drawing.Size(79, 17)
    Me.checkResolution1600x1200.TabIndex = 8
    Me.checkResolution1600x1200.Text = "1600x1200"
    Me.checkResolution1600x1200.UseVisualStyleBackColor = True
    '
    'checkResolution1024x768
    '
    Me.checkResolution1024x768.AutoSize = True
    Me.checkResolution1024x768.Location = New System.Drawing.Point(12, 58)
    Me.checkResolution1024x768.Name = "checkResolution1024x768"
    Me.checkResolution1024x768.Size = New System.Drawing.Size(73, 17)
    Me.checkResolution1024x768.TabIndex = 3
    Me.checkResolution1024x768.Text = "1024x768"
    Me.checkResolution1024x768.UseVisualStyleBackColor = True
    '
    'checkResolution1440x900
    '
    Me.checkResolution1440x900.AutoSize = True
    Me.checkResolution1440x900.Location = New System.Drawing.Point(170, 58)
    Me.checkResolution1440x900.Name = "checkResolution1440x900"
    Me.checkResolution1440x900.Size = New System.Drawing.Size(73, 17)
    Me.checkResolution1440x900.TabIndex = 6
    Me.checkResolution1440x900.Text = "1440x900"
    Me.checkResolution1440x900.UseVisualStyleBackColor = True
    '
    'checkResolution1280x720
    '
    Me.checkResolution1280x720.AutoSize = True
    Me.checkResolution1280x720.Location = New System.Drawing.Point(170, 12)
    Me.checkResolution1280x720.Name = "checkResolution1280x720"
    Me.checkResolution1280x720.Size = New System.Drawing.Size(73, 17)
    Me.checkResolution1280x720.TabIndex = 4
    Me.checkResolution1280x720.Text = "1280x720"
    Me.checkResolution1280x720.UseVisualStyleBackColor = True
    '
    'checkResolution1280x1024
    '
    Me.checkResolution1280x1024.AutoSize = True
    Me.checkResolution1280x1024.Location = New System.Drawing.Point(170, 35)
    Me.checkResolution1280x1024.Name = "checkResolution1280x1024"
    Me.checkResolution1280x1024.Size = New System.Drawing.Size(79, 17)
    Me.checkResolution1280x1024.TabIndex = 5
    Me.checkResolution1280x1024.Text = "1280x1024"
    Me.checkResolution1280x1024.UseVisualStyleBackColor = True
    '
    'checkResolution640x480
    '
    Me.checkResolution640x480.AutoSize = True
    Me.checkResolution640x480.Location = New System.Drawing.Point(12, 12)
    Me.checkResolution640x480.Name = "checkResolution640x480"
    Me.checkResolution640x480.Size = New System.Drawing.Size(67, 17)
    Me.checkResolution640x480.TabIndex = 1
    Me.checkResolution640x480.Text = "640x480"
    Me.checkResolution640x480.UseVisualStyleBackColor = True
    '
    'checkResolution800x600
    '
    Me.checkResolution800x600.AutoSize = True
    Me.checkResolution800x600.Location = New System.Drawing.Point(12, 35)
    Me.checkResolution800x600.Name = "checkResolution800x600"
    Me.checkResolution800x600.Size = New System.Drawing.Size(67, 17)
    Me.checkResolution800x600.TabIndex = 2
    Me.checkResolution800x600.Text = "800x600"
    Me.checkResolution800x600.UseVisualStyleBackColor = True
    '
    'tabSyntaxResolution
    '
    Me.tabSyntaxResolution.Controls.Add(Me.textResolutionSyntax)
    Me.tabSyntaxResolution.Location = New System.Drawing.Point(4, 22)
    Me.tabSyntaxResolution.Name = "tabSyntaxResolution"
    Me.tabSyntaxResolution.Padding = New System.Windows.Forms.Padding(3)
    Me.tabSyntaxResolution.Size = New System.Drawing.Size(476, 82)
    Me.tabSyntaxResolution.TabIndex = 1
    Me.tabSyntaxResolution.Text = "Syntax"
    Me.tabSyntaxResolution.UseVisualStyleBackColor = True
    '
    'textResolutionSyntax
    '
    Me.textResolutionSyntax.Location = New System.Drawing.Point(12, 12)
    Me.textResolutionSyntax.Multiline = True
    Me.textResolutionSyntax.Name = "textResolutionSyntax"
    Me.textResolutionSyntax.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
    Me.textResolutionSyntax.Size = New System.Drawing.Size(448, 63)
    Me.textResolutionSyntax.TabIndex = 10
    '
    'labelResolutionGuidlines
    '
    Me.labelResolutionGuidlines.AutoSize = True
    Me.labelResolutionGuidlines.Location = New System.Drawing.Point(16, 152)
    Me.labelResolutionGuidlines.Name = "labelResolutionGuidlines"
    Me.labelResolutionGuidlines.Size = New System.Drawing.Size(103, 13)
    Me.labelResolutionGuidlines.TabIndex = 20
    Me.labelResolutionGuidlines.Text = "Resolution Guidlines"
    '
    'labelThumnailGeneration
    '
    Me.labelThumnailGeneration.AutoSize = True
    Me.labelThumnailGeneration.Location = New System.Drawing.Point(12, 12)
    Me.labelThumnailGeneration.Name = "labelThumnailGeneration"
    Me.labelThumnailGeneration.Size = New System.Drawing.Size(111, 13)
    Me.labelThumnailGeneration.TabIndex = 18
    Me.labelThumnailGeneration.Text = "Thumbnail Generation"
    '
    'tabThumbnail
    '
    Me.tabThumbnail.Controls.Add(Me.tabCommonThumbnail)
    Me.tabThumbnail.Controls.Add(Me.tabSyntaxThumbnail)
    Me.tabThumbnail.Enabled = False
    Me.tabThumbnail.Location = New System.Drawing.Point(15, 28)
    Me.tabThumbnail.Name = "tabThumbnail"
    Me.tabThumbnail.SelectedIndex = 0
    Me.tabThumbnail.Size = New System.Drawing.Size(484, 112)
    Me.tabThumbnail.TabIndex = 19
    '
    'tabCommonThumbnail
    '
    Me.tabCommonThumbnail.Controls.Add(Me.checkThumb500GIF)
    Me.tabCommonThumbnail.Controls.Add(Me.checkThumb125GIF)
    Me.tabCommonThumbnail.Controls.Add(Me.checkThumb250GIF)
    Me.tabCommonThumbnail.Controls.Add(Me.checkThumb125PNG)
    Me.tabCommonThumbnail.Controls.Add(Me.checkThumb125JPEG)
    Me.tabCommonThumbnail.Controls.Add(Me.checkThumb500JPEG)
    Me.tabCommonThumbnail.Controls.Add(Me.checkThumb250JPEG)
    Me.tabCommonThumbnail.Controls.Add(Me.checkThumb500PNG)
    Me.tabCommonThumbnail.Controls.Add(Me.checkThumb250PNG)
    Me.tabCommonThumbnail.Location = New System.Drawing.Point(4, 22)
    Me.tabCommonThumbnail.Name = "tabCommonThumbnail"
    Me.tabCommonThumbnail.Padding = New System.Windows.Forms.Padding(3)
    Me.tabCommonThumbnail.Size = New System.Drawing.Size(476, 86)
    Me.tabCommonThumbnail.TabIndex = 0
    Me.tabCommonThumbnail.Text = "Common"
    Me.tabCommonThumbnail.UseVisualStyleBackColor = True
    '
    'checkThumb500GIF
    '
    Me.checkThumb500GIF.AutoSize = True
    Me.checkThumb500GIF.Location = New System.Drawing.Point(12, 58)
    Me.checkThumb500GIF.Name = "checkThumb500GIF"
    Me.checkThumb500GIF.Size = New System.Drawing.Size(126, 17)
    Me.checkThumb500GIF.TabIndex = 3
    Me.checkThumb500GIF.Text = "Large (500x500, GIF)"
    Me.checkThumb500GIF.UseVisualStyleBackColor = True
    '
    'formDefault
    '
    Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
    Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
    Me.ClientSize = New System.Drawing.Size(550, 455)
    Me.Controls.Add(Me.buttonCapture)
    Me.Controls.Add(Me.checkIEI)
    Me.Controls.Add(Me.WebBrowser1)
    Me.Controls.Add(Me.tabCollection)
    Me.Controls.Add(Me.pictureBanner)
    Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
    Me.MaximizeBox = False
    Me.Name = "formDefault"
    Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
    Me.Text = "WebCapture"
    Me.TopMost = True
    CType(Me.pictureBanner, System.ComponentModel.ISupportInitialize).EndInit()
    Me.tabServer.ResumeLayout(False)
    Me.tabServer.PerformLayout()
    Me.groupVariables.ResumeLayout(False)
    Me.groupVariables.PerformLayout()
    Me.tabSyntaxThumbnail.ResumeLayout(False)
    Me.tabSyntaxThumbnail.PerformLayout()
    Me.tabGeneral.ResumeLayout(False)
    Me.tabGeneral.PerformLayout()
    Me.tabCollection.ResumeLayout(False)
    Me.tabAdvanced.ResumeLayout(False)
    Me.tabAdvanced.PerformLayout()
    Me.tabResolution.ResumeLayout(False)
    Me.tabCommonResolution.ResumeLayout(False)
    Me.tabCommonResolution.PerformLayout()
    Me.tabSyntaxResolution.ResumeLayout(False)
    Me.tabSyntaxResolution.PerformLayout()
    Me.tabThumbnail.ResumeLayout(False)
    Me.tabCommonThumbnail.ResumeLayout(False)
    Me.tabCommonThumbnail.PerformLayout()
    Me.ResumeLayout(False)
    Me.PerformLayout()

  End Sub
  Friend WithEvents pictureBanner As System.Windows.Forms.PictureBox
  Friend WithEvents labelVarPreview As System.Windows.Forms.Label
  Friend WithEvents textVarBaseName As System.Windows.Forms.TextBox
  Friend WithEvents tabServer As System.Windows.Forms.TabPage
  Friend WithEvents groupVariables As System.Windows.Forms.GroupBox
  Friend WithEvents checkVarResolutions As System.Windows.Forms.CheckBox
  Friend WithEvents checkVarThumbnails As System.Windows.Forms.CheckBox
  Friend WithEvents checkVarDocumentURL As System.Windows.Forms.CheckBox
  Friend WithEvents checkVarBaseName As System.Windows.Forms.CheckBox
  Friend WithEvents textVarDocumentURL As System.Windows.Forms.TextBox
  Friend WithEvents textVarResolutions As System.Windows.Forms.TextBox
  Friend WithEvents labelVarSuccessful As System.Windows.Forms.Label
  Friend WithEvents textVarThumbnails As System.Windows.Forms.TextBox
  Friend WithEvents labelVarThumnails As System.Windows.Forms.Label
  Friend WithEvents labelVarBaseName As System.Windows.Forms.Label
  Friend WithEvents checkVarSavedPath As System.Windows.Forms.CheckBox
  Friend WithEvents checkVarSavedFormats As System.Windows.Forms.CheckBox
  Friend WithEvents textVarSavedPath As System.Windows.Forms.TextBox
  Friend WithEvents labelVarSavedPath As System.Windows.Forms.Label
  Friend WithEvents textVarSavedFormats As System.Windows.Forms.TextBox
  Friend WithEvents labelVarSavedFormats As System.Windows.Forms.Label
  Friend WithEvents checkVarSuccessful As System.Windows.Forms.CheckBox
  Friend WithEvents checkVarProcessId As System.Windows.Forms.CheckBox
  Friend WithEvents labelVarProcessId As System.Windows.Forms.Label
  Friend WithEvents textVarSuccessful As System.Windows.Forms.TextBox
  Friend WithEvents labelVarDocumentURL As System.Windows.Forms.Label
  Friend WithEvents textVarProcessId As System.Windows.Forms.TextBox
  Friend WithEvents textProcessURL As System.Windows.Forms.TextBox
  Friend WithEvents textProcessId As System.Windows.Forms.TextBox
  Friend WithEvents labelProcessId As System.Windows.Forms.Label
  Friend WithEvents labelProcessURL As System.Windows.Forms.Label
  Friend WithEvents buttonCapture As System.Windows.Forms.Button
  Friend WithEvents checkIEI As System.Windows.Forms.CheckBox
  Friend WithEvents checkThumb125GIF As System.Windows.Forms.CheckBox
  Friend WithEvents checkThumb250GIF As System.Windows.Forms.CheckBox
  Friend WithEvents checkThumb125PNG As System.Windows.Forms.CheckBox
  Friend WithEvents checkThumb125JPEG As System.Windows.Forms.CheckBox
  Friend WithEvents checkThumb500JPEG As System.Windows.Forms.CheckBox
  Friend WithEvents tabSyntaxThumbnail As System.Windows.Forms.TabPage
  Friend WithEvents textThumbnailSyntax As System.Windows.Forms.TextBox
  Friend WithEvents checkThumb250JPEG As System.Windows.Forms.CheckBox
  Friend WithEvents checkThumb500PNG As System.Windows.Forms.CheckBox
  Friend WithEvents checkThumb250PNG As System.Windows.Forms.CheckBox
  Friend WithEvents CheckBox13 As System.Windows.Forms.CheckBox
  Friend WithEvents CheckBox14 As System.Windows.Forms.CheckBox
  Friend WithEvents CheckBox15 As System.Windows.Forms.CheckBox
  Friend WithEvents CheckBox16 As System.Windows.Forms.CheckBox
  Friend WithEvents CheckBox17 As System.Windows.Forms.CheckBox
  Friend WithEvents dialogBrowse As System.Windows.Forms.FolderBrowserDialog
  Friend WithEvents WebBrowser1 As System.Windows.Forms.WebBrowser
  Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
  Friend WithEvents CheckBox18 As System.Windows.Forms.CheckBox
  Friend WithEvents CheckBox7 As System.Windows.Forms.CheckBox
  Friend WithEvents CheckBox11 As System.Windows.Forms.CheckBox
  Friend WithEvents CheckBox12 As System.Windows.Forms.CheckBox
  Friend WithEvents textBaseName As System.Windows.Forms.TextBox
  Friend WithEvents labelBaseName As System.Windows.Forms.Label
  Friend WithEvents labelSavePath As System.Windows.Forms.Label
  Friend WithEvents checkSaveWMF As System.Windows.Forms.CheckBox
  Friend WithEvents labelSaveFormats As System.Windows.Forms.Label
  Friend WithEvents checkSaveEMF As System.Windows.Forms.CheckBox
  Friend WithEvents labelDocumentURL As System.Windows.Forms.Label
  Friend WithEvents checkSaveBMP As System.Windows.Forms.CheckBox
  Friend WithEvents checkSaveJPEG As System.Windows.Forms.CheckBox
  Friend WithEvents checkSaveTIFF As System.Windows.Forms.CheckBox
  Friend WithEvents textSavePath As System.Windows.Forms.TextBox
  Friend WithEvents checkAutoOverwrite As System.Windows.Forms.CheckBox
  Friend WithEvents buttonBrowse As System.Windows.Forms.Button
  Friend WithEvents textTextOverlay As System.Windows.Forms.TextBox
  Friend WithEvents labelTextOverlay As System.Windows.Forms.Label
  Friend WithEvents textDocumentURL As System.Windows.Forms.TextBox
  Friend WithEvents tabGeneral As System.Windows.Forms.TabPage
  Friend WithEvents checkSaveAll As System.Windows.Forms.CheckBox
  Friend WithEvents checkSavePNG As System.Windows.Forms.CheckBox
  Friend WithEvents checkSaveGIF As System.Windows.Forms.CheckBox
  Friend WithEvents tabCollection As System.Windows.Forms.TabControl
  Friend WithEvents tabAdvanced As System.Windows.Forms.TabPage
  Friend WithEvents tabResolution As System.Windows.Forms.TabControl
  Friend WithEvents tabCommonResolution As System.Windows.Forms.TabPage
  Friend WithEvents checkResolution1680x1050 As System.Windows.Forms.CheckBox
  Friend WithEvents checkResolution1920x1200 As System.Windows.Forms.CheckBox
  Friend WithEvents checkResolution1600x1200 As System.Windows.Forms.CheckBox
  Friend WithEvents checkResolution1024x768 As System.Windows.Forms.CheckBox
  Friend WithEvents checkResolution1440x900 As System.Windows.Forms.CheckBox
  Friend WithEvents checkResolution1280x720 As System.Windows.Forms.CheckBox
  Friend WithEvents checkResolution1280x1024 As System.Windows.Forms.CheckBox
  Friend WithEvents checkResolution640x480 As System.Windows.Forms.CheckBox
  Friend WithEvents checkResolution800x600 As System.Windows.Forms.CheckBox
  Friend WithEvents tabSyntaxResolution As System.Windows.Forms.TabPage
  Friend WithEvents textResolutionSyntax As System.Windows.Forms.TextBox
  Friend WithEvents labelResolutionGuidlines As System.Windows.Forms.Label
  Friend WithEvents labelThumnailGeneration As System.Windows.Forms.Label
  Friend WithEvents tabThumbnail As System.Windows.Forms.TabControl
  Friend WithEvents tabCommonThumbnail As System.Windows.Forms.TabPage
  Friend WithEvents checkThumb500GIF As System.Windows.Forms.CheckBox
End Class
