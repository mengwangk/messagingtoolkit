Imports Microsoft.Win32
Imports System.Text.RegularExpressions
Imports System
Imports System.Drawing
Imports System.Drawing.Graphics
Imports System.Drawing.Imaging
Imports System.IO
Module modMisc
  Private AppRegistryKey As String = "Software\Esquivias\WebCapture"

  Public Function FileExists(ByVal FileFullPath As String) As Boolean
    Dim f As New IO.FileInfo(FileFullPath)
    Return f.Exists
  End Function

  Public Function FolderExists(ByVal FolderPath As String) As Boolean
    Dim f As New IO.DirectoryInfo(FolderPath)
    Return f.Exists
  End Function

  Public Function getLastRun(ByVal Value As String)
    Dim RegKey As RegistryKey = Registry.CurrentUser.OpenSubKey(AppRegistryKey, True)
    If (RegKey Is Nothing) Then
      Return ""
      Exit Function
    End If
    Dim key As RegistryKey = RegKey.OpenSubKey("LastRun", True)
    If key Is Nothing Then
      Return ""
      Exit Function
    End If
    If (key.GetValue(Value) Is Nothing) Then
      Return ""
    Else
      Return key.GetValue(Value).ToString
    End If
  End Function

  Public Sub setLastRun(ByVal Name As String, ByVal Value As String)
    Dim RegKey As RegistryKey = Registry.CurrentUser.OpenSubKey(AppRegistryKey, True)
    If (RegKey Is Nothing) Then
      RegKey = Registry.CurrentUser.CreateSubKey(AppRegistryKey)
      RegKey = Registry.CurrentUser.OpenSubKey(AppRegistryKey, True)
    End If
    Dim key As RegistryKey = RegKey.OpenSubKey("LastRun", True)
    If key Is Nothing Then
      key = RegKey.CreateSubKey("LastRun")
    End If
    key.SetValue(Name, Value)
  End Sub

  Public Sub checkIEInt(ByVal remove As Boolean, ByVal forceadd As Boolean)
    If (forceadd) Then
      Dim RegKey As RegistryKey = Registry.CurrentUser.OpenSubKey("Software\Microsoft\Internet Explorer\MenuExt", True)
      Dim key As RegistryKey = RegKey.OpenSubKey("WebCapture", True)
      If key Is Nothing Then
        key = RegKey.CreateSubKey("WebCapture")
      End If
      key.SetValue("", System.Windows.Forms.Application.StartupPath & "\InternetExplorer.htm")
    Else
      Dim RegKey As RegistryKey = Registry.CurrentUser.OpenSubKey("Software\Microsoft\Internet Explorer\MenuExt", True)
      If (remove) Then
        Dim key As RegistryKey = RegKey.OpenSubKey("WebCapture", True)
        If key IsNot Nothing Then
          RegKey.DeleteSubKeyTree("WebCapture")
        End If
      Else
        Dim key As RegistryKey = RegKey.OpenSubKey("WebCapture", True)
        If key Is Nothing Then
          formDefault.checkIEI.Checked = False
        Else
          key.SetValue("", System.Windows.Forms.Application.StartupPath & "\InternetExplorer.htm")
          formDefault.checkIEI.Checked = True
        End If
      End If
    End If
  End Sub

  Public Sub saveGuidlineUpdate()
    formDefault.SaveGuidlines = ""
    Dim ag As IEnumerator = formDefault.arrayGuidlines.GetEnumerator
    While ag.MoveNext
      If (formDefault.SaveGuidlines <> "") Then
        formDefault.SaveGuidlines += "," & ag.Current
      Else
        formDefault.SaveGuidlines = ag.Current
      End If
    End While
    setLastRun("SaveGuidelines", formDefault.SaveGuidlines)
    enableCapture()
  End Sub

  Public Sub enableCapture()
    If (formDefault.textDocumentURL.Text.Trim.Length > 0) Then
      If (formDefault.arrayFormats.Count > 0) Then
        If (formDefault.textBaseName.Text.Trim.Length > 0) Then
          formDefault.buttonCapture.Enabled = True
        Else
          formDefault.buttonCapture.Enabled = False
        End If
      Else
        formDefault.buttonCapture.Enabled = False
      End If
    Else
      formDefault.buttonCapture.Enabled = False
    End If
  End Sub

  Public Sub saveFormatUpdate()
    Dim SaveFormats As String = ""
    Dim af As IEnumerator = formDefault.arrayFormats.GetEnumerator
    While af.MoveNext
      If (SaveFormats <> "") Then
        SaveFormats += "," & af.Current
      Else
        SaveFormats = af.Current
      End If
    End While
    If (formDefault.arrayFormats.Count = 7) Then
      formDefault.checkSaveAll.Checked = True
    Else
      formDefault.checkSaveAll.Checked = False
    End If
    setLastRun("SaveFormats", SaveFormats)
    enableCapture()
  End Sub

  Public Sub ListGuideLine(ByVal Value As String, ByVal Checked As Boolean)
    If (Checked) Then
      ListAdd(formDefault.arrayGuidlines, Value)
    Else
      ListRemove(formDefault.arrayGuidlines, Value)
    End If
    saveGuidlineUpdate()
  End Sub

  Public Sub ListFormat(ByVal Value As String, ByVal Checked As Boolean)
    If (Checked) Then
      ListAdd(formDefault.arrayFormats, Value)
    Else
      ListRemove(formDefault.arrayFormats, Value)
    End If
    saveFormatUpdate()
  End Sub

  Public Sub ListAdd(ByVal List As ArrayList, ByVal Value As String)
    List.Add(Value)
  End Sub

  Public Sub ListRemove(ByVal List As ArrayList, ByVal Value As String)
    List.Remove(Value)
  End Sub


  Public Sub DrawWebImage()
    Do
      Try
        Dim scrollWidth As Integer
        Dim scrollHeight As Integer
        scrollHeight = formDefault.WebBrowser1.Document.Body.ScrollRectangle.Height
        scrollWidth = formDefault.WebBrowser1.Document.Body.ScrollRectangle.Width
        formDefault.WebBrowser1.Size = New Size(scrollWidth, scrollHeight)
        Dim bm As New Bitmap(scrollWidth, scrollHeight)
        formDefault.WebBrowser1.DrawToBitmap(bm, New Rectangle(0, 0, bm.Width, bm.Height))
        'x.watermark
        If (formDefault.textTextOverlay.Text.Trim.Length > 0) Then
          Dim Watermark As Graphics = Graphics.FromImage(bm)
          Watermark.DrawString(formDefault.textTextOverlay.Text, New Font("Verdana", 7, FontStyle.Regular), New SolidBrush(Color.FromArgb(110, 0, 0, 0)), 1, 1)
          Watermark.DrawString(formDefault.textTextOverlay.Text, New Font("Verdana", 7, FontStyle.Regular), New SolidBrush(Color.FromArgb(140, 255, 255, 255)), 0, 0)
        End If
        'x.guidelines
        Dim ag As IEnumerator = formDefault.arrayGuidlines.GetEnumerator
        Dim agwh As String()
        While ag.MoveNext
          Dim drawGuidelines = Graphics.FromImage(bm)
          Dim drawGuidlineXY As Graphics = Graphics.FromImage(bm)
          agwh = Split(ag.Current, "x")
          drawGuidelines.DrawRectangle(Pens.Black, 0, 0, Convert.ToInt16(agwh(0)), Convert.ToInt16(agwh(1)))
          drawGuidlineXY.DrawString(ag.Current, New Font("Verdana", 7, FontStyle.Regular), New SolidBrush(Color.FromArgb(200, 0, 0, 0)), 1, Convert.ToInt16(agwh(1)) - 7)
          drawGuidlineXY.DrawString(ag.Current, New Font("Verdana", 7, FontStyle.Regular), New SolidBrush(Color.FromArgb(200, 255, 255, 255)), 0, Convert.ToInt16(agwh(1)) - 8)
        End While
        'x.formats
        If (FolderExists(formDefault.SavePath) = False) Then
          Directory.CreateDirectory(formDefault.SavePath)
        End If
        Dim af As IEnumerator = formDefault.arrayFormats.GetEnumerator
        While af.MoveNext
          Select Case af.Current
            Case "png"
              Dim doSave = False
              If (FileExists(formDefault.SavePath & "\" & formDefault.textBaseName.Text & ".png")) Then
                If (formDefault.checkAutoOverwrite.Checked) Then
                  doSave = True
                Else
                  Dim x = MsgBox("Overwrite '" & formDefault.textBaseName.Text & ".png'?", MsgBoxStyle.YesNo)
                  If (x = 6) Then doSave = True
                End If
              Else
                doSave = True
              End If
              If (doSave) Then
                bm.Save(formDefault.SavePath & "\" & formDefault.textBaseName.Text & ".png", System.Drawing.Imaging.ImageFormat.Png)
              End If
            Case "jpeg"
              Dim doSave = False
              If (FileExists(formDefault.SavePath & "\" & formDefault.textBaseName.Text & ".jpeg")) Then
                If (formDefault.checkAutoOverwrite.Checked) Then
                  doSave = True
                Else
                  Dim x = MsgBox("Overwrite '" & formDefault.textBaseName.Text & ".jpeg'?", MsgBoxStyle.YesNo)
                  If (x = 6) Then doSave = True
                End If
              Else
                doSave = True
              End If
              If (doSave) Then
                bm.Save(formDefault.SavePath & "\" & formDefault.textBaseName.Text & ".jpeg", System.Drawing.Imaging.ImageFormat.Jpeg)
              End If
            Case "gif"
              Dim doSave = False
              If (FileExists(formDefault.SavePath & "\" & formDefault.textBaseName.Text & ".gif")) Then
                If (formDefault.checkAutoOverwrite.Checked) Then
                  doSave = True
                Else
                  Dim x = MsgBox("Overwrite '" & formDefault.textBaseName.Text & ".gif'?", MsgBoxStyle.YesNo)
                  If (x = 6) Then doSave = True
                End If
              Else
                doSave = True
              End If
              If (doSave) Then
                bm.Save(formDefault.SavePath & "\" & formDefault.textBaseName.Text & ".gif", System.Drawing.Imaging.ImageFormat.Gif)
              End If
            Case "tiff"
              Dim doSave = False
              If (FileExists(formDefault.SavePath & "\" & formDefault.textBaseName.Text & ".tiff")) Then
                If (formDefault.checkAutoOverwrite.Checked) Then
                  doSave = True
                Else
                  Dim x = MsgBox("Overwrite '" & formDefault.textBaseName.Text & ".tiff'?", MsgBoxStyle.YesNo)
                  If (x = 6) Then doSave = True
                End If
              Else
                doSave = True
              End If
              If (doSave) Then
                bm.Save(formDefault.SavePath & "\" & formDefault.textBaseName.Text & ".tiff", System.Drawing.Imaging.ImageFormat.Tiff)
              End If
            Case "bmp"
              Dim doSave = False
              If (FileExists(formDefault.SavePath & "\" & formDefault.textBaseName.Text & ".bmp")) Then
                If (formDefault.checkAutoOverwrite.Checked) Then
                  doSave = True
                Else
                  Dim x = MsgBox("Overwrite '" & formDefault.textBaseName.Text & ".bmp'?", MsgBoxStyle.YesNo)
                  If (x = 6) Then doSave = True
                End If
              Else
                doSave = True
              End If
              If (doSave) Then
                bm.Save(formDefault.SavePath & "\" & formDefault.textBaseName.Text & ".bmp", System.Drawing.Imaging.ImageFormat.Bmp)
              End If
            Case "emf"
              Dim doSave = False
              If (FileExists(formDefault.SavePath & "\" & formDefault.textBaseName.Text & ".emf")) Then
                If (formDefault.checkAutoOverwrite.Checked) Then
                  doSave = True
                Else
                  Dim x = MsgBox("Overwrite '" & formDefault.textBaseName.Text & ".emf'?", MsgBoxStyle.YesNo)
                  If (x = 6) Then doSave = True
                End If
              Else
                doSave = True
              End If
              If (doSave) Then
                bm.Save(formDefault.SavePath & "\" & formDefault.textBaseName.Text & ".emf", System.Drawing.Imaging.ImageFormat.Emf)
              End If
            Case "wmf"
              Dim doSave = False
              If (FileExists(formDefault.SavePath & "\" & formDefault.textBaseName.Text & ".wmf")) Then
                If (formDefault.checkAutoOverwrite.Checked) Then
                  doSave = True
                Else
                  Dim x = MsgBox("Overwrite '" & formDefault.textBaseName.Text & ".wmf'?", MsgBoxStyle.YesNo)
                  If (x = 6) Then doSave = True
                End If
              Else
                doSave = True
              End If
              If (doSave) Then
                bm.Save(formDefault.SavePath & "\" & formDefault.textBaseName.Text & ".wmf", System.Drawing.Imaging.ImageFormat.Wmf)
              End If
          End Select
        End While
        '
        bm.Dispose()
        formDefault.ImageCaptured = True
        formDefault.ServerReturn = True
      Catch ex As Exception
        formDefault.ImageCaptured = True
        formDefault.ServerReturn = False
      Finally
        '
      End Try
    Loop Until formDefault.ImageCaptured = True
    formDefault.isCaptureEvent = False
    formDefault.buttonCapture.Enabled = True
    formDefault.WebBrowser1.Navigate("about:blank")
    'What do we tell the server?
    formDefault.tabCollection.Enabled = True
  End Sub

End Module
