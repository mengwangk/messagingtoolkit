﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.cmdStartListening = New System.Windows.Forms.Button
        Me.grpOut = New System.Windows.Forms.GroupBox
        Me.txtTo = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtMsg = New System.Windows.Forms.TextBox
        Me.chkRequestReceipt = New System.Windows.Forms.CheckBox
        Me.cmdSendSMS = New System.Windows.Forms.Button
        Me.grpIn = New System.Windows.Forms.GroupBox
        Me.txtInSMS = New System.Windows.Forms.TextBox
        Me.grpOut.SuspendLayout()
        Me.grpIn.SuspendLayout()
        Me.SuspendLayout()
        '
        'cmdStartListening
        '
        Me.cmdStartListening.Location = New System.Drawing.Point(152, 12)
        Me.cmdStartListening.Name = "cmdStartListening"
        Me.cmdStartListening.Size = New System.Drawing.Size(394, 23)
        Me.cmdStartListening.TabIndex = 0
        Me.cmdStartListening.Text = "Start TCP (UI will stop responding until the mobile application connects)"
        Me.cmdStartListening.UseVisualStyleBackColor = True
        '
        'grpOut
        '
        Me.grpOut.Controls.Add(Me.cmdSendSMS)
        Me.grpOut.Controls.Add(Me.chkRequestReceipt)
        Me.grpOut.Controls.Add(Me.Label2)
        Me.grpOut.Controls.Add(Me.txtMsg)
        Me.grpOut.Controls.Add(Me.Label1)
        Me.grpOut.Controls.Add(Me.txtTo)
        Me.grpOut.Enabled = False
        Me.grpOut.Location = New System.Drawing.Point(12, 41)
        Me.grpOut.Name = "grpOut"
        Me.grpOut.Size = New System.Drawing.Size(303, 232)
        Me.grpOut.TabIndex = 1
        Me.grpOut.TabStop = False
        Me.grpOut.Text = "Outgoing SMS"
        '
        'txtTo
        '
        Me.txtTo.Location = New System.Drawing.Point(87, 17)
        Me.txtTo.Name = "txtTo"
        Me.txtTo.Size = New System.Drawing.Size(208, 21)
        Me.txtTo.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(15, 20)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(66, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Message to:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(28, 47)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(53, 13)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Message:"
        '
        'txtMsg
        '
        Me.txtMsg.Location = New System.Drawing.Point(87, 44)
        Me.txtMsg.Multiline = True
        Me.txtMsg.Name = "txtMsg"
        Me.txtMsg.Size = New System.Drawing.Size(208, 124)
        Me.txtMsg.TabIndex = 2
        '
        'chkRequestReceipt
        '
        Me.chkRequestReceipt.AutoSize = True
        Me.chkRequestReceipt.Location = New System.Drawing.Point(87, 174)
        Me.chkRequestReceipt.Name = "chkRequestReceipt"
        Me.chkRequestReceipt.Size = New System.Drawing.Size(127, 17)
        Me.chkRequestReceipt.TabIndex = 4
        Me.chkRequestReceipt.Text = "Request read receipt"
        Me.chkRequestReceipt.UseVisualStyleBackColor = True
        '
        'cmdSendSMS
        '
        Me.cmdSendSMS.Location = New System.Drawing.Point(61, 197)
        Me.cmdSendSMS.Name = "cmdSendSMS"
        Me.cmdSendSMS.Size = New System.Drawing.Size(181, 23)
        Me.cmdSendSMS.TabIndex = 5
        Me.cmdSendSMS.Text = "Send SMS"
        Me.cmdSendSMS.UseVisualStyleBackColor = True
        '
        'grpIn
        '
        Me.grpIn.Controls.Add(Me.txtInSMS)
        Me.grpIn.Enabled = False
        Me.grpIn.Location = New System.Drawing.Point(321, 41)
        Me.grpIn.Name = "grpIn"
        Me.grpIn.Size = New System.Drawing.Size(358, 232)
        Me.grpIn.TabIndex = 2
        Me.grpIn.TabStop = False
        Me.grpIn.Text = "Incoming SMS"
        '
        'txtInSMS
        '
        Me.txtInSMS.Location = New System.Drawing.Point(6, 17)
        Me.txtInSMS.Multiline = True
        Me.txtInSMS.Name = "txtInSMS"
        Me.txtInSMS.ReadOnly = True
        Me.txtInSMS.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtInSMS.Size = New System.Drawing.Size(346, 203)
        Me.txtInSMS.TabIndex = 3
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(692, 282)
        Me.Controls.Add(Me.grpIn)
        Me.Controls.Add(Me.grpOut)
        Me.Controls.Add(Me.cmdStartListening)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Mobile Test App"
        Me.grpOut.ResumeLayout(False)
        Me.grpOut.PerformLayout()
        Me.grpIn.ResumeLayout(False)
        Me.grpIn.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents cmdStartListening As System.Windows.Forms.Button
    Friend WithEvents grpOut As System.Windows.Forms.GroupBox
    Friend WithEvents cmdSendSMS As System.Windows.Forms.Button
    Friend WithEvents chkRequestReceipt As System.Windows.Forms.CheckBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtMsg As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtTo As System.Windows.Forms.TextBox
    Friend WithEvents grpIn As System.Windows.Forms.GroupBox
    Friend WithEvents txtInSMS As System.Windows.Forms.TextBox
End Class
