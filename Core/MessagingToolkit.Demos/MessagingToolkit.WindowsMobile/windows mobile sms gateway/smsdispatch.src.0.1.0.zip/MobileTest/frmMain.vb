﻿Imports System.Net.Sockets
Imports smsdispatch.tcp.pc
Imports smsdispatch.messages.pc

Public Class frmMain

    Private Delegate Sub Log(ByVal s As String)
    Private Delegate Sub EnDeGUI(ByVal flag As Boolean)

    Dim WithEvents sck As Client

    'Start the TCP listener and get a connection.
    Private Sub cmdStartListening_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdStartListening.Click
        Try
            Dim l As New TcpListener(9192)
            l.Start()
            sck = New smsdispatch.tcp.pc.Client
            sck.AcceptSocket(l.AcceptTcpClient)
            EnableDisableGUI(False)
            l.Stop()
            l = Nothing
        Catch ex As Exception
            MessageBox.Show(Me, "Error starting TCP listener" + vbCrLf + ex.ToString, "TCP ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    'Send an SMS.
    Private Sub cmdSendSMS_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSendSMS.Click
        If txtTo.Text = "" Then
            MessageBox.Show(Me, "Enter a recipient", "No recipient", MessageBoxButtons.OK, MessageBoxIcon.Information)
            txtTo.Focus()
            Exit Sub
        End If

        If txtMsg.Text = "" Then
            MessageBox.Show(Me, "Enter a message", "No message", MessageBoxButtons.OK, MessageBoxIcon.Information)
            txtMsg.Focus()
            Exit Sub
        End If

        Dim msg As New smsdispatch.messages.pc.SMSMsg("", txtTo.Text, Now, txtMsg.Text, chkRequestReceipt.Checked)
        sck.Send(msg.ToTransmissionString)
    End Sub

    'Incoming TCP message.
    Private Sub sck_DataArrived(ByVal sender As smsdispatch.tcp.pc.Client, ByVal data As String) Handles sck.DataArrived
        'SMS or reply of previous request?
        'A reply to previous request does not request a null character.
        If data.IndexOf(Chr(0)) > -1 Then
            Dim msg As smsdispatch.messages.pc.SMSMsg = smsdispatch.messages.pc.SMSMsg.FromTransmissionString(data)
            Me.Invoke(New Log(AddressOf doLog), New String() {msg.ToString})
        Else
            If data = Chr(6) Then
                Me.Invoke(New Log(AddressOf doLog), New String() {"SMS send successfully"})
            Else
                Me.Invoke(New Log(AddressOf doLog), New String() {"SMS send failed" + vbCrLf + data.Substring(1)})
            End If
        End If
    End Sub

    'TCP disconnected event.
    Private Sub sck_Disconnected(ByVal sender As smsdispatch.tcp.pc.Client) Handles sck.Disconnected
        Invoke(New EnDeGUI(AddressOf EnableDisableGUI), New Object() {True})
    End Sub

    Private Sub EnableDisableGUI(ByVal flag As Boolean)
        cmdStartListening.Enabled = flag
        grpIn.Enabled = Not flag
        grpOut.Enabled = Not flag
    End Sub

    Private Sub doLog(ByVal s As String)
        txtInSMS.AppendText(s + vbCrLf)
        txtInSMS.ScrollToCaret()
    End Sub

End Class