﻿SMSDispatch has been created using the Mobile SDK version 6.

It has been tested on two different HTC mobile phones.

Typical configuration steps in order to run the service and sample:

1. Change the contents of the MobileService\mobile.txt file to match your desired configuration.
   For details, see also the MobileService\Config.vb class.
2. Build the project.
3. Deploy the mobile service to the mobile phone.
4. On the mobile phone, start the mobile service.
5. On Windows, start the MobileTest application and start the TCP listener.

If all goes well, in a few seconds the mobile application will connect to the Windows application.
At that point, you'll be able to send SMS messages from the Windows application and incoming SMS
messages will be send to the Windows application.

If it doesn't work:

1. Check your mobile.txt file and make sure you have the correct parameters. Particularly, make sure
   that you have a correct host or IP address.
   
2. Make sure that there is TCP connectivity between your mobile phone and Windows. Typically you would
   need to either connect your mobile to your PC and ActiveSync using a USB cable, or your mobile should
   be able to reach your PC if you have a Wi-Fi network.
   
3. Verify that you have downloaded and installed the Mobile SDK version 6.

**** Remember ****
If you register the mobile application as a persistent interceptor, it will catch incoming SMS
messages even if the mobile application isn't running - the mobile OS will start it automatically.

If you register the mobile application so that it doesn't notify other applications of incoming
SMS messages, then you will not see any SMS messages that happen to arrive at the time you perform
testing in your normal SMS inbox.
