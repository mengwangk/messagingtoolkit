﻿''
'' This program is free software; you can redistribute it and/or modify
'' it under the terms of the GNU General Public License as published by
'' the Free Software Foundation; either version 2 of the License, or
'' (at your option) any later version.
''
'' This program is distributed in the hope that it will be useful,
'' but WITHOUT ANY WARRANTY; without even the implied warranty of
'' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'' GNU General Public License for more details.
''
'' You should have received a copy of the GNU General Public License
'' along with this program; if not, write to the Free Software
'' Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
'' 
Imports System.Text
Imports System.Net.Sockets

''' <summary>
''' This class implements basic TCP socket plumbing.
''' </summary>
''' <remarks></remarks>
Public Class Client

    ''' <summary>
    ''' Fired when data arrives over the socket.
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="data"></param>
    ''' <remarks></remarks>
    Public Event DataArrived(ByVal sender As Client, ByVal data As String)

    ''' <summary>
    ''' Fired when the remote party disconnects.
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <remarks></remarks>
    Public Event Disconnected(ByVal sender As Client)

    ''' <summary>
    ''' Internally used TCP client.
    ''' </summary>
    ''' <remarks></remarks>
    Protected WithEvents sck As TcpClient

    ''' <summary>
    ''' Internal placeholder for arrived data.
    ''' </summary>
    ''' <remarks></remarks>
    Protected sckData(4096) As Byte

    ''' <summary>
    ''' Returns whether the current socket is connected.
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property IsConnected() As Boolean
        Get
            If sck IsNot Nothing Then
                Return sck.Connected
            Else
                Return False
            End If
        End Get
    End Property

    ''' <summary>
    ''' Uses a connected TcpClient object.
    ''' </summary>
    ''' <param name="tcp">Connected TcpClient.</param>
    ''' <remarks></remarks>
    Public Sub AcceptSocket(ByVal tcp As TcpClient)
        sck = tcp
        sck.GetStream.BeginRead(sckData, 0, sckData.GetLength(0), AddressOf StreamReceive, Nothing)
    End Sub

    ''' <summary>
    ''' Connects to a remote host.
    ''' </summary>
    ''' <param name="host">Host or IP address.</param>
    ''' <param name="port">Port.</param>
    ''' <remarks></remarks>
    Public Sub Connect(ByVal host As String, ByVal port As Integer)
        If sck IsNot Nothing Then
            If sck.Connected Then
                sck.Close()
            End If
            sck = Nothing
        End If

        Try
            sck = New TcpClient
            sck.Connect(host, port)
            sck.GetStream.BeginRead(sckData, 0, sckData.GetLength(0), AddressOf StreamReceive, Nothing)
        Catch ex As Exception
            sck = Nothing
            Throw ex
        End Try

    End Sub

    ''' <summary>
    ''' Sends a string to the remote party.
    ''' </summary>
    ''' <param name="str">Data to send</param>
    ''' <remarks></remarks>
    Public Sub Send(ByVal str As String)
        Send(System.Text.Encoding.UTF8.GetBytes(str))
    End Sub

    ''' <summary>
    ''' Sends binary data to the remote party.
    ''' </summary>
    ''' <param name="b">Byte array with data to send.</param>
    ''' <remarks></remarks>
    Public Sub Send(ByVal b() As Byte)
        'Note that we're using a two-byte software header that includes
        'the length of the message to send.
        '
        '  ------------------------------------
        '  | Length of data (2 bytes) |  Data |
        '  ------------------------------------

        Dim bFinal() As Byte
        ReDim bFinal(b.GetLength(0) + 2 - 1)
        bFinal(0) = CByte(b.GetLength(0) \ 256)
        bFinal(1) = CByte(b.GetLength(0) Mod 256)
        Array.Copy(b, 0, bFinal, 2, b.GetLength(0))

        SyncLock sck.GetStream
            sck.GetStream.BeginWrite(bFinal, 0, bFinal.Length, Nothing, Nothing)
        End SyncLock
    End Sub

    ''' <summary>
    ''' Receives data from the remote party.
    ''' </summary>
    ''' <param name="ar"></param>
    ''' <remarks></remarks>
    Private Sub StreamReceive(ByVal ar As IAsyncResult)
        Dim byteCount As Integer

        Try
            SyncLock sck.GetStream
                byteCount = sck.GetStream.EndRead(ar)
            End SyncLock

            If byteCount < 1 Then
                Throw New Exception("Disconnected")
            End If

            MessageAssembler(sckData, 0, byteCount)

            SyncLock sck.GetStream
                sck.GetStream.BeginRead(sckData, 0, sckData.GetLength(0), AddressOf StreamReceive, Nothing)
            End SyncLock

        Catch ex As Exception
            If sck.Connected Then
                sck.Close()
            End If
            sck = Nothing
            RaiseEvent Disconnected(Me)
        End Try

    End Sub

    ''' <summary>
    ''' Unpackes the remote message.
    ''' </summary>
    ''' <param name="b"></param>
    ''' <param name="offset"></param>
    ''' <param name="count"></param>
    ''' <remarks></remarks>
    Private Sub MessageAssembler(ByVal b() As Byte, ByVal offset As Integer, ByVal count As Integer)
        Static len As Integer = -1
        Static recBytesOffset As Integer = 0
        Static recBytes() As Byte = {}

        Dim byteCount As Integer = 0

        'Unpack what we have.
        While byteCount <> count

            'Get the software header.
            If len = -1 Then
                If count - byteCount < 2 Then Exit Sub
                len = b(byteCount) * 256 + b(byteCount + 1)
                byteCount += 2
                ReDim recBytes(len - 1)
            End If

            For i As Integer = byteCount To count - 1
                recBytes(recBytesOffset) = b(i)
                recBytesOffset += 1
                byteCount += 1
                'If we have a logical packet, fire our event.
                If recBytesOffset = len Then
                    RaiseEvent DataArrived(Me, System.Text.Encoding.UTF8.GetString(recBytes))
                    ReDim recBytes(-1)
                    len = -1
                    recBytesOffset = 0
                    Exit For
                End If
            Next
        End While

    End Sub

End Class
