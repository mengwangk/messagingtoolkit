﻿''
'' This program is free software; you can redistribute it and/or modify
'' it under the terms of the GNU General Public License as published by
'' the Free Software Foundation; either version 2 of the License, or
'' (at your option) any later version.
''
'' This program is distributed in the hope that it will be useful,
'' but WITHOUT ANY WARRANTY; without even the implied warranty of
'' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'' GNU General Public License for more details.
''
'' You should have received a copy of the GNU General Public License
'' along with this program; if not, write to the Free Software
'' Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
'' 
Imports Microsoft.WindowsMobile.PocketOutlook
Imports Microsoft.WindowsMobile.PocketOutlook.MessageInterception

Public Class frmMain

    'Used to log status messages on the main form thread.
    Private Delegate Sub Log(ByVal s As String)

    'Used to send an SMS on the main form thread.
    Private Delegate Sub SendMessage(ByVal sms As SmsMessage)

    'The SMS interceptor object.
    Dim WithEvents msgInterceptor As MessageInterceptor

    'The TCP connection object.
    Dim WithEvents clientSck As tcp.mobile.Client

    'Our config.
    Dim cfg As Config = Nothing

#Region "Form events"

    'On form closing, stop the interceptor.
    Private Sub frmMain_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        If msgInterceptor IsNot Nothing Then
            msgInterceptor.Dispose()
            msgInterceptor = Nothing
        End If
    End Sub

    'Startup.
    Private Sub frmMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        'Try to get the config out of the mobile.txt file.
        Try
            Dim SR As New IO.StreamReader(GetExecutingDirectory() + "\mobile.txt")
            cfg = New Config(SR)
            SR.Close()
            SR.Dispose()
            SR = Nothing
        Catch ex As Exception
            'Error, use defaults.
            doLog("Error reading config (" + ex.Message + ")")
            doLog("Using default config")
            cfg = New Config
        End Try

        'Show it.
        doLog(cfg.ToString)

        'Is it a permanent interceptor?
        If MessageInterceptor.IsApplicationLauncherEnabled(cfg.ServiceID) Then
            'Create using service ID.
            msgInterceptor = New MessageInterceptor(cfg.ServiceID)
        Else
            'Create normally.
            msgInterceptor = New MessageInterceptor(cfg.Action)
            msgInterceptor.MessageCondition = New MessageCondition(cfg.MsgProperty, cfg.MsgCondition, cfg.MsgValue)
        End If

        'Persist whether it's a permanent interceptor.
        If cfg.IsLauncherEnabled Then
            msgInterceptor.EnableApplicationLauncher(cfg.ServiceID)
        Else
            msgInterceptor.DisableApplicationLauncher()
        End If

        'Add the event handler.
        AddHandler msgInterceptor.MessageReceived, AddressOf msgInterceptor_MessageReceived

    End Sub

    'Quits.
    Private Sub cmdQuit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdQuit.Click
        Application.Exit()
    End Sub

#End Region

#Region "SMS"

    'SMS arrived.
    Private Sub msgInterceptor_MessageReceived(ByVal sender As Object, ByVal e As Microsoft.WindowsMobile.PocketOutlook.MessageInterception.MessageInterceptorEventArgs)
        Dim sms As SmsMessage = CType(e.Message, SmsMessage)

        'Create our object.
        Dim smsMsg As New messages.mobile.SMSMsg(sms.From.Name, sms.From.Address, sms.Received, sms.Body, False)
        doLog("Incoming SMS from " + sms.From.Name)

        'If we're connected, send it out to the host.
        If clientSck IsNot Nothing AndAlso clientSck.IsConnected Then
            Try
                SyncLock clientSck
                    clientSck.Send(smsMsg.ToTransmissionString)
                    doLog("Send to host")
                End SyncLock
            Catch ex As Exception
                'Error, write it out to our file.
                WriteToFile(smsMsg)
                doLog("Queued")
            End Try
        Else
            'If we're not connected, write it out to our file.
            WriteToFile(smsMsg)
            doLog("Queued")
        End If
    End Sub

    'Writes an SMS message to our temporary file.
    Private Sub WriteToFile(ByVal smsMsg As messages.mobile.SMSMsg)
        Dim txt As New IO.StreamWriter(GetExecutingDirectory() + "\insms.txt", True)
        smsMsg.WriteToFile(txt)
        txt.Close()
        txt.Dispose()
        txt = Nothing
    End Sub

#End Region

#Region "TCP/IP connection timer"

    'This timer is fired repeatedly to check for TCP connectivity.
    'If we're connected to the host, nothing happens.
    'Otherwise, we try to connect.
    Private Sub chkTimer_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkTimer.Tick
        If clientSck Is Nothing OrElse clientSck.IsConnected = False Then
            Try
                Invoke(New Log(AddressOf doLog), New String() {"Trying to connect to host..."})
                Dim tcp As New Net.Sockets.TcpClient
                tcp.Connect(cfg.HostIP, cfg.HostPort)
                clientSck = New tcp.mobile.Client
                clientSck.AcceptSocket(tcp)
                Invoke(New Log(AddressOf doLog), New String() {"Connection established"})
                'Make sure we replay the cached SMS messages to the host.
                RunoutSMSCache()
            Catch ex As Exception
                Invoke(New Log(AddressOf doLog), New String() {"Could not connect to host"})
                clientSck = Nothing
            End Try
        End If
    End Sub

    'Reads the cached messages from our SMS file
    'and replays them to the host.
    Private Sub RunoutSMSCache()
        If IO.File.Exists(GetExecutingDirectory() + "\insms.txt") = False Then Exit Sub
        SyncLock clientSck
            Dim txt As New IO.StreamReader(GetExecutingDirectory() + "\insms.txt", True)
            Try
                Invoke(New Log(AddressOf doLog), New String() {"Replay queued messages"})
                While txt.Peek > -1
                    Dim msg As messages.mobile.SMSMsg = messages.mobile.SMSMsg.FromFile(txt)
                    clientSck.Send(msg.ToTransmissionString)
                End While
                txt.Close()
                txt.Dispose()
                txt = Nothing
                'When we're done, delete the file.
                IO.File.Delete(GetExecutingDirectory() + "\insms.txt")
                Invoke(New Log(AddressOf doLog), New String() {"Replay complete"})
            Catch ex As Exception
                txt.Close()
                txt.Dispose()
                txt = Nothing
                Invoke(New Log(AddressOf doLog), New String() {"Replay error (" + ex.Message + ")"})
            End Try
        End SyncLock
    End Sub

#End Region

#Region "TCP/IP events"

    'A new SMS request is handled here.
    '
    'The host includes the telephone number in the FromAddress message field
    'and the message body in the Message field.
    '
    'If we successfully send the SMS, we send back an ACK to the host.
    'Otherwise we send a NACK followed by the error message.
    Private Sub clientSck_DataArrived(ByVal sender As tcp.mobile.Client, ByVal data As String) Handles clientSck.DataArrived
        Dim msg As messages.mobile.SMSMsg = messages.mobile.SMSMsg.FromTransmissionString(data)
        SyncLock clientSck
            Try
                Invoke(New Log(AddressOf doLog), New String() {"Sending SMS for host..."})
                Dim sms As New SmsMessage(msg.FromAddress, msg.Message)
                sms.RequestDeliveryReport = msg.RequestReceipt
                'It appears that we need to throw the SMS on the same thread
                'as the interceptor in order to be able to receive receipts.
                Invoke(New SendMessage(AddressOf SendSMS), New Object() {sms})
                clientSck.Send(Chr(6))
                Invoke(New Log(AddressOf doLog), New String() {"Successful"})
            Catch ex As Exception
                clientSck.Send(Chr(21) + ex.Message)
                Invoke(New Log(AddressOf doLog), New String() {"Failed (" + ex.Message + ")"})
            End Try
        End SyncLock
    End Sub

    Private Sub SendSMS(ByVal sms As SmsMessage)
        sms.Send()
    End Sub

    'Host disconnected.
    Private Sub clientSck_Disconnected(ByVal sender As tcp.mobile.Client) Handles clientSck.Disconnected
        Invoke(New Log(AddressOf doLog), New String() {"Disconnected"})
    End Sub

#End Region

#Region "Various"

    'Returns the executing directory.
    Private Function GetExecutingDirectory() As String
        Dim asm As Reflection.Assembly = System.Reflection.Assembly.GetExecutingAssembly
        Dim pathName As String = asm.ManifestModule.FullyQualifiedName
        Return pathName.Substring(0, pathName.LastIndexOf("\"c))
    End Function

    'Logs information to the form textbox.
    Private Sub doLog(ByVal s As String)
        If txtOutput.Text.Length > 1024 Then txtOutput.Text = ""
        txtOutput.Text = txtOutput.Text + s + vbCrLf
        txtOutput.SelectionStart = txtOutput.Text.Length - 1
        txtOutput.SelectionLength = 1
        txtOutput.ScrollToCaret()
    End Sub

#End Region

End Class