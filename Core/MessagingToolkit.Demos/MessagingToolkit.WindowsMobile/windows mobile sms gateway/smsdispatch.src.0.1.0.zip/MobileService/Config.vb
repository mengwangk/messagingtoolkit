﻿''
'' This program is free software; you can redistribute it and/or modify
'' it under the terms of the GNU General Public License as published by
'' the Free Software Foundation; either version 2 of the License, or
'' (at your option) any later version.
''
'' This program is distributed in the hope that it will be useful,
'' but WITHOUT ANY WARRANTY; without even the implied warranty of
'' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'' GNU General Public License for more details.
''
'' You should have received a copy of the GNU General Public License
'' along with this program; if not, write to the Free Software
'' Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
'' 
Imports Microsoft.WindowsMobile.PocketOutlook
Imports Microsoft.WindowsMobile.PocketOutlook.MessageInterception

''' <summary>
''' This class is used to hold the mobile dispatcher configuration.
''' </summary>
''' <remarks></remarks>
Public Class Config

    ''' <summary>
    ''' Our service ID.
    ''' </summary>
    ''' <remarks></remarks>
    Public ServiceID As String = "MobileService-ID"

    ''' <summary>
    ''' True to create a persistent interceptor, false otherwise.
    ''' </summary>
    ''' <remarks></remarks>
    Public IsLauncherEnabled As Boolean = False

    ''' <summary>
    ''' Set to the type of message property to match when intercepting.
    ''' </summary>
    ''' <remarks></remarks>
    Public MsgProperty As MessageProperty = MessageProperty.Body

    ''' <summary>
    ''' Set to the comparison type of the message property to match
    ''' when intercepting.
    ''' </summary>
    ''' <remarks></remarks>
    Public MsgCondition As MessagePropertyComparisonType = MessagePropertyComparisonType.NotEqual

    ''' <summary>
    ''' Set to the value of the message property to match using the 
    ''' comparison type when intercepting.
    ''' </summary>
    ''' <remarks></remarks>
    Public MsgValue As String = "Any string"

    ''' <summary>
    ''' Action to perform with the intercepted message.
    ''' </summary>
    ''' <remarks></remarks>
    Public Action As InterceptionAction = InterceptionAction.NotifyAndDelete

    ''' <summary>
    ''' Remote host IP.
    ''' </summary>
    ''' <remarks></remarks>
    Public HostIP As String = "192.168.1.195"

    ''' <summary>
    ''' Remote port.
    ''' </summary>
    ''' <remarks></remarks>
    Public HostPort As Integer = 9192

    ''' <summary>
    ''' Default class constructor which yields the default configuration.
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub New()
    End Sub

    ''' <summary>
    ''' Creates a new instance by reading the configuration from a text file.
    ''' </summary>
    ''' <param name="SR">Stream reader of text file with the configuration.</param>
    ''' <remarks></remarks>
    Public Sub New(ByVal SR As IO.StreamReader)
        ServiceID = SR.ReadLine
        IsLauncherEnabled = Convert.ToBoolean(SR.ReadLine)
        MsgProperty = CType([Enum].Parse(GetType(MessageProperty), SR.ReadLine, True), MessageProperty)
        MsgCondition = CType([Enum].Parse(GetType(MessagePropertyComparisonType), SR.ReadLine, True), MessagePropertyComparisonType)
        MsgValue = SR.ReadLine
        Action = CType([Enum].Parse(GetType(InterceptionAction), SR.ReadLine, True), InterceptionAction)
        HostIP = SR.ReadLine
        HostPort = Convert.ToInt32(SR.ReadLine)
    End Sub

    ''' <summary>
    ''' Returns the configuration in human-readable form.
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Overrides Function ToString() As String
        Return "ServiceID: " + ServiceID + vbCrLf + _
               "Launcher Enabled: " + IsLauncherEnabled.ToString + vbCrLf + _
               "MsgProperty: " + MsgProperty.ToString + vbCrLf + _
               "MsgCondition: " + MsgCondition.ToString + vbCrLf + _
               "MsgValue: " + MsgValue.ToString + vbCrLf + _
               "Action: " + Action.ToString + vbCrLf + _
               "HostIP: " + HostIP.ToString + vbCrLf + _
               "HostPort: " + HostPort.ToString
    End Function

End Class