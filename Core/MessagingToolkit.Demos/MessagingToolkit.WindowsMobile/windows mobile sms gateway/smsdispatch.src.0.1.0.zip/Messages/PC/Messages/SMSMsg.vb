﻿''
'' This program is free software; you can redistribute it and/or modify
'' it under the terms of the GNU General Public License as published by
'' the Free Software Foundation; either version 2 of the License, or
'' (at your option) any later version.
''
'' This program is distributed in the hope that it will be useful,
'' but WITHOUT ANY WARRANTY; without even the implied warranty of
'' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'' GNU General Public License for more details.
''
'' You should have received a copy of the GNU General Public License
'' along with this program; if not, write to the Free Software
'' Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
'' 

''' <summary>
''' This class is used to define, pack and unpack messages send between 
''' the mobile dispatcher application and another application.
''' </summary>
''' <remarks></remarks>
Public Class SMSMsg

    ''' <summary>
    ''' Name/telephone of the SMS sender.
    ''' </summary>
    ''' <remarks></remarks>
    Public FromName As String

    ''' <summary>
    ''' Name/telephone of the SMS sender.
    ''' </summary>
    ''' <remarks></remarks>
    Public FromAddress As String

    ''' <summary>
    ''' Date/time the SMS was received.
    ''' </summary>
    ''' <remarks></remarks>
    Public Received As DateTime

    ''' <summary>
    ''' Message body.
    ''' </summary>
    ''' <remarks></remarks>
    Public Message As String

    ''' <summary>
    ''' True to request a received receipt, false otherwise.
    ''' </summary>
    ''' <remarks></remarks>
    Public RequestReceipt As Boolean

    ''' <summary>
    ''' Default class constructor.
    ''' </summary>
    ''' <param name="fromName"></param>
    ''' <param name="fromAddress"></param>
    ''' <param name="received"></param>
    ''' <param name="message"></param>
    ''' <param name="requestReceipt"></param>
    ''' <remarks></remarks>
    Public Sub New(ByVal fromName As String, ByVal fromAddress As String, ByVal received As DateTime, ByVal message As String, ByVal requestReceipt As Boolean)
        Me.FromName = fromName
        Me.FromAddress = fromAddress
        Me.Received = received
        Me.Message = message
        Me.RequestReceipt = requestReceipt
    End Sub

    ''' <summary>
    ''' Persists the current instance to a file.
    ''' </summary>
    ''' <param name="SW">Open stream writer of file to persist the info to.</param>
    ''' <remarks></remarks>
    Public Sub WriteToFile(ByVal SW As IO.StreamWriter)
        SW.WriteLine("From name: " + FromName)
        SW.WriteLine("From address: " + FromAddress)
        SW.WriteLine("Received: " + formatDate(Received))
        SW.WriteLine("Message: " + Message)
    End Sub

    ''' <summary>
    ''' Creates a string with the SMS data. The string will be transmitted over a TCP socket.
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function ToTransmissionString() As String
        Return FromName + Chr(0) + FromAddress + Chr(0) + formatDate(Received) + Chr(0) + Message + Chr(0) + RequestReceipt.ToString
    End Function

    ''' <summary>
    ''' Creates an SMS message instance from a string received over a TCP socket.
    ''' </summary>
    ''' <param name="s">Data string.</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared Function FromTransmissionString(ByVal s As String) As SMSMsg
        Dim sSplit() As String = s.Split(Chr(0))
        Return New SMSMsg(sSplit(0), sSplit(1), Convert.ToDateTime(sSplit(2)), sSplit(3), Convert.ToBoolean(sSplit(4)))
    End Function

    ''' <summary>
    ''' Returns a human-readable description of the message.
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Overrides Function ToString() As String
        Return "From name: " + FromName + vbCrLf + _
               "From address: " + FromAddress + vbCrLf + _
               "Received: " + formatDate(Received) + vbCrLf + _
               "Message: " + Message
    End Function

    Private Function formatDate(ByVal dt As DateTime) As String
        Return dt.Year.ToString.PadLeft(4, "0"c) + "/" + dt.Month.ToString.PadLeft(2, "0"c) + "/" + dt.Day.ToString.PadLeft(2, "0"c) + " " + _
               dt.Hour.ToString.PadLeft(2, "0"c) + ":" + dt.Minute.ToString.PadLeft(2, "0"c) + ":" + dt.Second.ToString.PadLeft(2, "0"c)
    End Function

End Class